const tryCatch = (controller) => {
  return async (req, res) => {
    try {
      await controller(req, res);
    } catch (error) {
      res.status(500).json({ msg: error.message });
    }
  };
};

module.exports = tryCatch;
