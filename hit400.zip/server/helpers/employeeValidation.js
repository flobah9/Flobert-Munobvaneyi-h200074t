const { check } = require("express-validator");

exports.EmployeeDetailValidation = [
  check("firstName", "Firstname is required").not().isEmpty(),
  check("lastName", "Lastname is required").not().isEmpty(),
  check("ID_number", "Please enter a valid ID number").not().isEmpty(),
  check("homeAddress", "Please provide Home address").not().isEmpty(),
  check("emailAddress", "Please enter a valid email")
    .isEmail()
    .normalizeEmail({ gmail_remove_dots: true }),
  check("phoneNumber", "Enter phone number").not().isEmpty(),
  check("role", "Choose a valid role").not().isEmpty(),
];

exports.EmployeeLoginValidation = [
  check("emailAddress", "Please enter a valid email")
    .isEmail()
    .normalizeEmail({ gmail_remove_dots: true }),
  check("password", "Min password length is 8 characters").isLength({ min: 8 }),
];
