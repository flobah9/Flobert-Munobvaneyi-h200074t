const { check } = require("express-validator");

exports.OrderDetailValidation = [
  check("customerID", "Provide customer ID").not().isEmpty(),
  check("loadType", "Type of load is required").not().isEmpty(),
  check("order_details", "Order information is required").not().isEmpty(),
  check("estimated_weight", "Load weight is required").not().isEmpty(),
  check("scheduled_delivery_time", "Enter delivery time").not().isEmpty(),
];
