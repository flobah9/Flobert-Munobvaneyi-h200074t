const { check } = require("express-validator");

exports.CustomerDetailValidation = [
  check("customerName", "Customer name is required").not().isEmpty(),
  check("emailAddress", "Please enter a valid email")
    .isEmail()
    .normalizeEmail({ gmail_remove_dots: true }),
  check("phoneNumber", "Enter phone number").not().isEmpty(),
  check("location", "Location details are required").not().isEmpty(),
];
