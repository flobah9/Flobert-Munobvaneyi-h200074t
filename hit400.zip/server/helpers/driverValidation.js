const { check } = require("express-validator");

exports.DriverDetailValidation = [
  check("firstName", "Firstname is required").not().isEmpty(),
  check("lastName", "Lastname is required").not().isEmpty(),
  check("ID_number", "Please enter a valid ID number").not().isEmpty(),
  check("licence_no", "Please enter a valid Licence_no").not().isEmpty(),
  check("homeAddress", "Please provide Home address").not().isEmpty(),
  check("emailAddress", "Please enter a valid email")
    .isEmail()
    .normalizeEmail({ gmail_remove_dots: true }),
  check("phoneNumber", "Enter phone number").not().isEmpty(),
];

exports.DriverSignInValidation = [
  check("licence_no", "Licence number is required").not().isEmpty(),
  check("password", "Min password length is 8 characters").isLength({ min: 8 }),
]