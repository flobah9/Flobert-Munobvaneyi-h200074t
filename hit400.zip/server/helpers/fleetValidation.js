const { check } = require("express-validator");

exports.FleetDetailValidation = [
  check("make", "Make detail is required").not().isEmpty(),
  check("engine_size", "Provide the engine size").not().isEmpty(),
  check("payload_capacity", "Provide the payload capacity").not().isEmpty(),
];
