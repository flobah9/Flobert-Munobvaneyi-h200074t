const { validationResult } = require("express-validator");
const Employee_details = require("../models/Employee_details");
const tryCatch = require("../helpers/tryCatch");

const AddNewEmployee = tryCatch(async (req, res) => {
  //validate field to see if there is no error
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  //check if email is already used
  const employee = await Employee_details.findOne({
    where: {
      emailAddress: req.body.emailAddress,
    },
  });

  //display error message if user is already in use
  if (employee)
    return res
      .status(409)
      .json({ msg: "Email is already in use by another user" });
  //proceed to save once email is not used
  else {
    await Employee_details.create({
      firstName: req.body.firstName,
      lastName: req.body.lastName,
      ID_number: req.body.ID_number,
      homeAddress: req.body.homeAddress,
      emailAddress: req.body.emailAddress,
      phoneNumber: req.body.phoneNumber,
      role: req.body.role,
    });
    return res
      .status(201)
      .json({ msg: "New employee successfully registered into the system" });
  }
});

const UpdateEmployee = tryCatch(async (req, res) => {
  //validate field to see if there is no error
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  // Find the user by ID
  const employee = await Employee_details.findByPk(req.params.id);

  if (!employee) return res.status(404).json({ msg: "Employee not found" });

  // Iterate over the updated field
  const updatedFields = req.body;

  for (const field in updatedFields) {
    // Only update the field if it has changed
    if (updatedFields[field] !== employee[field]) {
      employee[field] = updatedFields[field];
    }
  }
  // Save the updated user
  await employee.save();
  return res.status(200).json({ msg: "Employee details successfully updated" });
});

const GetAllEmployee = tryCatch(async (req, res) => {
  const response = await Employee_details.findAll({
    attributes: [
      "id",
      "firstName",
      "lastName",
      "ID_number",
      "homeAddress",
      "emailAddress",
      "phoneNumber",
      "role",
    ],
  });
  if (response) return res.status(200).json(response);
  else {
    res.status(404).json({ msg: "Error on retrieving data" });
  }
});

const GetEmployeeById = tryCatch(async (req, res) => {
  // Find the user by ID
  const employee = await Employee_details.findByPk(req.params.id);

  if (!employee) return res.status(404).json({ msg: "Employee not found" });
  res.status(200).json(employee);
});

module.exports = {
  AddNewEmployee,
  UpdateEmployee,
  GetAllEmployee,
  GetEmployeeById,
};
