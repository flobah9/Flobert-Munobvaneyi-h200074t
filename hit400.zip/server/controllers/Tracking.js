const tryCatch = require("../helpers/tryCatch");
const Customer_profile = require("../models/Customer_profile");
const Driver_details = require("../models/Driver_details");
const Fleet_details = require("../models/Fleet_details");
const Fleet_status = require("../models/Fleet_status");
const Order_details = require("../models/Order_details");
const Route_details = require("../models/Route_details");
const Track_driver = require("../models/Track_driver");
const { Op } = require("sequelize");

const AddMyLocation = tryCatch(async (req, res) => {
  const path = await Route_details.findOne({
    where: {
      id: req.body.id,
    },
  });
  if (!path) return res.status(404).json({ msg: "Error retrieving order" });

  //finding the order status
  const order = await Order_details.findOne({
    where: {
      id: path.order_id,
    },
  });

  if (order.status === "Completed")
    return res.status(400).json({ msg: "Order already delivered" });

  //create tracking details

  const find = await Track_driver.findOne({
    where: {
      [Op.and]: [{ route_id: req.body.id }, { driver_id: req.driverId }],
    },
  });

  if (!find) {
    const create = await Track_driver.create({
      driver_id: req.driverId,
      lng: req.body.lng,
      lat: req.body.lat,
      order_id: order.id,
      route_id: path.id,
      status: "Pending",
    });
    if (!create)
      return res.status(400).json({ msg: "Failed to cretae my location" });
    res.status(200).json({ msg: "Location posted successfully" });
  } else {
    res.status(404).json({ msg: "Already exsts for tracking" });
  }
});

const GetMyLocation = tryCatch(async (req, res) => {
  const location = await Track_driver.findOne({
    where: {
      [Op.and]: [{ route_id: req.params.id }, { driver_id: req.driverId }],
    },
    attributes: ["id"],
  });
  if (!location) return res.status(404).json({ msg: "Not found" });
  res.status(200).json(location);
});

const UpdateMyCurrentLocation = tryCatch(async (req, res) => {
  const loc = await Track_driver.findByPk(req.params.id);

  if (!loc) return res.status(404).json({ msg: "Not found" });
  else {
    //update tracking details
    const driver = await Track_driver.update(
      {
        lng: req.body.lng,
        lat: req.body.lat,
      },
      {
        where: {
          [Op.and]: [{ id: req.params.id }, { driver_id: req.driverId }],
        },
      }
    );
    if (!driver) return res.status(400).json({ msg: "Failed to update" });
    res.status(200).json({ msg: "Updated successfully" });
  }
});

const TrackDriverLocation = tryCatch(async (req, res) => {
  const location = await Track_driver.findAll({
    attributes: ["id", "route_id", "driver_id", "lng", "lat", "status"],
    include: [
      {
        model: Route_details,
        attributes: [
          "id",
          "order_id",
          "originLat",
          "originLng",
          "destinationLat",
          "destinationLng",
        ],
        include: [
          {
            model: Order_details,
            attributes: ["id", "orderID", "customerID", "order_details"],
            include: [
              {
                model: Fleet_details,
                attributes: ["id", "make", "fleetNo", "class"],
                include: [
                  {
                    model: Driver_details,
                    attributes: ["id", "firstName", "lastName"],
                  },
                ],
              },
              {
                model: Customer_profile,
                attributes: ["customerName", "emailAddress", "location"],
              },
            ],
          },
        ],
      },
    ],
  });
  if (!location)
    return res.status(400).json({ msg: "Failed to get driver location" });
  res.status(200).json(location);
});

const FinishMyTravel = tryCatch(async (req, res) => {
  const loc = await Track_driver.findByPk(req.params.id);

  if (!loc) return res.status(404).json({ msg: "Not found" });
  else {
    const route = await Route_details.findOne({
      where: {
        id: loc.route_id,
      },
      attributes: ["destinationLng", "destinationLat", "order_id"],
    });

    if (!route) return res.status(404).json({ msg: "Not found" });
    else {
      const order = await Order_details.findOne({
        where: {
          id: route.order_id,
        },
        attributes: ["id", "fleet_id"],
      });

      if (!order) return res.status(404).json({ msg: "Order Not found" });
      else {
        const update = await Track_driver.update(
          {
            lng: route.destinationLng,
            lat: route.destinationLat,
            status: "Delivered",
          },
          {
            where: {
              [Op.and]: [{ id: req.params.id }, { driver_id: req.driverId }],
            },
          }
        );
        if (update) {
          await Order_details.update(
            {
              status: "Completed",
            },
            {
              where: {
                id: order.id,
              },
            }
          );

          await Fleet_status.update(
            {
              status: "Off-duty",
            },
            {
              where: {
                fleet_id: order.fleet_id,
              },
            }
          );
          res.status(200).json({ msg: "Order successfully delivered" });
        }
      }
    }
  }
});

module.exports = {
  UpdateMyCurrentLocation,
  TrackDriverLocation,
  AddMyLocation,
  GetMyLocation,
  FinishMyTravel,
};
