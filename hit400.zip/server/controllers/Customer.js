const { validationResult } = require("express-validator");
const Customer_profile = require("../models/Customer_profile");
const tryCatch = require("../helpers/tryCatch");

const AddNewCustomer = tryCatch(async (req, res) => {
  //validate field to see if there is no error
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const customer = await Customer_profile.findOne({
    where: {
      emailAddress: req.body.emailAddress,
      phoneNumber: req.body.phoneNumber,
      customerName: req.body.customerName,
    },
  });

  //display error message if user is already in use
  if (customer)
    return res.status(409).json({
      msg: "Customer details in use by another customer/ customer is already registered!!!",
    });
  else {
    const register = await Customer_profile.create({
      customerName: req.body.customerName,
      emailAddress: req.body.emailAddress,
      phoneNumber: req.body.phoneNumber,
      preferences: req.body.preferences,
      location: req.body.location,
      lng: req.body.lng,
      lat: req.body.lat,
    });
    if (register)
      return res
        .status(201)
        .json({ msg: "New customer successfully registered into the system" });
    else {
      res.status(400).json({ msg: "Something went wrong" });
    }
  }
});

const GetAllCustomers = tryCatch(async (req, res) => {
  const response = await Customer_profile.findAll({
    attributes: [
      "id",
      "customerName",
      "customerID",
      "emailAddress",
      "phoneNumber",
      "preferences",
      "location",
      "lng",
      "lat",
    ],
  });
  if (response) return res.status(200).json(response);
  else {
    res.status(404).json({ msg: "Error on retrieving data" });
  }
});

const UpdateCustomerPriofile = tryCatch(async (req, res) => {
  //validate field to see if there is no error
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  // Find the customer by ID
  const customer = await Customer_profile.findByPk(req.params.id);

  if (!customer) return res.status(404).json({ msg: "Customer not found" });

  // Iterate over the updated field
  const updatedFields = req.body;

  for (const field in updatedFields) {
    // Only update the field if it has changed
    if (updatedFields[field] !== customer[field]) {
      customer[field] = updatedFields[field];
    }
  }
  // Save the updated user
  await customer.save();
  return res.status(200).json({ msg: "Customer profile successfully updated" });
});

const GetCustomerByID = tryCatch(async (req, res) => {
  const response = await Customer_profile.findOne({
    attributes: [
      "id",
      "customerName",
      "customerID",
      "emailAddress",
      "phoneNumber",
      "location",
      "lng",
      "lat",
    ],
    where: {
      customerID: req.params.customerID,
    },
  });
  if (response) return res.status(200).json(response);
  else {
    res.status(404).json({ msg: "Error on retrieving data" });
  }
});

const CountAllCustomers = tryCatch(async (req, res) => {
  const { count } = await Customer_profile.findAndCountAll();
  res.status(200).json(count);
});

module.exports = {
  AddNewCustomer,
  GetAllCustomers,
  UpdateCustomerPriofile,
  GetCustomerByID,
  CountAllCustomers,
};
