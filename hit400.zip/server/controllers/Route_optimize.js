const tryCatch = require("../helpers/tryCatch");
const Customer_profile = require("../models/Customer_profile");
const Driver_details = require("../models/Driver_details");
const Fleet_details = require("../models/Fleet_details");
const Order_details = require("../models/Order_details");
const Route_details = require("../models/Route_details");
const { dijkstra } = require("./Dijkstra");
const { Op } = require("sequelize");
const axios = require("axios");
require("dotenv").config();

const mapboxToken = process.env.MAPBOX_ACCESS_TOKEN;

const AssignedOptimizedRoute = tryCatch(async (req, res) => {
  const viewroute = await Route_details.findAll({
    attributes: [
      "id",
      "originLat",
      "originLng",
      "destinationLat",
      "destinationLng",
    ],
    where: {
      driver_id: {
        [Op.eq]: req.driverId, // Use `Op.eq` for equality comparison
      },
    },
    include: [
      {
        model: Order_details,
        attributes: [
          "id",
          "orderID",
          "customerID",
          "scheduled_delivery_time",
          "order_details",
          "loadType",
          "status",
        ],
        include: [
          {
            model: Fleet_details,
            attributes: ["id", "fleetNo", "make"],
            include: [
              {
                model: Driver_details,
              },
            ],
          },
          {
            model: Customer_profile,
            attributes: ["id", "customerID", "customerName", "location"],
          },
        ],
      },
    ],
  });

  if (viewroute) return res.status(200).json(viewroute);
  else {
    res.status(404).json({ msg: "Error on retrieving data" });
  }
});

const OptimizeRoute = tryCatch(async (req, res) => {
  const viewpath = await Route_details.findByPk(req.params.id);
  if (!viewpath) return res.status(404).json({ msg: "Path not found" });
  else {
    const origin = { lng: viewpath.originLng, lat: viewpath.originLat };
    const destination = {
      lng: viewpath.destinationLng,
      lat: viewpath.destinationLat,
    };

    async function buildGraph(origin, destination) {
      // Function to fetch directions and extract road network data
      const fetchDirections = async (origin, destination) => {
        const directionsUrl = `https://api.mapbox.com/directions/v5/mapbox/driving/${origin.lng},${origin.lat};${destination.lng},${destination.lat}?steps=true&access_token=${mapboxToken}`;
        const response = await fetch(directionsUrl);
        const data = await response.json();
        const legs = data.routes[0].legs;

        const nodes = new Set(); // Store unique nodes (intersections)
        const edges = {}; // Adjacency list representation of graph

        for (const leg of legs) {
          const steps = leg.steps;
          let previousNode = null;

          for (const step of steps) {
            const geometry = step.geometry.coordinates;

            // Handle cases where geometry might be empty
            if (!geometry) {
              continue; // Skip iteration if geometry is empty
            }

            for (const point of geometry) {
              const node = { lng: point[0], lat: point[1] };
              nodes.add(node);

              if (previousNode) {
                if (!edges[previousNode]) {
                  edges[previousNode] = [];
                }
                edges[previousNode].push(node);
              }

              previousNode = node;
            }
          }
        }
        return { nodes, edges };
      };
      const graphData = await fetchDirections(origin, destination);
      return graphData;
    }

    // Main logic to optimize route
    const graph = await buildGraph(origin, destination); // Replace with logic to build graph from Mapbox data or other sources
    const pathR = dijkstra(graph, origin, destination);
    res.status(200).json(pathR);
  }
});

module.exports = {
  AssignedOptimizedRoute,
  OptimizeRoute,
};
