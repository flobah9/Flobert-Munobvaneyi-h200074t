const Company_profile = require("../models/Company_profile");
const tryCatch = require("../helpers/tryCatch");

const AddCompanyDetails = tryCatch(async (req, res) => {
  const company = await Company_profile.findOne({
    where: {
      companyName: req.body.companyName,
      emailAddress: req.body.emailAddress,
    },
  });

  //display error message if user is already in use
  if (company) return res.status(409).json({ msg: "Details already in use" });
  else {
    await Company_profile.create({
      companyName: req.body.companyName,
      phoneNumber: req.body.phoneNumber,
      emailAddress: req.body.emailAddress,
      location: req.body.location,
      lng: req.body.lng,
      lat: req.body.lat,
    });
    return res
      .status(201)
      .json({ msg: "Company details successfully uploaded into the system" });
  }
});

const GetCompanyProfile = tryCatch(async (req, res) => {
  const response = await Company_profile.findAll({
    attributes: [
      "id",
      "companyName",
      "phoneNumber",
      "emailAddress",
      "location",
      "lng",
      "lat",
    ],
  });
  if (response) return res.status(200).json({ response });
  else {
    res.status(404).json({ msg: "Error on retrieving data" });
  }
});

const UpdateCompanyProfile = tryCatch(async (req, res) => {
  // Find the user by ID
  const company = await Company_profile.findByPk(req.params.id);

  if (!company) return res.status(404).json({ msg: "Company not found" });

  // Iterate over the updated field
  const updatedFields = req.body;

  for (const field in updatedFields) {
    // Only update the field if it has changed
    if (updatedFields[field] !== company[field]) {
      company[field] = updatedFields[field];
    }
  }

  // Save the updated user
  await company.save();
  return res.status(200).json({ msg: "Company details successfully updated" });
});

module.exports = {
  AddCompanyDetails,
  GetCompanyProfile,
  UpdateCompanyProfile,
};
