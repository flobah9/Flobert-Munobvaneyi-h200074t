function dijkstra(graph, origin, destination) {
  // Initialize distances for all nodes
  const distances = {};
  for (const node in graph) {
    distances[node] = Infinity;
  }
  distances[origin] = 0; // Distance from origin to itself is 0

  // Set to track visited nodes
  const visited = new Set();

  // Priority queue to process nodes based on tentative distances
  const pq = new PriorityQueue({
    compare: (a, b) => distances[a] - distances[b],
  });
  pq.enqueue(origin);

  while (!pq.isEmpty()) {
    // Get the node with the shortest tentative distance
    const current = pq.dequeue();
    visited.add(current);

    // If destination is reached, stop and return paths
    if (current === destination) {
      return reconstructPaths(distances, origin);
    }

    // Explore neighbors
    for (const neighbor of graph[current]) {
      const tentativeDistance =
        distances[current] + calculateDistance(current, neighbor);
      if (!visited.has(neighbor) && tentativeDistance < distances[neighbor]) {
        distances[neighbor] = tentativeDistance;
        pq.enqueue(neighbor);
      }
    }
  }

  // No paths found
  return [];
}

// Function to calculate distance between two nodes based on coordinates (replace with your actual distance calculation)
function calculateDistance(node1, node2) {
  // Replace with your distance calculation logic based on coordinates (e.g., Euclidean distance)
  const dx = node1.lng - node2.lng;
  const dy = node1.lat - node2.lat;
  return Math.sqrt(dx * dx + dy * dy);
}

// Function to reconstruct paths from distances (optional)
function reconstructPaths(distances, origin) {
  const paths = [];
  const reconstruct = (node, currentPath = []) => {
    if (node === origin) {
      paths.push(currentPath.reverse());
      return;
    }
    for (const neighbor of graph[node]) {
      if (
        distances[node] ===
        distances[neighbor] + calculateDistance(node, neighbor)
      ) {
        reconstruct(neighbor, [...currentPath, neighbor]);
      }
    }
  };
  reconstruct(destination);
  return paths;
}

// Simple priority queue implementation (replace with a more efficient library if needed)
class PriorityQueue {
  constructor(options) {
    this.compare = options.compare;
    this.data = [];
  }

  isEmpty() {
    return this.data.length === 0;
  }

  enqueue(item) {
    this.data.push(item);
    this.heapifyUp();
  }

  dequeue() {
    const item = this.data.shift();
    this.heapifyDown();
    return item;
  }

  heapifyUp() {
    let index = this.data.length - 1;
    while (
      index > 0 &&
      this.compare(this.data[index], this.data[getParent(index)]) < 0
    ) {
      [this.data[index], this.data[getParent(index)]] = [
        this.data[getParent(index)],
        this.data[index],
      ];
      index = getParent(index);
    }
  }

  heapifyDown() {
    let index = 0;
    while (getLeftChild(index) < this.data.length) {
      let smallerChildIndex = getLeftChild(index);
      if (
        getRightChild(index) < this.data.length &&
        this.compare(
          this.data[getRightChild(index)],
          this.data[smallerChildIndex]
        ) < 0
      ) {
        smallerChildIndex = getRightChild(index);
      }
      if (this.compare(this.data[index], this.data[smallerChildIndex]) >= 0) {
        break;
      }
      [this.data[index], this.data[smallerChildIndex]] = [
        this.data[smallerChildIndex],
        this.data[index],
      ];
      index = smallerChildIndex;
    }
  }
}

function getParent(i) {
  return Math.floor((i - 1) / 2);
}

function getLeftChild(i) {
  return 2 * i + 1;
}

function getRightChild(i) {
  return 2 * i;
}
