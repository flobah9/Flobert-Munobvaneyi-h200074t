const { validationResult } = require("express-validator");
const Driver_details = require("../models/Driver_details");
const tryCatch = require("../helpers/tryCatch");
const Fleet_details = require("../models/Fleet_details");
const Fleet_status = require("../models/Fleet_status");
const Order_details = require("../models/Order_details");
const { Op } = require("sequelize");
var fs = require("fs");
const Route_details = require("../models/Route_details");
var https = require("follow-redirects").https;
require("dotenv").config();

const AddNewDriver = tryCatch(async (req, res) => {
  //validate field to see if there is no error
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  //check if email is already used
  const driver = await Driver_details.findOne({
    where: {
      emailAddress: req.body.emailAddress,
      licence_no: req.body.licence_no,
    },
  });

  //display error message if user is already in use
  if (driver)
    return res
      .status(409)
      .json({ msg: "Email is already in use by another user" });
  //proceed to save once email is not used
  else {
    const phone = req.body.phoneNumber;
    const surname = req.body.lastName;
    const name = req.body.firstName;
    //function to check if there is a free fleet without a drive

    //find fleet in fleet table
    const fleet = await Fleet_details.findAll({
      attributes: ["id", "make"],
    });
    //find used fleet
    const usedFleet = await Driver_details.findAll({
      attributes: ["fleet_id"],
    });

    // Find fleet in Fleet that have not been used in Drivers
    const unusedFleet = fleet.filter(
      (fleetA) => !usedFleet.find((fleetB) => fleetB.fleet_id === fleetA.id)
    );

    if (unusedFleet.length > 0) {
      // Randomly select an unused fleet
      const randomFleet =
        unusedFleet[Math.floor(Math.random() * unusedFleet.length)];

      // Perform any desired action with the randomly selected driver
      const assigned = await Driver_details.create({
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        ID_number: req.body.ID_number,
        licence_no: req.body.licence_no,
        homeAddress: req.body.homeAddress,
        emailAddress: req.body.emailAddress,
        phoneNumber: req.body.phoneNumber,
        fleet_id: randomFleet.id,
      });

      if (assigned) {
        //then create fleet status for the truck
        await Fleet_status.create({
          fleet_id: randomFleet.id,
          status: "Off-duty",
        });

        //retrieve infor about the assigned fleet
        const retrieveFleet = await Fleet_details.findOne({
          attributes: ["id", "fleetNo", "make", "class"],
          where: {
            id: randomFleet.id,
          },
        });

        if (retrieveFleet) {
          //send text message to drive alerting him about car assigned
          var options = {
            method: "POST",
            hostname: `${process.env.API_BASE_URL}`,
            path: "/sms/2/text/advanced",
            headers: {
              Authorization: `App ${process.env.API_KEY}`,
              "Content-Type": "application/json",
              Accept: "application/json",
            },
            maxRedirects: 20,
          };

          var req = https.request(options, function (res) {
            var chunks = [];

            res.on("data", function (chunk) {
              chunks.push(chunk);
            });

            res.on("end", function (chunk) {
              var body = Buffer.concat(chunks);
              console.log(body.toString());
            });

            res.on("error", function (error) {
              console.error(error);
            });
          });

          var postData = JSON.stringify({
            messages: [
              {
                destinations: [{ to: `${phone}` }],
                from: "ServiceSMS",
                text: `Hello ${surname} ${name}\nA truck with fleetNo: ${retrieveFleet.fleetNo} and model is ${retrieveFleet.make} and is of ${retrieveFleet.class} duty truck class has been assigned to you.`,
              },
            ],
          });

          req.write(postData);

          req.end();

          res.status(201).json({
            msg: "New driver successfully registered into the system",
          });
        }
      } else {
        res
          .status(400)
          .json({ msg: "Something went wrong, failed to add driver details" });
      }
    } else {
      res.status(400).json({
        msg: "No free vehicle is in the system, so drive is on waiting list",
      });
    }
  }
});

const UpdateDriver = tryCatch(async (req, res) => {
  //validate field to see if there is no error
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  // Find the user by ID
  const employee = await Driver_details.findByPk(req.params.id);

  if (!employee) return res.status(404).json({ msg: "Driver not found" });

  // Iterate over the updated field
  const updatedFields = req.body;

  for (const field in updatedFields) {
    // Only update the field if it has changed
    if (updatedFields[field] !== employee[field]) {
      employee[field] = updatedFields[field];
    }
  }
  // Save the updated user
  await employee.save();
  return res.status(200).json({ msg: "Driver details successfully updated" });
});

const GetAllDrivers = tryCatch(async (req, res) => {
  const response = await Driver_details.findAll({
    attributes: [
      "id",
      "firstName",
      "lastName",
      "ID_number",
      "licence_no",
      "homeAddress",
      "emailAddress",
      "phoneNumber",
    ],
    include: [
      {
        model: Fleet_details,
        attributes: [
          "id",
          "fleetNo",
          "make",
          "class",
          "payload_capacity",
          "engine_size",
        ],
        include: [
          {
            model: Fleet_status,
            attributes: ["status"],
          },
        ],
      },
    ],
  });
  if (response) return res.status(200).json(response);
  else {
    res.status(404).json({ msg: "Error on retrieving data" });
  }
});

const CountAllDrivers = tryCatch(async (req, res) => {
  const { count } = await Driver_details.findAndCountAll();
  res.status(200).json(count);
});

const DriverCountTotalAssigned = tryCatch(async (req, res) => {
  const { count } = await Route_details.findAndCountAll({
    where: {
      driver_id: {
        [Op.eq]: req.driverId, // Use `Op.eq` for equality comparison
      },
    },
  });
  res.status(200).json(count);
});

const DriverCountCompleted = tryCatch(async (req, res) => {
  const { count } = await Route_details.findAndCountAll({
    where: {
      driver_id: {
        [Op.eq]: req.driverId, // Use `Op.eq` for equality comparison
      },
    },
    include: [
      {
        model: Order_details,
        where: {
          status: "Completed",
        },
      },
    ],
  });
  res.status(200).json(count);
});

module.exports = {
  AddNewDriver,
  UpdateDriver,
  GetAllDrivers,
  CountAllDrivers,
  DriverCountCompleted,
  DriverCountTotalAssigned,
};
