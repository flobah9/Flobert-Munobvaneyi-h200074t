const { validationResult } = require("express-validator");
const bcrypt = require("bcrypt");
const Employee_details = require("../models/Employee_details");
const Employee_login = require("../models/Employee_login");
const tryCatch = require("../helpers/tryCatch");
const Driver_details = require("../models/Driver_details");
const Driver_login = require("../models/Driver_login");

const SignUpEmployee = tryCatch(async (req, res) => {
  //validation if fields are not empty
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  //check if passwords match
  if (req.body.password !== req.body.confirmPassword)
    return res.status(400).json({ msg: "Password entered don`t match" });

  //check if user is in the system
  const emailAddress = req.body.emailAddress;
  const empl = await Employee_details.findOne({
    where: { emailAddress },
    attributes: ["uuid", "id", "firstName", "lastName", "role"],
  });

  if (!empl) return res.status(404).json({ msg: "Email not found" });
  else {
    //proceed to find if user did not sign up before
    const user = await Employee_login.findOne({
      where: {
        employee_id: empl.id,
      },
    });
    if (user)
      return res.status(409).json({
        msg: "Employee already signed up, proceed to log in",
      });
    else {
      //save the new employee login details
      await Employee_login.create({
        employee_id: empl.id,
        password: req.body.password,
      });

      req.session.userId = empl.uuid;
      const uuid = empl.uuid;
      const firstName = empl.firstName;
      const lastName = empl.lastName;
      const role = empl.role;
      return res.status(200).json({ uuid, firstName, lastName, role });
    }
  }
});

const SignUpDriver = tryCatch(async (req, res) => {
  //validation if fields are not empty
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  //check if passwords match
  if (req.body.password !== req.body.confirmPassword)
    return res.status(400).json({ msg: "Password entered don`t match" });

  //check if driver is in the system
  const licence_no = req.body.licence_no;
  const drv = await Driver_details.findOne({
    where: { licence_no },
    attributes: ["uuid", "id", "firstName", "lastName", "licence_no"],
  });
  if (!drv) return res.status(404).json({ msg: "Licence_no not found" });
  else {
    const user = await Driver_login.findOne({
      where: {
        driver_id: drv.id,
      },
    });
    if (user)
      return res.status(409).json({
        msg: "Driver already signed up, proceed to log in",
      });
    else {
      //save the new employee login details
      await Driver_login.create({
        driver_id: drv.id,
        password: req.body.password,
      });

      req.session.driverId = drv.uuid;
      const uuid = drv.uuid;
      const firstName = drv.firstName;
      const lastName = drv.lastName;
      const licence_no = drv.licence_no;
      return res.status(200).json({ uuid, firstName, lastName, licence_no });
    }
  }
});

const LoginEmployee = tryCatch(async (req, res) => {
  //validation if fields are not empty
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  //check if user is in the system
  const emailAddress = req.body.emailAddress;
  const employee = await Employee_details.findOne({
    where: { emailAddress },
    attributes: ["uuid", "id", "firstName", "lastName", "role"],
  });

  if (!employee) return res.status(404).json({ msg: "User not found" });
  else {
    //proceed to find login details
    const user = await Employee_login.findOne({
      where: {
        employee_id: employee.id,
      },
    });
    //check if user exists
    if (!user) return res.status(404).json({ msg: "User not yet signed up" });
    else {
      //verify is passwords match
      const match = await bcrypt.compare(req.body.password, user.password);
      if (!match) {
        return res.status(404).json({ msg: "Wrong email/password!!" });
      }

      req.session.userId = employee.uuid;
      const uuid = employee.uuid;
      const firstName = employee.firstName;
      const lastName = employee.lastName;
      const role = employee.role;
      res.status(200).json({ uuid, firstName, lastName, role });
    }
  }
});

const LoginDriver = tryCatch(async (req, res) => {
  //validation if fields are not empty
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  //check if user is in the system
  const licence_no = req.body.licence_no;
  const driver = await Driver_details.findOne({
    where: { licence_no },
    attributes: ["uuid", "id", "firstName", "lastName", "licence_no"],
  });

  if (!driver) return res.status(404).json({ msg: "Driver not found" });
  else {
    //proceed to find login details
    const drv = await Driver_login.findOne({
      where: {
        driver_id: driver.id,
      },
    });
    //check if user exists
    if (!drv) return res.status(404).json({ msg: "Driver not yet signed up" });
    else {
      //verify is passwords match
      const match = await bcrypt.compare(req.body.password, drv.password);
      if (!match) {
        return res.status(404).json({ msg: "Wrong email/password!!" });
      }

      req.session.driverId = driver.uuid;
      const uuid = driver.uuid;
      const firstName = driver.firstName;
      const lastName = driver.lastName;
      const licence_no = driver.licence_no;
      res.status(200).json({ uuid, firstName, lastName, licence_no });
    }
  }
});

const LogoutEmployee = async (req, res) => {
  req.session.destroy((err) => {
    if (err) return res.status(400).json({ msg: "Can not logout" });
    res.status(200).json({ msg: "You have logout" });
  });
};

module.exports = {
  SignUpEmployee,
  SignUpDriver,
  LoginDriver,
  LoginEmployee,
  LogoutEmployee,
};
