const tryCatch = require("../helpers/tryCatch");
const Company_profile = require("../models/Company_profile");
const Customer_profile = require("../models/Customer_profile");
const Order_details = require("../models/Order_details");
const Route_details = require("../models/Route_details");
const Fleet_details = require("../models/Fleet_details");
const Driver_details = require("../models/Driver_details");
const Fleet_status = require("../models/Fleet_status");
const { Op } = require("sequelize");
require("dotenv").config();
const sgMail = require("@sendgrid/mail");
var fs = require("fs");
var https = require("follow-redirects").https;
const sequelize = require("sequelize");

sgMail.setApiKey(process.env.SENDGRID_API_KEY);

const CreateAnOrder = tryCatch(async (req, res) => {
  //get source lattitude and longitude
  const company = await Company_profile.findOne({
    where: {
      id: 1,
    },
    attributes: ["lat", "lng"],
  });

  const { customerID } = req.body;
  //get customer lattitude and longitude
  const customer = await Customer_profile.findOne({
    where: {
      customerID: customerID,
    },
  });

  const deliveryy = req.body.scheduled_delivery_time;

  if (!customer) return res.status(404).json({ msg: "Customer ID not found" });
  else {
    //save order details initially into the database
    const order = await Order_details.create({
      customerID: customer.customerID,
      loadType: req.body.loadType,
      order_details: req.body.order_details,
      estimated_weight: req.body.estimated_weight,
      scheduled_delivery_time: req.body.scheduled_delivery_time,
      status: "Pending",
      employee_id: req.userId,
    });

    if (!order)
      return res.status(400).json({
        msg: "An error occured during the first part of creating the order",
      });
    else {
      //assign fleet
      const fleet = await Fleet_details.findAll({
        where: {
          [Op.and]: [
            { class: req.body.loadType },
            {
              payload_capacity: {
                [Op.gte]: parseFloat(req.body.estimated_weight),
              },
            },
          ],
        },
        include: [
          {
            model: Fleet_status,
            where: {
              status: "Off-duty",
            },
          },
          {
            model: Driver_details,
            where: {},
          },
        ],
      });

      if (fleet) {
        //update order status and fleet
        const randomFleet = fleet[Math.floor(Math.random() * fleet.length)];

        const viewFleet = await Fleet_details.findOne({
          where: {
            id: randomFleet.id,
          },
          include: [
            {
              model: Driver_details,
            },
          ],
        });

        if (!viewFleet)
          return res.status(400).json({
            msg: "Fleet not found",
          });

        const updateOrder = await Order_details.update(
          {
            fleet_id: randomFleet.id,
            status: "Assigned",
          },
          {
            where: {
              id: order.id,
            },
          }
        );

        if (!updateOrder)
          return res.status(400).json({
            msg: "Something went wrong could not assign the truck for delivery",
          });

        await Fleet_status.update(
          {
            status: "On-duty",
          },
          {
            where: {
              fleet_id: randomFleet.id,
            },
          }
        );
        //save route details for easy access
        const route = await Route_details.create({
          order_id: order.id,
          originLat: company.lat,
          originLng: company.lng,
          destinationLat: customer.lat,
          destinationLng: customer.lng,
          driver_id: viewFleet?.driver_personal_detail?.id,
        });

        if (!route)
          return res.status(400).json({
            msg: "An error occured during the first part of creating the order",
          });
        else {
          //send email to customer
          const message = {
            from: "manflobah9@gmail.com",
            to: `${customer.emailAddress}`,
            subject: "Alert!!! Order created",
            text: `Good day kindly note that your delivery order have been successfully created and isc scheduled to be delivered on: ${deliveryy}`,
          };
          sgMail
            .send(message)
            .then(() => {
              console.log("Email sent");
            })
            .catch((error) => {
              console.error(error);
            });

          var options = {
            method: "POST",
            hostname: `${process.env.API_BASE_URL}`,
            path: "/sms/2/text/advanced",
            headers: {
              Authorization: `App ${process.env.API_KEY}`,
              "Content-Type": "application/json",
              Accept: "application/json",
            },
            maxRedirects: 20,
          };

          var req = https.request(options, function (res) {
            var chunks = [];

            res.on("data", function (chunk) {
              chunks.push(chunk);
            });

            res.on("end", function (chunk) {
              var body = Buffer.concat(chunks);
              console.log(body.toString());
            });

            res.on("error", function (error) {
              console.error(error);
            });
          });

          var postData = JSON.stringify({
            messages: [
              {
                destinations: [
                  { to: `${fleet?.driver_personal_detail?.phoneNumber}` },
                ],
                from: "ServiceSMS",
                text: `Hello ${fleet?.driver_personal_detail?.lastName} ${fleet?.driver_personal_detail?.firstName}, a delivery scheduled on ${deliveryy} has been assigned to you.`,
              },
            ],
          });

          req.write(postData);

          req.end();
          res.status(200).json({
            msg: "Customer order successfully created and a assigned to a fleet",
          });
        }
      } else {
        res.status(404).json({
          msg: "Order saved, but No truck is available at the moment",
        });
      }
    }
  }
});

const ViewAllOrders = tryCatch(async (req, res) => {
  const orders = await Order_details.findAll({
    attributes: [
      "id",
      "orderID",
      "customerID",
      "loadType",
      "order_details",
      "estimated_weight",
      "scheduled_delivery_time",
      "status",
    ],
    include: [
      {
        model: Fleet_details,
        attributes: ["id", "fleetNo", "make", "payload_capacity"],
        include: [
          {
            model: Driver_details,
            attributes: ["id", "licence_no", "firstName", "lastName"],
          },
        ],
      },
      {
        model: Customer_profile,
        attributes: [
          "id",
          "customerID",
          "customerName",
          "emailAddress",
          "phoneNumber",
          "location",
        ],
      },
    ],
  });
  if (orders) return res.status(200).json(orders);
  else {
    res.status(404).json({ msg: "Error on retrieving data" });
  }
});

const CountAllOrders = tryCatch(async (req, res) => {
  const { count } = await Order_details.findAndCountAll();
  res.status(200).json(count);
});

const CountCompletedOrders = tryCatch(async (req, res) => {
  const { count } = await Order_details.findAndCountAll({
    where: {
      status: "Completed",
    },
  });
  res.status(200).json(count);
});

const CancelOrder = tryCatch(async (req, res) => {
  const order = await Order_details.findByPk(req.params.id);
  if (order.status === "Pending") {
    const pendingStatus = await Order_details.update(
      {
        status: "Cancelled",
      },
      {
        where: {
          id: order.id,
        },
      }
    );
    if (!pendingStatus)
      return res.status(400).json({ msg: "Failed to update the status" });
    else {
      res.status(200).json({ msg: "Order successfully cancelled" });
    }
  } else if (order.status === "Assigned") {
    const assignedStatus = await Order_details.update(
      {
        status: "Cancelled",
      },
      {
        where: {
          id: order.id,
        },
      }
    );
    if (!assignedStatus)
      return res.status(400).json({ msg: "Failed to update the status" });
    else {
      await Fleet_status.update(
        {
          status: "Off-duty",
        },
        {
          where: {
            fleet_id: order.fleet_id,
          },
        }
      );
      res.status(200).json({ msg: "Order successfully cancelled" });
    }
  } else {
    res
      .status(409)
      .json({ msg: "Order already completed, can not be cancelled" });
  }
});

const AssignFleetToOrder = tryCatch(async (req, res) => {
  const order = await Order_details.findByPk(req.params.id);
  if (order.status !== "Assigned" || order.status !== "Completed") {
    //get source lattitude and longitude
    const company = await Company_profile.findOne({
      where: {
        id: 1,
      },
      attributes: ["lat", "lng"],
    });

    //get customer lattitude and longitude
    const customer = await Customer_profile.findOne({
      where: {
        customerID: order.customerID,
      },
    });

    if (!customer)
      return res.status(404).json({ msg: "Customer ID not found" });
    else {
      //assign fleet
      const fleet = await Fleet_details.findAll({
        where: {
          [Op.and]: [
            { class: order.loadType },
            {
              payload_capacity: {
                [Op.gte]: parseFloat(order.estimated_weight),
              },
            },
          ],
        },
        include: [
          {
            model: Fleet_status,
            where: {
              status: "Off-duty",
            },
          },
          {
            model: Driver_details,
            where: {},
          },
        ],
      });
      if (fleet) {
        //update order status and fleet
        const randomFleet = fleet[Math.floor(Math.random() * fleet.length)];
        const updateOrder = await Order_details.update(
          {
            fleet_id: randomFleet.id,
            status: "Assigned",
          },
          {
            where: {
              id: order.id,
            },
          }
        );

        if (!updateOrder)
          return res.status(400).json({
            msg: "Something went wrong could not assign the truck for delivery",
          });

        await Fleet_status.update(
          {
            status: "On-duty",
          },
          {
            where: {
              fleet_id: randomFleet.id,
            },
          }
        );
        //save route details for easy access
        const route = await Route_details.create({
          order_id: order.id,
          originLat: company.lat,
          originLng: company.lng,
          destinationLat: customer.lat,
          destinationLng: customer.lng,
        });
        if (!route)
          return res.status(400).json({
            msg: "An error occured during the first part of creating the order",
          });
        else {
          //send email to customer
          const message = {
            from: "manflobah9@gmail.com",
            to: `${customer.emailAddress}`,
            subject: "Alert!!! Order created",
            text: `Good day kindly note that your delivery order have been successfully created and isc scheduled to be delivered on: ${deliveryy}`,
          };
          sgMail
            .send(message)
            .then(() => {
              console.log("Email sent");
            })
            .catch((error) => {
              console.error(error);
            });

          //send whatsapp message to driver informing them about delivery to take place
          var options = {
            method: "POST",
            hostname: `${process.env.API_BASE_URL}`,
            path: "/whatsapp/1/message/template",
            headers: {
              Authorization: `App ${process.env.API_KEY}`,
              "Content-Type": "application/json",
              Accept: "application/json",
            },
            maxRedirects: 20,
          };

          var req = https.request(options, function (res) {
            var chunks = [];

            res.on("data", function (chunk) {
              chunks.push(chunk);
            });

            res.on("end", function (chunk) {
              var body = Buffer.concat(chunks);
              console.log(body.toString());
            });

            res.on("error", function (error) {
              console.error(error);
            });
          });

          var postData = JSON.stringify({
            messages: [
              {
                from: "447860099299",
                to: `${fleet?.driver_personal_detail?.phoneNumber}`,
                messageId: "60783695-c130-4216-9b3a-13b97351f3ff",
                content: {
                  templateName: "message_test",
                  templateData: {
                    body: {
                      placeholders: [
                        `Good day ${fleet?.driver_personal_detail?.lastName} ${fleet?.driver_personal_detail?.firstName}, a delivery scheduled on ${order.scheduled_delivery_time} has been assigned to you.`,
                      ],
                    },
                  },
                  language: "en",
                },
              },
            ],
          });

          req.write(postData);

          req.end();
          res.status(200).json({ msg: "Customer order successfully created" });
        }
      } else {
        res.status(404).json({
          msg: "Order saved, but No truck is available at the moment",
        });
      }
    }
  } else {
    res
      .status(409)
      .json({ msg: "Operation ca not be performed on this order" });
  }
});

const OrderVsFleet = tryCatch(async (req, res) => {
  const response = await Order_details.findAll({
    attributes: [
      [sequelize.fn("count", sequelize.col("order_details.id")), "total"],
      [sequelize.col("fleet_detail.make"), "make"],
    ],
    include: [
      {
        model: Fleet_details,
        attributes: ["id"],
      },
    ],
    group: ["make"],
  });
  if (!response) return res.status(500).json({ msg: "Something went wrong" });
  res.status(200).json(response);
});

const OrderVsDriver = tryCatch(async (req, res) => {
  const response = await Order_details.findAll({
    attributes: [
      [sequelize.fn("count", sequelize.col("order_details.id")), "total"],
      [
        sequelize.col("fleet_detail.driver_personal_detail.lastName"),
        "lastName",
      ],
    ],
    include: [
      {
        model: Fleet_details,
        attributes: ["id", "make"],
        include: [
          {
            model: Driver_details,
            attributes: ["firstName", "emailAddress"],
          },
        ],
      },
    ],
    group: ["lastName"],
  });
  if (!response) return res.status(500).json({ msg: "Something went wrong" });
  res.status(200).json(response);
});

module.exports = {
  CreateAnOrder,
  ViewAllOrders,
  CountAllOrders,
  CountCompletedOrders,
  CancelOrder,
  AssignFleetToOrder,
  OrderVsFleet,
  OrderVsDriver,
};
