const axios = require("axios");
require("dotenv").config();

const mapboxToken = process.env.MAPBOX_ACCESS_TOKEN;

async function getMapboxData(origin, destination) {
  const url = `https://api.mapbox.com/directions/v5/driving/${origin.lng},${origin.lat};${destination.lng},${destination.lat}?geometries=geojson&steps=true&access_token=${mapboxToken}`;

  try {
    const response = await axios.get(url);

    const data = response.data;

    // Extract relevant data from the Mapbox response (replace with your logic)
    const waypoints = data.routes[0].geometry.coordinates; // Example: array of coordinates along the route

    // Process waypoints to create a graph structure
    const graph = {};
    for (let i = 0; i < waypoints.length - 1; i++) {
      const current = waypoints[i];
      const next = waypoints[i + 1];

      // Create nodes (if they don't exist)
      if (!graph[current]) {
        graph[current] = [];
      }
      if (!graph[next]) {
        graph[next] = [];
      }

      // Add directed edge (one-way connection) from current to next
      graph[current].push(next);
    }

    return graph;
  } catch (error) {
    console.error("Error fetching data from Mapbox API:", error);
    return null; // Or handle the error differently
  }
}
