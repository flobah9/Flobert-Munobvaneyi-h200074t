const tryCatch = require("../helpers/tryCatch");
const Feedback = require("../models/Feedback");

const AddFeedback = tryCatch(async (req, res) => {
  const response = await Feedback.findOne({
    where: {
      route_id: req.body.id,
    },
  });
  if (response)
    return res.status(409).json({
      msg: "Feedback for this route already provided!",
    });

  await Feedback.create({
    route_id: req.body.id,
    traffic: req.body.traffic,
    condition: req.body.condition,
    report: req.body.report,
  });

  return res
    .status(201)
    .json({ msg: "Delivery completed and feedback successfully captured" });
});

module.exports = {
  AddFeedback,
};
