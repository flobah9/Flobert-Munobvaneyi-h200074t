const Fleet_details = require("../models/Fleet_details");
const tryCatch = require("../helpers/tryCatch");
const Driver_details = require("../models/Driver_details");
const Fleet_status = require("../models/Fleet_status");

const RegisterFleet = tryCatch(async (req, res) => {
  const fleet = await Fleet_details.findOne({
    where: {
      engine_size: req.body.engine_size,
      class: req.body.class,
    },
  });
  //display error message if user is already in use
  if (fleet)
    return res.status(409).json({
      msg: "Fleet details in use by another fleet/ fleet is already registered!!!",
    });
  else {
    await Fleet_details.create({
      make: req.body.make,
      class: req.body.class,
      engine_size: req.body.engine_size,
      payload_capacity: req.body.payload_capacity,
    });
    return res
      .status(201)
      .json({ msg: "New fleet successfully registered into the system" });
  }
});

const UpdateFleet = tryCatch(async (req, res) => {
  //validate field to see if there is no error
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  // Find the fleet by ID
  const fleet = await Fleet_details.findByPk(req.params.id);

  if (!fleet) return res.status(404).json({ msg: "Fleet not found" });

  // Iterate over the updated field
  const updatedFields = req.body;

  for (const field in updatedFields) {
    // Only update the field if it has changed
    if (updatedFields[field] !== fleet[field]) {
      fleet[field] = updatedFields[field];
    }
  }
  // Save the updated user
  await fleet.save();
  return res.status(200).json({ msg: "Fleet details successfully updated" });
});

const GetAllFleet = tryCatch(async (req, res) => {
  const fleet = await Fleet_details.findAll({
    attributes: [
      "id",
      "fleetNo",
      "make",
      "class",
      "engine_size",
      "payload_capacity",
    ],
    include: [
      {
        model: Driver_details,
        attributes: ["id", "firstName", "lastName", "licence_no"],
      },
      {
        model: Fleet_status,
        attributes: ["status"],
      },
    ],
  });
  if (fleet) return res.status(200).json(fleet);
  else {
    res.status(404).json({ msg: "Error on retrieving data" });
  }
});

const CountAllFleet = tryCatch(async (req, res) => {
  const { count } = await Fleet_details.findAndCountAll();
  res.status(200).json(count);
});

module.exports = {
  RegisterFleet,
  UpdateFleet,
  GetAllFleet,
  CountAllFleet,
};
