const tryCatch = require("../helpers/tryCatch");
const Customer_profile = require("../models/Customer_profile");
const Driver_details = require("../models/Driver_details");
const Fleet_details = require("../models/Fleet_details");
const Order_details = require("../models/Order_details");
const Route_details = require("../models/Route_details");
const axios = require("axios");
require("dotenv").config();

const AssignedOptimizedRoute = tryCatch(async (req, res) => {
  const viewroute = await Route_details.findAll({
    attributes: ["id", "originLat"],
    include: [
      {
        model: Order_details,
        attributes: [
          "id",
          "orderID",
          "customerID",
          "scheduled_delivery_time",
          "order_details",
          "loadType",
          "status",
        ],
        include: [
          {
            model: Fleet_details,
            attributes: ["id", "fleetNo", "make"],
            include: [
              {
                model: Driver_details,
                attributes: ["id", "firstName", "lastName"],
                where: {
                  id: req.driverId,
                },
              },
            ],
          },
          {
            model: Customer_profile,
            attributes: ["id", "customerID", "customerName", "location"],
          },
        ],
      },
    ],
  });

  if (viewroute) return res.status(200).json(viewroute);
  else {
    res.status(404).json({ msg: "Error on retrieving data" });
  }
});

const OptimizeRoute = tryCatch(async (req, res) => {
  const viewpath = await Route_details.findByPk(req.params.id);
  if (!viewpath) return res.status(404).json({ msg: "Path not found" });
  else {
    // Get the distance matrix from the Mapbox API
    // Get the distance matrix from the Mapbox API
    // const start = {
    //   lat: viewpath.originLat,
    //   lng: viewpath.originLng,
    // };
    res.status(200).json(viewpath);
    // const end = {
    //   lat: viewpath.destinationLat,
    //   lng: viewpath.destinationLng,
    // };

    // async function getDistanceMatrix(origin, destination) {
    //   const accessToken = process.env.MAPBOX_ACCESS_TOKEN;
    //   const response = await axios.get(
    //     `https://api.mapbox.com/directions/v5/mapbox/driving/${origin[0]},${origin[1]};${destination[0]},${destination[1]}?access_token=${accessToken}`
    //   );
    //   const distance = response.data.routes[0].distance;
    //   return distance;
    // }

    // // Define the graph as an adjacency list
    // const graph = {
    //   A: { B: 0 }, // We'll update distances later
    //   B: { A: 0, C: 0 },
    //   C: { B: 0 },
    // };

    // // Update distances using Mapbox API
    // async function updateDistances() {
    //   const origin = [start.lat, start.lng];
    //   const destination = [end.lat, end.lng];
    //   const distanceAB = await getDistanceMatrix(origin, [
    //     ,/* Latitude of B */
    //     /* Longitude of B */
    //   ]);
    //   const distanceBC = await getDistanceMatrix(
    //     [
    //       ,/* Latitude of B */
    //       /* Longitude of B */
    //     ],
    //     destination
    //   );

    //   graph.A.B = distanceAB;
    //   graph.B.A = distanceAB;
    //   graph.B.C = distanceBC;
    //   graph.C.B = distanceBC;
    // }

    // // Define the Dijkstra's algorithm function
    // function dijkstra(graph, source, destination) {
    //   const distances = {};
    //   const visited = {};
    //   const previous = {};

    //   for (let node in graph) {
    //     if (node === source) {
    //       distances[node] = 0;
    //     } else {
    //       distances[node] = Infinity;
    //     }
    //     previous[node] = null;
    //   }

    //   let current = source;
    //   while (current !== destination) {
    //     const neighbors = graph[current];
    //     for (let neighbor in neighbors) {
    //       const newDistance = distances[current] + neighbors[neighbor];
    //       if (newDistance < distances[neighbor]) {
    //         distances[neighbor] = newDistance;
    //         previous[neighbor] = current;
    //       }
    //     }
    //     visited[current] = true;
    //     let smallest = Infinity;
    //     for (let node in distances) {
    //       if (!visited[node] && distances[node] < smallest) {
    //         smallest = distances[node];
    //         current = node;
    //       }
    //     }
    //   }

    //   const path = [];
    //   while (current !== null) {
    //     path.unshift(current);
    //     current = previous[current];
    //   }

    //   return path;
    // }

    // // Simulate sending response
    // function sendResponse(path) {
    //   res.status(200).json(path);
    // }

    // // Update the distances and find the shortest path using Dijkstra's algorithm
    // updateDistances()
    //   .then(() => {
    //     const path = dijkstra(graph, "A", "C");
    //     sendResponse(path);
    //   })
    //   .catch((error) => {
    //     console.error("Error updating distances:", error);
    //     res.status(500).json({ error: "Internal server error" });
    //   });
  }
});

module.exports = {
  AssignedOptimizedRoute,
  OptimizeRoute,
};

const route = await Route_details.findOne({
  where: {
    id: loc.route_id,
  },
  attributes: ["destinationLng", "destinationLat"],
});

if (!route) return res.status(404).json({ msg: "Not found" });

const order = await Order_details.findOne({
  where: {
    id: loc.order_id,
  },
});

if (order.status === "Completed")
  return res.status(400).json({ msg: "Order already delivered" });

if (
  route.destinationLng === req.body.lng &&
  route.destinationLat === req.body.lat
) {
  //update tracking details
  const update = await Track_driver.update(
    {
      lng: req.body.lng,
      lat: req.body.lat,
      status: "Delivered",
    },
    {
      where: {
        [Op.and]: [{ id: req.params.id }, { driver_id: req.driverId }],
      },
    }
  );

  if (update) {
    await Order_details.update(
      {
        status: "Completed",
      },
      {
        where: {
          id: order.id,
        },
      }
    );

    const fleet = Fleet_details.findOne({
      where: {
        fleetNo: order.fleetNo,
      },
    });

    if (fleet) {
      await Fleet_status.update(
        {
          status: "Off-duty",
        },
        {
          where: {
            fleet_id: fleet.id,
          },
        }
      );

      res.status(200).json({ msg: "Order successfully delivered" });
    }
  }
}