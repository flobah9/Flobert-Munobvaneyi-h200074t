const { DataTypes } = require("sequelize");
const db = require("../config/conn");

const Fleet_details = db.define(
  "fleet_details",
  {
    uuid: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      allowNull: false,
      validate: {
        notEmpty: true,
      },
    },
    fleetNo: {
      type: DataTypes.STRING,
      allowNull: true,
      unique: true,
    },
    make: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    class: {
      type: DataTypes.ENUM("Light", "Medium", "Heavy"),
      allowNull: false,
    },
    engine_size: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    payload_capacity: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
  },
  { freezeTableName: true }
);

module.exports = Fleet_details;
