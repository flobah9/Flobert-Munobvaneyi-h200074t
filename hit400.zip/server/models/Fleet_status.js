const { DataTypes } = require("sequelize");
const db = require("../config/conn");
const Fleet_details = require("./Fleet_details");

const Fleet_status = db.define(
  "fleet_status",
  {
    uuid: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      allowNull: false,
      validate: {
        notEmpty: true,
      },
    },
    fleet_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    status: {
      type: DataTypes.ENUM("On-duty", "Off-duty"),
      allowNull: false,
    },
  },
  { freezeTableName: true }
);

Fleet_details.hasOne(Fleet_status, {
  foreignKey: "fleet_id",
});

Fleet_status.belongsTo(Fleet_details, {
  foreignKey: "fleet_id",
});

module.exports = Fleet_status;
