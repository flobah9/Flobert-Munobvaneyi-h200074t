const { DataTypes } = require("sequelize");
const db = require("../config/conn");

const Customer_profile = db.define(
  "customer_profile",
  {
    uuid: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      allowNull: false,
      validate: {
        notEmpty: true,
      },
    },
    customerID: {
      type: DataTypes.STRING,
      allowNull: true,
      unique: true,
    },
    customerName: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    emailAddress: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        isEmail: true,
      },
    },
    phoneNumber: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    preferences: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    location: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    lng: {
      type: DataTypes.DECIMAL(9, 6),
      allowNull: false,
    },
    lat: {
      type: DataTypes.DECIMAL(9, 6),
      allowNull: false,
    },
  },
  { freezeTableName: true }
);

module.exports = Customer_profile;
