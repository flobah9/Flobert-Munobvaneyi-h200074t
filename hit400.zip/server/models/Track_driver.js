const { DataTypes } = require("sequelize");
const db = require("../config/conn");
const Driver_details = require("./Driver_details");
const Route_details = require("./Route_details");

const Track_driver = db.define(
  "track_driver",
  {
    uuid: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      allowNull: false,
      validate: {
        notEmpty: true,
      },
    },
    driver_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    route_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    lng: {
      type: DataTypes.DECIMAL(9, 6),
      allowNull: false,
    },
    lat: {
      type: DataTypes.DECIMAL(9, 6),
      allowNull: false,
    },
    status: {
      type: DataTypes.ENUM("Pending", "Delivered"),
      allowNull: false,
    },
  },
  { freezeTableName: true }
);

Driver_details.hasMany(Track_driver, {
  foreignKey: "driver_id",
});

Track_driver.belongsTo(Driver_details, {
  foreignKey: "driver_id",
});

Route_details.hasOne(Track_driver, {
  foreignKey: "route_id",
});

Track_driver.belongsTo(Route_details, {
  foreignKey: "route_id",
});

module.exports = Track_driver;
