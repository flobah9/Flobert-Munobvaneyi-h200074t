const { DataTypes } = require("sequelize");
const db = require("../config/conn");
const Route_details = require("./Route_details");

const Feedback = db.define(
  "feedback",
  {
    uuid: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      allowNull: false,
      validate: {
        notEmpty: true,
      },
    },
    route_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    traffic: {
      type: DataTypes.ENUM(
        "Light Traffic",
        "Moderate Traffic",
        "Heavy Traffic"
      ),
      allowNull: false,
    },
    condition: {
      type: DataTypes.ENUM("Good", "Damaged", "Broken"),
      allowNull: false,
    },
    report: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  },
  { freezeTableName: true }
);

Route_details.hasOne(Feedback, {
  foreignKey: "route_id",
});

Feedback.belongsTo(Route_details, {
  foreignKey: "route_id",
});

module.exports = Feedback;
