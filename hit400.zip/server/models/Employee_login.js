const { DataTypes } = require("sequelize");
const bcrypt = require("bcrypt");
const db = require("../config/conn");
const Employee_details = require("./Employee_details");

const Employee_login = db.define(
  "employee_login_details",
  {
    uuid: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      allowNull: false,
      validate: {
        notEmpty: true,
      },
    },
    employee_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    password: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        isPasswordValid(value) {
          if (
            !/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(
              value
            )
          ) {
            throw new Error(
              "Password must contain at least 8 characters including uppercase, lowercase, and numeric characters."
            );
          }
        },
      },
      get() {
        return this.getDataValue("password");
      },
      set(value) {
        const hashedPassword = bcrypt.hashSync(value, bcrypt.genSaltSync(12));
        this.setDataValue("password", hashedPassword);
      },
    },
  },
  { freezeTableName: true }
);

Employee_details.hasOne(Employee_login, {
  foreignKey: "employee_id",
});

Employee_login.belongsTo(Employee_details, {
  foreignKey: "employee_id",
});

module.exports = Employee_login;
