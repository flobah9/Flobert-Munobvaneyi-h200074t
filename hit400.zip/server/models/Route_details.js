const { DataTypes } = require("sequelize");
const db = require("../config/conn");
const Order_details = require("./Order_details");
const Driver_details = require("./Driver_details");

const Route_details = db.define(
  "route_details",
  {
    uuid: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      allowNull: false,
      validate: {
        notEmpty: true,
      },
    },
    order_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    originLat: {
      type: DataTypes.DECIMAL(9, 6),
      allowNull: false,
    },
    originLng: {
      type: DataTypes.DECIMAL(9, 6),
      allowNull: false,
    },
    destinationLat: {
      type: DataTypes.DECIMAL(9, 6),
      allowNull: false,
    },
    destinationLng: {
      type: DataTypes.DECIMAL(9, 6),
      allowNull: false,
    },
    driver_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
  },
  {
    freezeTableName: true,
  }
);

Order_details.hasOne(Route_details, {
  foreignKey: "order_id",
});

Route_details.belongsTo(Order_details, {
  foreignKey: "order_id",
});

Driver_details.hasOne(Route_details, {
  foreignKey: "driver_id",
});

Route_details.belongsTo(Driver_details, {
  foreignKey: "driver_id",
});

module.exports = Route_details;
