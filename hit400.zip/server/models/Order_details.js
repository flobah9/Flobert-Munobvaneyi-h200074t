const { DataTypes } = require("sequelize");
const db = require("../config/conn");
const Employee_details = require("./Employee_details");
const Fleet_details = require("./Fleet_details");
const Customer_profile = require("./Customer_profile");

const Order_details = db.define(
  "order_details",
  {
    uuid: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      allowNull: false,
      validate: {
        notEmpty: true,
      },
    },
    orderID: {
      type: DataTypes.STRING,
      allowNull: true,
      unique: true,
    },
    customerID: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    loadType: {
      type: DataTypes.ENUM("Light", "Medium", "Heavy"),
      allowNull: false,
    },
    order_details: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    estimated_weight: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    scheduled_delivery_time: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    status: {
      type: DataTypes.ENUM("Pending", "Assigned", "Cancelled", "Completed"),
      allowNull: false,
    },
    fleet_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    employee_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
  },
  { freezeTableName: true }
);

Fleet_details.hasMany(Order_details, {
  foreignKey: "fleet_id",
});

Order_details.belongsTo(Fleet_details, {
  foreignKey: "fleet_id",
});

Employee_details.hasMany(Order_details, {
  foreignKey: "employee_id",
});

Order_details.belongsTo(Employee_details, {
  foreignKey: "employee_id",
});

Customer_profile.hasMany(Order_details, {
  sourceKey: "customerID",
  foreignKey: "customerID",
});

Order_details.belongsTo(Customer_profile, {
  foreignKey: "customerID",
  targetKey: "customerID",
});

module.exports = Order_details;
