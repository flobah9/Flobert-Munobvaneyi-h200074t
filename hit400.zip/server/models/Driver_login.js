const { DataTypes } = require("sequelize");
const bcrypt = require("bcrypt");
const db = require("../config/conn");
const Driver_details = require("./Driver_details");

const Driver_login = db.define(
  "driver_login_details",
  {
    uuid: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      allowNull: false,
      validate: {
        notEmpty: true,
      },
    },
    driver_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    password: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        isPasswordValid(value) {
          if (
            /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(
              value
            )
          ) {
            throw new Error(
              "Password must contain at least 8 characters including uppercase, lowercase, and numeric characters."
            );
          }
        },
      },
      get() {
        return this.getDataValue("password");
      },
      set(value) {
        const hashedPassword = bcrypt.hashSync(value, bcrypt.genSaltSync(12));
        this.setDataValue("password", hashedPassword);
      },
    },
  },
  { freezeTableName: true }
);

Driver_details.hasOne(Driver_login, {
  foreignKey: "driver_id",
});

Driver_login.belongsTo(Driver_details, {
  foreignKey: "driver_id",
});

module.exports = Driver_login;
