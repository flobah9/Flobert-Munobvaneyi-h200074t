const Driver_details = require("../models/Driver_details");
const Employee_details = require("../models/Employee_details");

const verifyUser = async (req, res, next) => {
  try {
    // Validate session existence:
    if (!req.session) {
      return res.status(401).json({ msg: "Please login to your account!" });
    }

    // Handle missing userId in session:
    if (!req.session.userId) {
      req.session.destroy(); // Clear potentially invalid session
      return res
        .status(401)
        .json({ msg: "Unauthorized: Missing user ID in session." });
    }

    const user = await Employee_details.findOne({
      where: {
        uuid: req.session.userId,
      },
    });

    // Handle user not found:
    if (!user) {
      return res.status(401).json({ msg: "Unauthorized: User not found." });
    }

    // Set user data on request object:
    req.userId = user.id;
    req.role = user.role;

    // Call next middleware function:
    next();
  } catch (error) {
    console.error(error); // Log the error for debugging
    res.status(500).json({ msg: "Internal server error." });
  }
};

const adminOnly = async (req, res, next) => {
  const user = await Employee_details.findOne({
    where: {
      uuid: req.session.userId,
    },
  });
  if (!user) return res.status(404).json({ msg: "User not found" });
  if (user.role !== "Admin")
    return res.status(403).json({ msg: "Access forbidden" });
  next();
};

const driverOnly = async (req, res, next) => {
  try {
    // Validate session existence:
    if (!req.session) {
      return res.status(401).json({ msg: "Please login to your account!" });
    }

    // Handle missing userId in session:
    if (!req.session.driverId) {
      req.session.destroy(); // Clear potentially invalid session
      return res
        .status(401)
        .json({ msg: "Unauthorized: Missing user ID in session." });
    }

    const driver = await Driver_details.findOne({
      where: {
        uuid: req.session.driverId,
      },
    });

    // Handle user not found:
    if (!driver) {
      return res.status(401).json({ msg: "Unauthorized: Driver not found." });
    }

    // Set user data on request object:
    req.driverId = driver.id;
    req.licence_no = driver.licence_no;
    next();
  } catch (error) {
    console.error(error); // Log the error for debugging
    res.status(500).json({ msg: "Internal server error." });
  }
};

module.exports = { verifyUser, adminOnly, driverOnly };
