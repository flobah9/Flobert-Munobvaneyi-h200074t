const express = require("express");
const { verifyUser, adminOnly } = require("../middleware/auth");
const {
  AddCompanyDetails,
  GetCompanyProfile,
  UpdateCompanyProfile,
} = require("../controllers/Company");

const router = express.Router();

router.post("/add", verifyUser, adminOnly, AddCompanyDetails);
router.get("/view", verifyUser, GetCompanyProfile);
router.patch("/update/:id", verifyUser, adminOnly, UpdateCompanyProfile);

module.exports = router;
