const express = require("express");
const { driverOnly } = require("../middleware/auth");
const {
  UpdateMyCurrentLocation,
  TrackDriverLocation,
  AddMyLocation,
  GetMyLocation,
  FinishMyTravel,
} = require("../controllers/Tracking");

const router = express.Router();

router.post("/mylocation", driverOnly, AddMyLocation);
router.patch("/mylocation/:id", driverOnly, UpdateMyCurrentLocation);
router.patch("/finallocation/:id", driverOnly, FinishMyTravel);
router.get("/location", TrackDriverLocation);
router.get("/location/:id", driverOnly, GetMyLocation);

module.exports = router;
