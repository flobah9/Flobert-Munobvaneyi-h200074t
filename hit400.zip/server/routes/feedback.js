const express = require("express");
const { driverOnly } = require("../middleware/auth");
const { AddFeedback } = require("../controllers/Feedback");

const router = express.Router();

router.post("/add", driverOnly, AddFeedback);

module.exports = router;
