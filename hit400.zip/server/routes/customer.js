const express = require("express");
const { verifyUser } = require("../middleware/auth");
const {
  AddNewCustomer,
  GetAllCustomers,
  UpdateCustomerPriofile,
  GetCustomerByID,
  CountAllCustomers,
} = require("../controllers/Customer");
const { CustomerDetailValidation } = require("../helpers/customerValidation");

const router = express.Router();

router.post("/add", verifyUser, CustomerDetailValidation, AddNewCustomer);
router.get("/all", verifyUser, GetAllCustomers);
router.get("/view/:customerID", verifyUser, GetCustomerByID);
router.get("/count", verifyUser, CountAllCustomers);
router.patch(
  "/update/:id",
  verifyUser,
  CustomerDetailValidation,
  UpdateCustomerPriofile
);

module.exports = router;
