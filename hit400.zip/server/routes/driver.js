const express = require("express");
const { DriverDetailValidation } = require("../helpers/driverValidation");
const { verifyUser, adminOnly, driverOnly } = require("../middleware/auth");
const {
  AddNewDriver,
  GetAllDrivers,
  UpdateDriver,
  CountAllDrivers,
  DriverCountTotalAssigned,
  DriverCountCompleted,
} = require("../controllers/Driver");

const router = express.Router();

router.post(
  "/add",
  verifyUser,
  adminOnly,
  DriverDetailValidation,
  AddNewDriver
);
router.get("/all", verifyUser, GetAllDrivers);
router.get("/count", verifyUser, CountAllDrivers);
router.patch(
  "/update:/id",
  verifyUser,
  adminOnly,
  DriverDetailValidation,
  UpdateDriver
);
router.get("/countall", driverOnly, DriverCountTotalAssigned);
router.get("/countfull", driverOnly, DriverCountCompleted);

module.exports = router;
