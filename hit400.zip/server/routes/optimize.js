const express = require("express");
const { driverOnly } = require("../middleware/auth");
const {
  AssignedOptimizedRoute,
  OptimizeRoute,
} = require("../controllers/Route_optimize");

const router = express.Router();

router.get("/view", driverOnly, AssignedOptimizedRoute);
router.get("/view/:id", driverOnly, OptimizeRoute);

module.exports = router;
