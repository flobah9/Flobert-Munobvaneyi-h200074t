const express = require("express");
const { verifyUser, adminOnly } = require("../middleware/auth");
const {
  CreateAnOrder,
  ViewAllOrders,
  CountAllOrders,
  CountCompletedOrders,
  AssignFleetToOrder,
  CancelOrder,
  OrderVsFleet,
  OrderVsDriver,
} = require("../controllers/Order");

const router = express.Router();

router.post("/create", verifyUser, CreateAnOrder);
router.get("/all", verifyUser, ViewAllOrders);
router.get("/count", verifyUser, CountAllOrders);
router.get("/countfull", verifyUser, CountCompletedOrders);
router.get("/graph", verifyUser, OrderVsFleet);
router.get("/graphdriver", verifyUser, OrderVsDriver);
router.patch("/assign/:id", verifyUser, adminOnly, AssignFleetToOrder);
router.patch("/cancel/:id", verifyUser, adminOnly, CancelOrder);

module.exports = router;
