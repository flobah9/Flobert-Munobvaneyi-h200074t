const express = require("express");
const { FleetDetailValidation } = require("../helpers/fleetValidation");
const { verifyUser, adminOnly } = require("../middleware/auth");
const {
  RegisterFleet,
  UpdateFleet,
  GetAllFleet,
  CountAllFleet,
} = require("../controllers/Fleet");

const router = express.Router();

router.post(
  "/add",
  verifyUser,
  adminOnly,
  FleetDetailValidation,
  RegisterFleet
);
router.patch(
  "/update:id",
  verifyUser,
  adminOnly,
  FleetDetailValidation,
  UpdateFleet
);
router.get("/all", verifyUser, GetAllFleet);
router.get("/count", verifyUser, CountAllFleet);

module.exports = router;
