const express = require("express");
const { EmployeeDetailValidation } = require("../helpers/employeeValidation");
const {
  AddNewEmployee,
  GetAllEmployee,
  UpdateEmployee,
  GetEmployeeById,
} = require("../controllers/Employees");
const { verifyUser, adminOnly } = require("../middleware/auth");

const router = express.Router();

router.post(
  "/add",
  verifyUser,
  adminOnly,
  EmployeeDetailValidation,
  AddNewEmployee
);
router.get("/all", verifyUser, GetAllEmployee);
router.get("/view/:id", verifyUser, GetEmployeeById);
router.patch(
  "/update/:id",
  verifyUser,
  EmployeeDetailValidation,
  UpdateEmployee
);

module.exports = router;
