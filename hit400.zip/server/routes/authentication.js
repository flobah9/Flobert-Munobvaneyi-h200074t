const express = require("express");
const { EmployeeLoginValidation } = require("../helpers/employeeValidation");
const {
  SignUpEmployee,
  LoginEmployee,
  LogoutEmployee,
  LoginDriver,
  SignUpDriver,
} = require("../controllers/Authentication");
const { DriverSignInValidation } = require("../helpers/driverValidation");

const router = express.Router();

router.post("/signup", EmployeeLoginValidation, SignUpEmployee);
router.post("/signin", EmployeeLoginValidation, LoginEmployee);
router.post("/login", DriverSignInValidation, LoginDriver);
router.post("/create", DriverSignInValidation, SignUpDriver);
router.delete("/logout", LogoutEmployee);

module.exports = router;
