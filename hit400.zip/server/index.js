require("dotenv").config(); // Load environment variables
const express = require("express");
const cors = require("cors");
const db = require("./config/conn");
var session = require("express-session");
const bodyParser = require("body-parser");
const SequelizeStore = require("connect-session-sequelize");

const authRouter = require("./routes/authentication");
const employeeRouter = require("./routes/employee");
const companyRouter = require("./routes/company");
const customerRouter = require("./routes/customer");
const driverRouter = require("./routes/driver");
const fleetRouter = require("./routes/fleet");
const orderRouter = require("./routes/order");
const optimizeRouter = require("./routes/optimize");
const trackRouter = require("./routes/track");
const feedRouter = require("./routes/feedback");

db.sync()
  .then(() => console.log("Database connection successful"))
  .catch((error) => console.error(error));

const app = express();

const PORT = process.env.APP_PORT || 5000;

const sessionStore = SequelizeStore(session.Store);
const store = new sessionStore({
  db: db,
});

//session
app.use(
  session({
    secret: process.env.SESS_SECRET,
    resave: false,
    saveUninitialized: true,
    store: store,
    cookie: {
      secure: false,
    },
  })
);

const corsOptions = {
  origin: process.env.CLIENT_URL,
  methods: ["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"],
  allowedHeaders: [
    "Content-Type",
    "Origin",
    "X-Requested-With",
    "Accept",
    "x-client-key",
    "x-client-token",
    "x-client-secret",
    "Authorization",
  ],
  credentials: true,
};

app.use(cors(corsOptions));

app.use(bodyParser.json());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/auth", authRouter);
app.use("/employee", employeeRouter);
app.use("/company", companyRouter);
app.use("/customer", customerRouter);
app.use("/driver", driverRouter);
app.use("/fleet", fleetRouter);
app.use("/order", orderRouter);
app.use("/path", optimizeRouter);
app.use("/track", trackRouter);
app.use("/feed", feedRouter);

//error handling
app.use((err, req, res, next) => {
  err.statusCode = err.statusCode || 500;
  err.message = err.message || "Internal Server Error";
  res.status(err.statusCode).json({
    message: err.message,
  });
});

const startServer = async () => {
  try {
    app.listen(PORT, () =>
      console.log(`Server is up and running on port ${PORT}`)
    );
  } catch (error) {
    console.log(error);
  }
};

startServer();
