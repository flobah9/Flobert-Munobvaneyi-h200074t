-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 24, 2024 at 08:34 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dms`
--

-- --------------------------------------------------------

--
-- Table structure for table `company_profile`
--

CREATE TABLE `company_profile` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `companyName` varchar(255) NOT NULL,
  `phoneNumber` varchar(255) NOT NULL,
  `emailAddress` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `lng` decimal(9,6) NOT NULL,
  `lat` decimal(9,6) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `company_profile`
--

INSERT INTO `company_profile` (`id`, `uuid`, `companyName`, `phoneNumber`, `emailAddress`, `location`, `lng`, `lat`, `createdAt`, `updatedAt`) VALUES
(1, '5d87f0ec-a633-46ff-83a6-e6b8da203d05', 'Bebe Sw', '263776419969', 'flobert@tsoretec.com', '39 Lawley belvedere', 30.999092, -17.841770, '2024-04-14 23:17:15', '2024-04-14 23:17:15');

-- --------------------------------------------------------

--
-- Table structure for table `customer_id`
--

CREATE TABLE `customer_id` (
  `id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer_id`
--

INSERT INTO `customer_id` (`id`) VALUES
(1),
(2),
(3),
(4);

-- --------------------------------------------------------

--
-- Table structure for table `customer_profile`
--

CREATE TABLE `customer_profile` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `customerID` varchar(255) DEFAULT NULL,
  `customerName` varchar(255) NOT NULL,
  `emailAddress` varchar(255) NOT NULL,
  `phoneNumber` varchar(255) NOT NULL,
  `preferences` varchar(255) DEFAULT NULL,
  `location` varchar(255) NOT NULL,
  `lng` decimal(9,6) NOT NULL,
  `lat` decimal(9,6) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer_profile`
--

INSERT INTO `customer_profile` (`id`, `uuid`, `customerID`, `customerName`, `emailAddress`, `phoneNumber`, `preferences`, `location`, `lng`, `lat`, `createdAt`, `updatedAt`) VALUES
(1, '98ea8a8a-4667-43bb-8e38-f08261d568f1', 'DMSC0001', 'Mining Company', 'flobymunobvaneyi@gmail.com', '263776413567', 'Bulldozers, shifts', '256 Arcturus road, Harare Greendale', 31.141740, -17.809189, '2024-04-16 21:34:45', '2024-04-16 21:34:45'),
(2, 'd7008801-10e2-4d81-8242-866cf7fe3b62', 'DMSC0002', 'SimpleTechnology', 'takuganda@gmail.com', '263717705971', 'IT tools, stationary', 'Bindura', 31.332178, -17.296975, '2024-04-16 21:37:42', '2024-04-16 21:37:42'),
(3, '84916f6e-1d31-4e18-93a0-c7bc15d288fc', 'DMSC0003', 'Bebe AgriFarm', 'sirbebefam@gmail.com', '263777122018', 'tractors, discs, rakes', 'Shamva', 31.579709, -17.312595, '2024-04-16 21:39:36', '2024-04-16 21:39:36'),
(4, '5f9cc2c6-ad65-4f3c-bd86-75cce562c772', 'DMSC0004', 'Tecbytes', 'ifixbee@tecbytes.com', '263777712345', 'IT components', 'Avondale Nando building', 31.038735, -17.803067, '2024-04-29 12:47:47', '2024-04-29 12:47:47');

--
-- Triggers `customer_profile`
--
DELIMITER $$
CREATE TRIGGER `getCustomerId` BEFORE INSERT ON `customer_profile` FOR EACH ROW BEGIN
	INSERT INTO customer_id VALUES (NULL);
    SET NEW.customerID =  CONCAT("DMSC",LPAD(LAST_INSERT_ID(),4,"0"));
    END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `driver_login_details`
--

CREATE TABLE `driver_login_details` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `driver_id` int(11) NOT NULL,
  `password` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `driver_login_details`
--

INSERT INTO `driver_login_details` (`id`, `uuid`, `driver_id`, `password`, `createdAt`, `updatedAt`) VALUES
(1, '0e84a7d4-4683-4c9f-8e15-f21e66b265bf', 2, '$2b$12$YLu4B.p15JUNvVjGoKM.NeLLtyENNaWpT9mXwPs1U81OhTbwepUEO', '2024-04-18 01:59:37', '2024-04-18 01:59:37'),
(2, 'eb453eb6-1258-4b4b-8705-acb2e5278b57', 1, '$2b$12$RnqGKqIR6XtZEwMRwYMia./hJ4XLaB/X7izIe/GbI/RmFDDOJcyl.', '2024-04-29 13:02:47', '2024-04-29 13:02:47'),
(3, 'd47d1f77-7a4e-4b4b-8980-f73c90827923', 5, '$2b$12$Zq9/J.Q/JrMQyHuMm9aj6OoLwAQqwAQbHbnikNysL6XFfQG94waXG', '2024-04-29 13:04:16', '2024-04-29 13:04:16');

-- --------------------------------------------------------

--
-- Table structure for table `driver_personal_details`
--

CREATE TABLE `driver_personal_details` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `ID_number` varchar(255) NOT NULL,
  `licence_no` varchar(255) NOT NULL,
  `homeAddress` varchar(255) NOT NULL,
  `emailAddress` varchar(255) NOT NULL,
  `phoneNumber` varchar(255) NOT NULL,
  `fleet_id` int(11) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `driver_personal_details`
--

INSERT INTO `driver_personal_details` (`id`, `uuid`, `firstName`, `lastName`, `ID_number`, `licence_no`, `homeAddress`, `emailAddress`, `phoneNumber`, `fleet_id`, `createdAt`, `updatedAt`) VALUES
(1, 'd46bcf4c-803c-4a2d-b7af-67a0cf9725e6', 'Mutsa', 'Floby', '56-23457u56', 'ABC123456', 'Bindura', 'manflobah9@gmail.com', '263784711808', 2, '2024-04-18 01:53:57', '2024-04-18 01:53:57'),
(2, '3cb0549f-2905-4bd2-84a7-9fc46d471e0c', 'Wabantu', 'Bhebhe', '63-203456q47', 'ADC654321', 'Belvedere', 'manlikebebe9@gmail.com', '263713075783', 6, '2024-04-18 01:55:22', '2024-04-18 01:55:22'),
(3, 'b35abe30-a35b-43b3-a5bc-df28e99f8e82', 'Junier ', 'Doe', '45-2233567q47', 'AJK123456', '256 Arcturus road Greendale', 'juniourjanejoe@gmail.com', '263772466385', 4, '2024-04-28 14:38:15', '2024-04-28 14:38:15'),
(4, 'dc9a0d10-0b2a-46d6-b0f3-09dd91820d8c', 'Nelson', 'Nyariri', '05-0089123a87', 'AWS123456', 'Chipadze Bindura', 'nyaririnelson@gmail.com', '263713321191', 5, '2024-04-28 14:43:40', '2024-04-28 14:43:40'),
(5, 'a0045ba4-c8d5-4774-b903-d21e79e76478', 'Tapiwa', 'Taps', '25-9966098b67', 'AHI456789', 'Goromonzi', 'tapiwamherembi@gmail.com', '260764592355', 3, '2024-04-28 14:47:02', '2024-04-28 14:47:02'),
(6, '00eec74a-4fe0-4c04-aa81-77f23e8b798c', 'Tinashe', 'Goso', '05-3311348n47', 'AST089674', 'Anorld Farm Mazowe', 'tinashegoso@gmail.com', '263717540137', 7, '2024-04-28 15:00:04', '2024-04-28 15:00:04');

-- --------------------------------------------------------

--
-- Table structure for table `employee_login_details`
--

CREATE TABLE `employee_login_details` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `employee_id` int(11) NOT NULL,
  `password` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee_login_details`
--

INSERT INTO `employee_login_details` (`id`, `uuid`, `employee_id`, `password`, `createdAt`, `updatedAt`) VALUES
(1, 'f4ca449e-769d-4ece-893f-48f581a7770d', 1, '$2b$12$tc1epWy1jGc4JuEs2IRcwuuPmZvwH2ee4Ckmv5sraAkieOKzsgF9q', '2024-03-26 13:22:23', '2024-03-26 13:22:23'),
(2, 'bbb913e4-0327-4066-a9a8-08b836dc3db7', 2, '$2b$12$aon4r1Eol3Ued87L6hIZGuanGMo99SQKbIYevwVAqjNKmD82v6bFG', '2024-04-01 19:33:13', '2024-04-01 19:33:13');

-- --------------------------------------------------------

--
-- Table structure for table `employee_personal_details`
--

CREATE TABLE `employee_personal_details` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `ID_number` varchar(255) NOT NULL,
  `homeAddress` varchar(255) NOT NULL,
  `emailAddress` varchar(255) NOT NULL,
  `phoneNumber` varchar(255) NOT NULL,
  `role` enum('Admin','User') NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee_personal_details`
--

INSERT INTO `employee_personal_details` (`id`, `uuid`, `firstName`, `lastName`, `ID_number`, `homeAddress`, `emailAddress`, `phoneNumber`, `role`, `createdAt`, `updatedAt`) VALUES
(1, '31bbc82a-c4b0-4227-a827-abe4723e078e', 'Bebe', 'Wabantu', '63-2200430q47', '39 Lawley belvedere', 'manflobah9@gmail.com', '263784711808', 'Admin', '2024-03-26 12:50:03', '2024-03-26 12:50:03'),
(2, 'c1604be1-4f63-42e9-bdc7-242f842752d8', 'Floby', 'Munoz', '63-2200235e85', '18 Catalina Road Belvedere', 'manlikebebe9@gmail.com', '263713075783', 'User', '2024-03-26 13:41:06', '2024-04-01 18:37:57'),
(3, 'c67bc4ce-7364-4477-aac7-06fb14d3f843', 'Alexis', 'Bhima', '63-2200123d67', 'Chitungwiza', 'alexisbmw@gmail.com', '263777122018', 'User', '2024-04-01 18:45:51', '2024-05-16 22:54:15'),
(4, 'e43c8b6b-1c3e-451a-b48c-0968ba1b2bba', 'Panashe', 'Office', '33-0022450q47', 'Chitungwiza', 'panaoffice@gmail.com', '263717509964', 'User', '2024-05-16 22:49:25', '2024-05-16 22:49:25');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `route_id` int(11) NOT NULL,
  `traffic` enum('Light Traffic','Moderate Traffic','Heavy Traffic') NOT NULL,
  `condition` enum('Good','Damaged','Broken') NOT NULL,
  `report` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `uuid`, `route_id`, `traffic`, `condition`, `report`, `createdAt`, `updatedAt`) VALUES
(1, '8baaa4ed-91dc-4631-94bc-f8beabd95fae', 1, 'Moderate Traffic', 'Good', 'rsdtrytfuyjhgfhjg', '2024-04-29 12:10:07', '2024-04-29 12:10:07'),
(2, 'f61289b1-4f3f-4be9-b276-2665cd9e7cc5', 2, 'Moderate Traffic', 'Good', 'police stops', '2024-05-01 13:50:15', '2024-05-01 13:50:15'),
(3, '23285e1e-3c25-4a3f-8072-5540948bfa46', 3, 'Moderate Traffic', 'Good', 'rtyujik', '2024-05-02 15:45:54', '2024-05-02 15:45:54');

-- --------------------------------------------------------

--
-- Table structure for table `fleet_details`
--

CREATE TABLE `fleet_details` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `fleetNo` varchar(255) DEFAULT NULL,
  `make` varchar(255) NOT NULL,
  `class` enum('Light','Medium','Heavy') NOT NULL,
  `engine_size` int(7) NOT NULL,
  `payload_capacity` int(8) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fleet_details`
--

INSERT INTO `fleet_details` (`id`, `uuid`, `fleetNo`, `make`, `class`, `engine_size`, `payload_capacity`, `createdAt`, `updatedAt`) VALUES
(1, '256843d1-9567-4834-96cb-016cba96d1b7', 'DMST0001', 'Ford F-650/F-750', 'Medium', 2080, 13154, '2024-04-12 20:48:12', '2024-04-12 20:48:12'),
(2, 'd05bbab3-0fa1-4bfe-8bb8-d13c33bb8fe7', 'DMST0002', 'Volvo', 'Heavy', 3400, 17612, '2024-04-12 20:49:05', '2024-04-12 20:49:05'),
(3, 'b79289e4-40a2-4e07-a23d-6f61c384362f', 'DMST0003', 'Ford F-250', 'Light', 2389, 1814, '2024-04-16 11:21:29', '2024-04-16 11:21:29'),
(4, 'f2c42c9b-258f-4146-8784-10444b9c181e', 'DMST0004', 'Chevrolet Silverado 4500/5500 HD', 'Medium', 2345, 10000, '2024-04-16 21:19:17', '2024-04-16 21:19:17'),
(5, '6e754a8d-05fb-4a73-92bc-1775001ae9af', 'DMST0005', 'Mahindra Truxo 31', 'Heavy', 3450, 17809, '2024-04-16 21:23:02', '2024-04-16 21:23:02'),
(6, '16ca80ac-3fc5-41fa-977e-741c74af31af', 'DMST0006', 'Nissan NV200', 'Light', 1875, 4780, '2024-04-16 21:26:01', '2024-04-16 21:26:01'),
(7, 'd3a0180e-052f-469b-96a8-8df21fdb00f8', 'DMST0007', 'Toyota Tundra i-FORCE MAX', 'Light', 4, 750, '2024-04-28 14:54:19', '2024-04-28 14:54:19');

--
-- Triggers `fleet_details`
--
DELIMITER $$
CREATE TRIGGER `getFleetId` BEFORE INSERT ON `fleet_details` FOR EACH ROW BEGIN
	INSERT INTO fleet_id VALUES (NULL);
    SET NEW.fleetNo =  CONCAT("DMST",LPAD(LAST_INSERT_ID(),4,"0"));
    END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `fleet_id`
--

CREATE TABLE `fleet_id` (
  `id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fleet_id`
--

INSERT INTO `fleet_id` (`id`) VALUES
(1),
(2),
(3),
(4),
(5),
(6),
(7);

-- --------------------------------------------------------

--
-- Table structure for table `fleet_status`
--

CREATE TABLE `fleet_status` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `fleet_id` int(11) NOT NULL,
  `status` enum('On-duty','Off-duty') NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fleet_status`
--

INSERT INTO `fleet_status` (`id`, `uuid`, `fleet_id`, `status`, `createdAt`, `updatedAt`) VALUES
(1, 'f98eba6b-31ca-46ce-b053-d9e81400d919', 2, 'Off-duty', '2024-04-18 01:53:57', '2024-05-01 13:49:45'),
(2, 'af979d09-f9df-4f20-8a72-eb6e624d3d19', 6, 'Off-duty', '2024-04-18 01:55:23', '2024-05-02 15:48:02'),
(3, '9f385c1a-a924-49ce-be27-320b3d7de8e3', 4, 'Off-duty', '2024-04-28 14:38:15', '2024-04-28 14:38:15'),
(4, 'd7d3bc7b-94bf-47df-8f28-0a71eb8bc889', 5, 'Off-duty', '2024-04-28 14:43:41', '2024-04-28 14:43:41'),
(5, '4eac4ad5-2caa-46b5-aef4-455edbaf1e5a', 3, 'Off-duty', '2024-04-28 14:47:02', '2024-05-02 15:45:27'),
(6, '36dc9a87-4043-45ad-bac1-ac06a1914d71', 7, 'On-duty', '2024-04-28 15:00:04', '2024-04-29 12:54:42');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `orderID` varchar(255) DEFAULT NULL,
  `customerID` varchar(255) NOT NULL,
  `loadType` enum('Light','Medium','Heavy') NOT NULL,
  `order_details` varchar(255) NOT NULL,
  `estimated_weight` int(8) NOT NULL,
  `scheduled_delivery_time` datetime NOT NULL,
  `status` enum('Pending','Assigned','Cancelled','Completed') NOT NULL,
  `fleet_id` int(11) DEFAULT NULL,
  `employee_id` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`id`, `uuid`, `orderID`, `customerID`, `loadType`, `order_details`, `estimated_weight`, `scheduled_delivery_time`, `status`, `fleet_id`, `employee_id`, `createdAt`, `updatedAt`) VALUES
(1, '25ac85b9-2061-4b5e-a12f-e901e52a4e89', 'DMSO0001', 'DMSC0002', 'Light', 'Stationery, laptops, printers', 1200, '2024-04-19 09:00:00', 'Completed', 6, 2, '2024-04-18 01:57:17', '2024-04-29 12:09:58'),
(2, 'd4253972-cf12-41e9-98cf-cc680ca5c5f7', 'DMSO0002', 'DMSC0003', 'Heavy', 'Tractor, discs', 10000, '2024-04-25 13:00:00', 'Completed', 2, 2, '2024-04-20 01:47:15', '2024-05-01 13:49:45'),
(3, '6a62e828-452e-44a5-9a4f-e151acb74e42', 'DMSO0003', 'DMSC0004', 'Light', 'printers, bond papers and laptops', 576, '2024-05-02 13:15:00', 'Completed', 3, 2, '2024-04-29 12:51:24', '2024-05-02 15:45:27'),
(4, '41467e1d-763b-47dd-8556-eaa2cf3ae603', 'DMSO0004', 'DMSC0002', 'Light', 'Laser printers', 679, '2024-05-02 13:45:00', 'Assigned', 7, 2, '2024-04-29 12:54:41', '2024-04-29 12:54:41'),
(5, '926e9f70-f4a8-4ed4-9451-0c9882d1c927', 'DMSO0005', 'DMSC0002', 'Light', 'Laptops, desktops, stationery', 1200, '2024-05-02 15:30:00', 'Completed', 6, 2, '2024-04-29 12:56:30', '2024-05-02 15:48:02');

--
-- Triggers `order_details`
--
DELIMITER $$
CREATE TRIGGER `getCustID` BEFORE INSERT ON `order_details` FOR EACH ROW BEGIN
	INSERT INTO order_id VALUES (NULL);
    SET NEW.orderID =  CONCAT("DMSO",LPAD(LAST_INSERT_ID(),4,"0"));
    END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `order_id`
--

CREATE TABLE `order_id` (
  `id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_id`
--

INSERT INTO `order_id` (`id`) VALUES
(1),
(2),
(3),
(4),
(5);

-- --------------------------------------------------------

--
-- Table structure for table `route_details`
--

CREATE TABLE `route_details` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `order_id` int(11) NOT NULL,
  `originLat` decimal(9,6) NOT NULL,
  `originLng` decimal(9,6) NOT NULL,
  `destinationLat` decimal(9,6) NOT NULL,
  `destinationLng` decimal(9,6) NOT NULL,
  `driver_id` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `route_details`
--

INSERT INTO `route_details` (`id`, `uuid`, `order_id`, `originLat`, `originLng`, `destinationLat`, `destinationLng`, `driver_id`, `createdAt`, `updatedAt`) VALUES
(1, '728bb98e-6b2d-4604-9994-139de42a578d', 1, -17.841770, 30.999092, -17.296975, 31.332178, 2, '2024-04-18 01:57:18', '2024-04-18 01:57:18'),
(2, '1aed6165-79d6-41ac-a600-09830fb80b1e', 2, -17.841770, 30.999092, -17.312595, 31.579709, 1, '2024-04-20 01:47:16', '2024-04-20 01:47:16'),
(3, 'c238a1b8-379e-4031-96e0-70eb8a90aee4', 3, -17.841770, 30.999092, -17.803067, 31.038735, 5, '2024-04-29 12:51:27', '2024-04-29 12:51:27'),
(4, '9cd81f99-2f42-403b-a5d0-352b76b1f136', 4, -17.841770, 30.999092, -17.296975, 31.332178, 6, '2024-04-29 12:54:42', '2024-04-29 12:54:42'),
(5, '21876fbf-3bb9-4ec1-bd9d-cd555ab5154c', 5, -17.841770, 30.999092, -17.296975, 31.332178, 2, '2024-04-29 12:56:30', '2024-04-29 12:56:30');

-- --------------------------------------------------------

--
-- Table structure for table `Sessions`
--

CREATE TABLE `Sessions` (
  `sid` varchar(36) NOT NULL,
  `expires` datetime DEFAULT NULL,
  `data` text DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Sessions`
--

INSERT INTO `Sessions` (`sid`, `expires`, `data`, `createdAt`, `updatedAt`) VALUES
('-sKJCaZYIZ_IPLXDTP2uXl7AxZdTpDRN', '2024-05-17 22:49:25', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-05-16 22:49:25', '2024-05-16 22:49:25'),
('GKL4e8gN_65PVr2Pz8cKwOJMHSRXdRKH', '2024-05-17 22:54:15', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"},\"userId\":\"31bbc82a-c4b0-4227-a827-abe4723e078e\"}', '2024-05-16 22:47:06', '2024-05-16 22:54:15'),
('t0JXwcmeLc0ymvbPvHzFqcQopQCZ6H0V', '2024-05-17 22:47:05', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-05-16 22:47:05', '2024-05-16 22:47:05'),
('wQy14HlPu1LyfAW7ZOt4JaJYg0ra2ykO', '2024-05-17 22:54:14', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-05-16 22:54:14', '2024-05-16 22:54:14');

-- --------------------------------------------------------

--
-- Table structure for table `track_driver`
--

CREATE TABLE `track_driver` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `driver_id` int(11) NOT NULL,
  `route_id` int(11) NOT NULL,
  `lng` decimal(9,6) NOT NULL,
  `lat` decimal(9,6) NOT NULL,
  `status` enum('Pending','Delivered') NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `track_driver`
--

INSERT INTO `track_driver` (`id`, `uuid`, `driver_id`, `route_id`, `lng`, `lat`, `status`, `createdAt`, `updatedAt`) VALUES
(1, 'a14d0cf6-5c1c-4dfe-894f-153a746d89f6', 2, 1, 31.332178, -17.296975, 'Delivered', '2024-04-29 12:08:12', '2024-04-29 12:09:58'),
(2, '923b728b-f675-4c06-8965-8eea65e85277', 1, 2, 31.579709, -17.312595, 'Delivered', '2024-05-01 13:47:30', '2024-05-01 13:49:45'),
(3, '8ece2f3d-ab5d-4fad-ab97-b3384f432b83', 5, 3, 31.038735, -17.803067, 'Delivered', '2024-05-02 15:44:31', '2024-05-02 15:45:27'),
(4, '3f097778-65ce-4c6d-ad91-bda81eec0a21', 2, 5, 31.332178, -17.296975, 'Delivered', '2024-05-02 15:46:36', '2024-05-02 15:48:02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `company_profile`
--
ALTER TABLE `company_profile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer_id`
--
ALTER TABLE `customer_id`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer_profile`
--
ALTER TABLE `customer_profile`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `customerID` (`customerID`);

--
-- Indexes for table `driver_login_details`
--
ALTER TABLE `driver_login_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `driver_id` (`driver_id`);

--
-- Indexes for table `driver_personal_details`
--
ALTER TABLE `driver_personal_details`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ID_number` (`ID_number`),
  ADD KEY `fleet_id` (`fleet_id`);

--
-- Indexes for table `employee_login_details`
--
ALTER TABLE `employee_login_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_id` (`employee_id`);

--
-- Indexes for table `employee_personal_details`
--
ALTER TABLE `employee_personal_details`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ID_number` (`ID_number`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`),
  ADD KEY `route_id` (`route_id`);

--
-- Indexes for table `fleet_details`
--
ALTER TABLE `fleet_details`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `fleetNo` (`fleetNo`);

--
-- Indexes for table `fleet_id`
--
ALTER TABLE `fleet_id`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fleet_status`
--
ALTER TABLE `fleet_status`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fleet_id` (`fleet_id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `orderID` (`orderID`),
  ADD KEY `customerID` (`customerID`),
  ADD KEY `fleet_id` (`fleet_id`),
  ADD KEY `employee_id` (`employee_id`);

--
-- Indexes for table `order_id`
--
ALTER TABLE `order_id`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `route_details`
--
ALTER TABLE `route_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `driver_id` (`driver_id`);

--
-- Indexes for table `Sessions`
--
ALTER TABLE `Sessions`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `track_driver`
--
ALTER TABLE `track_driver`
  ADD PRIMARY KEY (`id`),
  ADD KEY `driver_id` (`driver_id`),
  ADD KEY `route_id` (`route_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `company_profile`
--
ALTER TABLE `company_profile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customer_id`
--
ALTER TABLE `customer_id`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `customer_profile`
--
ALTER TABLE `customer_profile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `driver_login_details`
--
ALTER TABLE `driver_login_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `driver_personal_details`
--
ALTER TABLE `driver_personal_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `employee_login_details`
--
ALTER TABLE `employee_login_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `employee_personal_details`
--
ALTER TABLE `employee_personal_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `fleet_details`
--
ALTER TABLE `fleet_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `fleet_id`
--
ALTER TABLE `fleet_id`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `fleet_status`
--
ALTER TABLE `fleet_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `order_id`
--
ALTER TABLE `order_id`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `route_details`
--
ALTER TABLE `route_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `track_driver`
--
ALTER TABLE `track_driver`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `driver_login_details`
--
ALTER TABLE `driver_login_details`
  ADD CONSTRAINT `driver_login_details_ibfk_1` FOREIGN KEY (`driver_id`) REFERENCES `driver_personal_details` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `driver_personal_details`
--
ALTER TABLE `driver_personal_details`
  ADD CONSTRAINT `driver_personal_details_ibfk_1` FOREIGN KEY (`fleet_id`) REFERENCES `fleet_details` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `employee_login_details`
--
ALTER TABLE `employee_login_details`
  ADD CONSTRAINT `employee_login_details_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employee_personal_details` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`route_id`) REFERENCES `route_details` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `fleet_status`
--
ALTER TABLE `fleet_status`
  ADD CONSTRAINT `fleet_status_ibfk_1` FOREIGN KEY (`fleet_id`) REFERENCES `fleet_details` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `order_details`
--
ALTER TABLE `order_details`
  ADD CONSTRAINT `order_details_ibfk_1` FOREIGN KEY (`customerID`) REFERENCES `customer_profile` (`customerID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `order_details_ibfk_2` FOREIGN KEY (`fleet_id`) REFERENCES `fleet_details` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `order_details_ibfk_3` FOREIGN KEY (`employee_id`) REFERENCES `employee_personal_details` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `route_details`
--
ALTER TABLE `route_details`
  ADD CONSTRAINT `route_details_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `order_details` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `route_details_ibfk_2` FOREIGN KEY (`driver_id`) REFERENCES `driver_personal_details` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `track_driver`
--
ALTER TABLE `track_driver`
  ADD CONSTRAINT `track_driver_ibfk_1` FOREIGN KEY (`driver_id`) REFERENCES `driver_personal_details` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `track_driver_ibfk_2` FOREIGN KEY (`route_id`) REFERENCES `route_details` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
