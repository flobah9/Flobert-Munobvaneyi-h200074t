import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

const url = "http://127.0.0.1:5000/company";

const initialState = {
  company: null,
  isError: false,
  isSuccess: false,
  isLoading: false,
  message: "",
};

//api call to get company profile
export async function getCompanyProfile() {
  try {
    return await axios.get(`${url}/all`, { withCredentials: true });
  } catch (error) {
    console.log(error);
  }
}

//api call to register company profile
export const RegisterCompany = createAsyncThunk(
  "company/RegisterCompany",
  async (company_details, thunkAPI) => {
    try {
      const response = await axios.post(`${url}/add`, company_details, {
        withCredentials: true,
      });
      return response.data || response.msg;
    } catch (error) {
      if (error.response) {
        const message = error.response.data.msg;
        return thunkAPI.rejectWithValue(message);
      }
    }
  }
);

//api call to update company profile
export const UpdateCompanyProfile = createAsyncThunk(
  "company/UpdateCompanyProfile",
  async ({ id, company_details }, thunkAPI) => {
    try {
      const response = await axios.patch(
        `${url}/update/${id}`,
        company_details
      );
      return response.data || response.msg;
    } catch (error) {
      if (error.response) {
        const message = error.response.data.msg;
        return thunkAPI.rejectWithValue(message);
      }
    }
  }
);

export const companySlice = createSlice({
  name: "company",
  initialState,
  reducers: {
    reset: (state) => initialState,
  },
  extraReducers: (builder) => {
    //Add new company
    builder.addCase(RegisterCompany.pending, (state) => {
      state.isLoading = true;
    });
    builder.addCase(RegisterCompany.fulfilled, (state, action) => {
      state.isLoading = false;
      state.isSuccess = true;
      if (action.payload && action.payload.msg) {
        state.message = action.payload.msg;
      }
      if (action.payload) {
        state.company = action.payload;
      }
    });
    builder.addCase(RegisterCompany.rejected, (state, action) => {
      state.isLoading = false;
      state.isError = true;
      state.message = action.payload;
    });

    //update fleet details
    builder.addCase(UpdateCompanyProfile.pending, (state) => {
      state.isLoading = true;
    });
    builder.addCase(UpdateCompanyProfile.fulfilled, (state, action) => {
      state.isLoading = false;
      state.isSuccess = true;
      if (action.payload && action.payload.msg) {
        state.message = action.payload.msg;
      }
      if (action.payload) {
        state.company = action.payload;
      }
    });
    builder.addCase(UpdateCompanyProfile.rejected, (state, action) => {
      state.isLoading = false;
      state.isError = true;
      state.message = action.payload;
    });
  },
});

export const { reset } = companySlice.actions;
export default companySlice.reducer;
