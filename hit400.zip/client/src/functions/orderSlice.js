import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

const url = "http://127.0.0.1:5000/order";

const initialState = {
  order: null,
  isError: false,
  isSuccess: false,
  isLoading: false,
  message: "",
};

//api call to get all fleet
export async function getAllOrders() {
  try {
    return await axios.get(`${url}/all`, { withCredentials: true });
  } catch (error) {
    console.log(error);
  }
}

//count all orders
export async function countOrders() {
  try {
    return await axios.get(`${url}/count`, { withCredentials: true });
  } catch (error) {
    console.log(error);
  }
}

//count all completed orders
export async function countCompletedOrders() {
  try {
    return await axios.get(`${url}/countfull`, { withCredentials: true });
  } catch (error) {
    console.log(error);
  }
}

export async function GetFleetOrders() {
  try {
    return await axios.get(`${url}/graph`, { withCredentials: true });
  } catch (error) {
    console.log(error);
  }
}

export async function GetDriverOrders() {
  try {
    return await axios.get(`${url}/graphdriver`, { withCredentials: true });
  } catch (error) {
    console.log(error);
  }
}

//api call to create a new customer order
export const CreateCustomerOrder = createAsyncThunk(
  "order/CreateCustomerOrder",
  async (order_details, thunkAPI) => {
    try {
      const response = await axios.post(`${url}/create`, order_details, {
        withCredentials: true,
      });
      return response.data || response.msg;
    } catch (error) {
      if (error.response) {
        const message = error.response.data.msg;
        return thunkAPI.rejectWithValue(message);
      }
    }
  }
);

//api call to update order details
export const UpdateOrder = createAsyncThunk(
  "order/UpdateOrder",
  async ({ id, order_details }, thunkAPI) => {
    try {
      const response = await axios.patch(`${url}/update/${id}`, order_details, {
        withCredentials: true,
      });
      return response.data || response.msg;
    } catch (error) {
      if (error.response) {
        const message = error.response.data.msg;
        return thunkAPI.rejectWithValue(message);
      }
    }
  }
);

//api call to update order details
export const CancelOrder = createAsyncThunk(
  "order/CancelOrder",
  async ({ id }, thunkAPI) => {
    try {
      const response = await axios.patch(`${url}/cancel/${id}`, {
        withCredentials: true,
      });
      return response.msg;
    } catch (error) {
      if (error.response) {
        const message = error.response.data.msg;
        return thunkAPI.rejectWithValue(message);
      }
    }
  }
);

//api call to update order details
export const ReAssignOrder = createAsyncThunk(
  "order/ReAssignOrder",
  async ({ id }, thunkAPI) => {
    try {
      const response = await axios.patch(`${url}/assign/${id}`, {
        withCredentials: true,
      });
      return response.msg;
    } catch (error) {
      if (error.response) {
        const message = error.response.data.msg;
        return thunkAPI.rejectWithValue(message);
      }
    }
  }
);

export const orderSlice = createSlice({
  name: "order",
  initialState,
  reducers: {
    reset: (state) => initialState,
  },
  extraReducers: (builder) => {
    //create new order
    builder.addCase(CreateCustomerOrder.pending, (state) => {
      state.isLoading = true;
    });
    builder.addCase(CreateCustomerOrder.fulfilled, (state, action) => {
      state.isLoading = false;
      state.isSuccess = true;
      if (action.payload && action.payload.msg) {
        state.message = action.payload.msg;
      }
      if (action.payload) {
        state.order = action.payload;
      }
    });
    builder.addCase(CreateCustomerOrder.rejected, (state, action) => {
      state.isLoading = false;
      state.isError = true;
      state.message = action.payload;
    });

    //update customer order
    builder.addCase(UpdateOrder.pending, (state) => {
      state.isLoading = true;
    });
    builder.addCase(UpdateOrder.fulfilled, (state, action) => {
      state.isLoading = false;
      state.isSuccess = true;
      if (action.payload && action.payload.msg) {
        state.message = action.payload.msg;
      }
      if (action.payload) {
        state.order = action.payload;
      }
    });
    builder.addCase(UpdateOrder.rejected, (state, action) => {
      state.isLoading = false;
      state.isError = true;
      state.message = action.payload;
    });

    //update customer order by cancelling
    builder.addCase(CancelOrder.pending, (state) => {
      state.isLoading = true;
    });
    builder.addCase(CancelOrder.fulfilled, (state, action) => {
      state.isLoading = false;
      state.isSuccess = true;
      if (action.payload && action.payload.msg) {
        state.message = action.payload.msg;
      }
      if (action.payload) {
        state.order = action.payload;
      }
    });
    builder.addCase(CancelOrder.rejected, (state, action) => {
      state.isLoading = false;
      state.isError = true;
      state.message = action.payload;
    });

    //update customer order by reassigning
    builder.addCase(ReAssignOrder.pending, (state) => {
      state.isLoading = true;
    });
    builder.addCase(ReAssignOrder.fulfilled, (state, action) => {
      state.isLoading = false;
      state.isSuccess = true;
      if (action.payload && action.payload.msg) {
        state.message = action.payload.msg;
      }
      if (action.payload) {
        state.order = action.payload;
      }
    });
    builder.addCase(ReAssignOrder.rejected, (state, action) => {
      state.isLoading = false;
      state.isError = true;
      state.message = action.payload;
    });
  },
});

export const orderType = () => [
  { id: "1", title: "Light" },
  { id: "2", title: "Medium" },
  { id: "3", title: "Heavy" },
];

export const { reset } = orderSlice.actions;
export default orderSlice.reducer;
