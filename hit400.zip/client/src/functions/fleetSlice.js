import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

const url = "http://127.0.0.1:5000/fleet";

const initialState = {
  fleet: null,
  isError: false,
  isSuccess: false,
  isLoading: false,
  message: "",
};

//api call to get all fleet
export async function getAllFleet() {
  try {
    return await axios.get(`${url}/all`, { withCredentials: true });
  } catch (error) {
    console.log(error);
  }
}

//count all fleet
export async function countFleet() {
  try {
    return await axios.get(`${url}/count`, { withCredentials: true });
  } catch (error) {
    console.log(error);
  }
}

//api call to register new fleet into the system
export const AddNewFleet = createAsyncThunk(
  "fleet/AddNewFleet",
  async (fleet_details, thunkAPI) => {
    try {
      axios.defaults.withCredentials = true;
      const response = await axios.post(`${url}/add`, fleet_details);
      return response.data || response.msg;
    } catch (error) {
      if (error.response) {
        const message = error.response.data.msg;
        return thunkAPI.rejectWithValue(message);
      }
    }
  }
);

//api call to update fleet details
export const UpdateFleet = createAsyncThunk(
  "fleet/UpdateFleet",
  async ({ id, fleet_details }, thunkAPI) => {
    try {
      axios.defaults.withCredentials = true;
      const response = await axios.patch(`${url}/update/${id}`, fleet_details);
      return response.data || response.msg;
    } catch (error) {
      if (error.response) {
        const message = error.response.data.msg;
        return thunkAPI.rejectWithValue(message);
      }
    }
  }
);

export const fleetSlice = createSlice({
  name: "fleet",
  initialState,
  reducers: {
    reset: (state) => initialState,
  },
  extraReducers: (builder) => {
    //Add new fleet
    builder.addCase(AddNewFleet.pending, (state) => {
      state.isLoading = true;
    });
    builder.addCase(AddNewFleet.fulfilled, (state, action) => {
      state.isLoading = false;
      state.isSuccess = true;
      if (action.payload && action.payload.msg) {
        state.message = action.payload.msg;
      }
      if (action.payload) {
        state.fleet = action.payload;
      }
    });
    builder.addCase(AddNewFleet.rejected, (state, action) => {
      state.isLoading = false;
      state.isError = true;
      state.message = action.payload;
    });

    //update fleet details
    builder.addCase(UpdateFleet.pending, (state) => {
      state.isLoading = true;
    });
    builder.addCase(UpdateFleet.fulfilled, (state, action) => {
      state.isLoading = false;
      state.isSuccess = true;
      if (action.payload && action.payload.msg) {
        state.message = action.payload.msg;
      }
      if (action.payload) {
        state.fleet = action.payload;
      }
    });
    builder.addCase(UpdateFleet.rejected, (state, action) => {
      state.isLoading = false;
      state.isError = true;
      state.message = action.payload;
    });
  },
});

export const truckType = () => [
  { id: "1", title: "Light" },
  { id: "2", title: "Medium" },
  { id: "3", title: "Heavy" },
];

export const { reset } = fleetSlice.actions;
export default fleetSlice.reducer;
