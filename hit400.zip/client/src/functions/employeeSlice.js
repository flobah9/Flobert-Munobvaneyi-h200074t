import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

const url = "http://127.0.0.1:5000/employee";

const initialState = {
  employee: null,
  isError: false,
  isSuccess: false,
  isLoading: false,
  message: "",
};

//api call to get all employees
export async function getAllEmployee() {
  try {
    return await axios.get(`${url}/all`, { withCredentials: true });
  } catch (error) {
    console.log(error);
  }
}

//api call to register new employee
export const AddNewEmployee = createAsyncThunk(
  "employee/AddNewEmployee",
  async (employee_details, thunkAPI) => {
    try {
      const response = await axios.post(`${url}/add`, employee_details, {
        withCredentials: true,
      });
      return response.data || response.msg;
    } catch (error) {
      if (error.response) {
        const message = error.response.data.msg;
        return thunkAPI.rejectWithValue(message);
      }
    }
  }
);

//api call to update employee details
export const UpdateEmployee = createAsyncThunk(
  "employee/UpdateEmployee",
  async ({ id, employee_details }, thunkAPI) => {
    try {
      const response = await axios.patch(
        `${url}/update/${id}`,
        employee_details,
        { withCredentials: true }
      );
      return response.data || response.msg;
    } catch (error) {
      if (error.response) {
        const message = error.response.data.msg;
        return thunkAPI.rejectWithValue(message);
      }
    }
  }
);

export const employeeSlice = createSlice({
  name: "employee",
  initialState,
  reducers: {
    reset: (state) => initialState,
  },
  extraReducers: (builder) => {
    //Add new user
    builder.addCase(AddNewEmployee.pending, (state) => {
      state.isLoading = true;
    });
    builder.addCase(AddNewEmployee.fulfilled, (state, action) => {
      state.isLoading = false;
      state.isSuccess = true;
      if (action.payload && action.payload.msg) {
        state.message = action.payload.msg;
      }
      if (action.payload) {
        state.employee = action.payload;
      }
    });
    builder.addCase(AddNewEmployee.rejected, (state, action) => {
      state.isLoading = false;
      state.isError = true;
      state.message = action.payload;
    });

    //update user
    builder.addCase(UpdateEmployee.pending, (state) => {
      state.isLoading = true;
    });
    builder.addCase(UpdateEmployee.fulfilled, (state, action) => {
      state.isLoading = false;
      state.isSuccess = true;
      if (action.payload && action.payload.msg) {
        state.message = action.payload.msg;
      }
      if (action.payload) {
        state.employee = action.payload;
      }
    });
    builder.addCase(UpdateEmployee.rejected, (state, action) => {
      state.isLoading = false;
      state.isError = true;
      state.message = action.payload;
    });
  },
});

export const userRoles = () => [
  { id: "1", title: "Admin" },
  { id: "2", title: "User" },
];

export const { reset } = employeeSlice.actions;
export default employeeSlice.reducer;
