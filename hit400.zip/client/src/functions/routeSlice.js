import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

const url = "http://127.0.0.1:5000/path";
const urls = "http://127.0.0.1:5000/track";

const initialState = {
  track: null,
  isError: false,
  isSuccess: false,
  isLoading: false,
  message: "",
};

//api call to get optimized route path
export async function getOptimizedRoute(id) {
  try {
    return await axios.get(`${url}/view/${id}`, { withCredentials: true });
  } catch (error) {
    console.log(error);
  }
}

//api call to get all routes for good to be delivered
export async function getAllRoutes() {
  try {
    return await axios.get(`${url}/view`, { withCredentials: true });
  } catch (error) {
    console.log(error);
  }
}

export async function getCurrentLocation(id) {
  try {
    return await axios.get(`${urls}/location/${id}`, {
      withCredentials: true,
    });
  } catch (error) {
    console.log(error);
  }
}

//api call to get all locations to be tracked
export async function getAllLocation() {
  try {
    return await axios.get(`${urls}/location`, { withCredentials: true });
  } catch (error) {
    console.log(error);
  }
}

//api call to update location details
export const UpdateLocation = createAsyncThunk(
  "track/UpdateLocation",
  async ({ id, location_details }, thunkAPI) => {
    try {
      const response = await axios.patch(
        `${urls}/mylocation/${id}`,
        location_details,
        {
          withCredentials: true,
        }
      );
      return response.data || response.msg;
    } catch (error) {
      if (error.response) {
        const message = error.response.data.msg;
        return thunkAPI.rejectWithValue(message);
      }
    }
  }
);

export const UpdateFinalLocation = createAsyncThunk(
  "track/UpdateFinalLocation",
  async ({ id, location_details }, thunkAPI) => {
    try {
      const response = await axios.patch(
        `${urls}/finallocation/${id}`,
        location_details,
        {
          withCredentials: true,
        }
      );
      return response.data || response.msg;
    } catch (error) {
      if (error.response) {
        const message = error.response.data.msg;
        return thunkAPI.rejectWithValue(message);
      }
    }
  }
);

export const AddLocation = createAsyncThunk(
  "track/AddLocation",
  async (location_details, thunkAPI) => {
    try {
      const response = await axios.post(
        `${urls}/mylocation`,
        location_details,
        {
          withCredentials: true,
        }
      );
      return response.data || response.msg;
    } catch (error) {
      if (error.response) {
        const message = error.response.data.msg;
        return thunkAPI.rejectWithValue(message);
      }
    }
  }
);

export const routeSlice = createSlice({
  name: "track",
  initialState,
  reducers: {
    reset: (state) => initialState,
  },
  extraReducers: (builder) => {
    //update customer order
    builder.addCase(UpdateLocation.pending, (state) => {
      state.isLoading = true;
    });
    builder.addCase(UpdateLocation.fulfilled, (state, action) => {
      state.isLoading = false;
      state.isSuccess = true;
      state.track = action.payload;
    });
    builder.addCase(UpdateLocation.rejected, (state, action) => {
      state.isLoading = false;
      state.isError = true;
      state.message = action.payload;
    });

    //update customer order
    builder.addCase(UpdateFinalLocation.pending, (state) => {
      state.isLoading = true;
    });
    builder.addCase(UpdateFinalLocation.fulfilled, (state, action) => {
      state.isLoading = false;
      state.isSuccess = true;
      state.track = action.payload;
    });
    builder.addCase(UpdateFinalLocation.rejected, (state, action) => {
      state.isLoading = false;
      state.isError = true;
      state.message = action.payload;
    });

    builder.addCase(AddLocation.pending, (state) => {
      state.isLoading = true;
    });
    builder.addCase(AddLocation.fulfilled, (state, action) => {
      state.isLoading = false;
      state.isSuccess = true;
      if (action.payload && action.payload.msg) {
        state.message = action.payload.msg;
      }
      if (action.payload) {
        state.track = action.payload;
      }
    });
    builder.addCase(AddLocation.rejected, (state, action) => {
      state.isLoading = false;
      state.isError = true;
      state.message = action.payload;
    });
  },
});

export const { reset } = routeSlice.actions;
export default routeSlice.reducer;
