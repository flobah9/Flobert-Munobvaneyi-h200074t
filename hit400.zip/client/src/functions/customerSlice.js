import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

const url = "http://127.0.0.1:5000/customer";

const initialState = {
  customer: null,
  isError: false,
  isSuccess: false,
  isLoading: false,
  message: "",
};

//retrieve all customer details
export async function getAllCustomers() {
  try {
    return await axios.get(`${url}/all`, { withCredentials: true });
  } catch (error) {
    console.log(error);
  }
}

//count all customers
export async function countCustomers() {
  try {
    return await axios.get(`${url}/count`, { withCredentials: true });
  } catch (error) {
    console.log(error);
  }
}

//register new customer into the system
export const AddNewCustomer = createAsyncThunk(
  "customer/AddNewCustomer",
  async (customer_details, thunkAPI) => {
    try {
      const response = await axios.post(`${url}/add`, customer_details, {
        withCredentials: true,
      });
      return response.data || response.msg;
    } catch (error) {
      if (error.response) {
        const message = error.response.data.msg;
        return thunkAPI.rejectWithValue(message);
      }
    }
  }
);

//api call to update customer details
export const UpdateCustomer = createAsyncThunk(
  "customer/UpdateCustomer",
  async ({ id, customer_details }, thunkAPI) => {
    try {
      const response = await axios.patch(
        `${url}/update/${id}`,
        customer_details
      );
      return response.data || response.msg;
    } catch (error) {
      if (error.response) {
        const message = error.response.data.msg;
        return thunkAPI.rejectWithValue(message);
      }
    }
  }
);

//api call to get customer by customerID
export async function GetCustomerID(customerID) {
  try {
    return await axios.get(`${url}/view/${customerID}`, {
      withCredentials: true,
    });
  } catch (error) {
    console.log(error);
  }
}

export const customerSlice = createSlice({
  name: "customer",
  initialState,
  reducers: {
    reset: (state) => initialState,
  },
  extraReducers: (builder) => {
    //Add new customer details
    builder.addCase(AddNewCustomer.pending, (state) => {
      state.isLoading = true;
    });
    builder.addCase(AddNewCustomer.fulfilled, (state, action) => {
      state.isLoading = false;
      state.isSuccess = true;
      if (action.payload && action.payload.msg) {
        state.message = action.payload.msg;
      }
      if (action.payload) {
        state.customer = action.payload;
      }
    });
    builder.addCase(AddNewCustomer.rejected, (state, action) => {
      state.isLoading = false;
      state.isError = true;
      state.message = action.payload;
    });

    //update customer details
    builder.addCase(UpdateCustomer.pending, (state) => {
      state.isLoading = true;
    });
    builder.addCase(UpdateCustomer.fulfilled, (state, action) => {
      state.isLoading = false;
      state.isSuccess = true;
      if (action.payload && action.payload.msg) {
        state.message = action.payload.msg;
      }
      if (action.payload) {
        state.customer = action.payload;
      }
    });
    builder.addCase(UpdateCustomer.rejected, (state, action) => {
      state.isLoading = false;
      state.isError = true;
      state.message = action.payload;
    });
  },
});

export const { reset } = customerSlice.actions;
export default customerSlice.reducer;
