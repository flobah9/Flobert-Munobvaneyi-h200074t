import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

const url = "http://127.0.0.1:5000/auth";

const initialState = {
  truck: null,
  isError: false,
  isSuccess: false,
  isLoading: false,
  message: "",
};

//api call to login driver
export const DriverSignIn = createAsyncThunk(
  "truck/DriverSignIn",
  async (truck, thunkAPI) => {
    try {
      const response = await axios.post(
        `${url}/login`,
        {
          licence_no: truck.licence_no,
          password: truck.password,
        },
        { withCredentials: true }
      );
      return response.data || response.msg;
    } catch (error) {
      if (error.response) {
        const message = error.response.data.msg;
        return thunkAPI.rejectWithValue(message);
      }
    }
  }
);

//api call to signup user
export const SignUpDriver = createAsyncThunk(
  "truck/SignUpDriver",
  async (truck, thunkAPI) => {
    try {
      const response = await axios.post(
        `${url}/create`,
        {
          emailAddress: truck.emailAddress,
          licence_no: truck.licence,
          password: truck.password,
          confirmPassword: truck.confirmPassword,
        },
        { withCredentials: true }
      );
      return response.data || response.msg;
    } catch (error) {
      if (error.response) {
        const message = error.response.data.msg;
        return thunkAPI.rejectWithValue(message);
      }
    }
  }
);

export const driverAuthSlice = createSlice({
  name: "trucks",
  initialState,
  reducers: {
    reset: (state) => initialState,
  },
  extraReducers: (builder) => {
    //login user
    builder.addCase(DriverSignIn.pending, (state) => {
      state.isLoading = true;
    });
    builder.addCase(DriverSignIn.fulfilled, (state, action) => {
      state.isLoading = false;
      state.isSuccess = true;
      if (action.payload && action.payload.msg) {
        state.message = action.payload.msg;
      }
      if (action.payload) {
        state.truck = action.payload;
      }
    });
    builder.addCase(DriverSignIn.rejected, (state, action) => {
      state.isLoading = false;
      state.isError = true;
      state.message = action.payload;
    });

    //SignUp user
    builder.addCase(SignUpDriver.pending, (state) => {
      state.isLoading = true;
    });
    builder.addCase(SignUpDriver.fulfilled, (state, action) => {
      state.isLoading = false;
      state.isSuccess = true;
      if (action.payload && action.payload.msg) {
        state.message = action.payload.msg;
      }
      if (action.payload) {
        state.truck = action.payload;
      }
    });
    builder.addCase(SignUpDriver.rejected, (state, action) => {
      state.isLoading = false;
      state.isError = true;
      state.message = action.payload;
    });
  },
});

export const { reset } = driverAuthSlice.actions;
export default driverAuthSlice.reducer;
