import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

const url = "http://127.0.0.1:5000/auth";

const initialState = {
  user: null,
  isError: false,
  isSuccess: false,
  isLoading: false,
  message: "",
};

//api call to login
export const LoginUser = createAsyncThunk(
  "user/LoginUser",
  async (user, thunkAPI) => {
    try {
      const response = await axios.post(
        `${url}/signin`,
        {
          emailAddress: user.emailAddress,
          password: user.password,
        },
        { withCredentials: true }
      );
      return response.data;
    } catch (error) {
      if (error.response) {
        const message = error.response.data.msg;
        return thunkAPI.rejectWithValue(message);
      }
    }
  }
);

//api call to signup user
export const SignUser = createAsyncThunk(
  "user/SignUser",
  async (user, thunkAPI) => {
    try {
      const response = await axios.post(`${url}/signup`, {
        emailAddress: user.emailAddress,
        password: user.password,
        confirmPassword: user.confirmPassword,
      });
      return response.data;
    } catch (error) {
      if (error.response) {
        const message = error.response.data.msg;
        return thunkAPI.rejectWithValue(message);
      }
    }
  }
);

//api call to logut of the system
export const LogOut = createAsyncThunk("user/LogOut", async () => {
  await axios.delete(`${url}/logout`);
});

export const authentication = createSlice({
  name: "auth",
  initialState,
  reducers: {
    reset: (state) => initialState,
  },
  extraReducers: (builder) => {
    builder.addCase(LoginUser.pending, (state) => {
      state.isLoading = true;
    });
    builder.addCase(LoginUser.fulfilled, (state, action) => {
      state.isLoading = false;
      state.isSuccess = true;
      state.user = action.payload;
    });
    builder.addCase(LoginUser.rejected, (state, action) => {
      state.isLoading = false;
      state.isError = true;
      state.message = action.payload;
    });

    //SignUp user
    builder.addCase(SignUser.pending, (state) => {
      state.isLoading = true;
    });
    builder.addCase(SignUser.fulfilled, (state, action) => {
      state.isLoading = false;
      state.isSuccess = true;
      state.user = action.payload;
    });
    builder.addCase(SignUser.rejected, (state, action) => {
      state.isLoading = false;
      state.isError = true;
      state.message = action.payload;
    });
  },
});

export const { reset } = authentication.actions;
export default authentication.reducer;
