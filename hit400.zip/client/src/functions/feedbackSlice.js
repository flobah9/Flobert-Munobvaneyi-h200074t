import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

const url = "http://127.0.0.1:5000/feed";

const initialState = {
  feed: null,
  isError: false,
  isSuccess: false,
  isLoading: false,
  message: "",
};

export const trafficRoles = () => [
  { id: "1", title: "Light Traffic" },
  { id: "2", title: "Moderate Traffic" },
  { id: "3", title: "Heavy Traffic" },
];

export const conditionRoles = () => [
  { id: "1", title: "Good" },
  { id: "2", title: "Damaged" },
  { id: "3", title: "Broken" },
];

export const AddFeedback = createAsyncThunk(
  "feed/AddFeedback",
  async (feedback, thunkAPI) => {
    try {
      const response = await axios.post(`${url}/add`, feedback, {
        withCredentials: true,
      });
      return response.data || response.msg;
    } catch (error) {
      if (error.response) {
        const message = error.response.data.msg;
        return thunkAPI.rejectWithValue(message);
      }
    }
  }
);

export const feedbackSlice = createSlice({
  name: "feed",
  initialState,
  reducers: {
    reset: (state) => initialState,
  },
  extraReducers: (builder) => {
    //update customer order
    builder.addCase(AddFeedback.pending, (state) => {
      state.isLoading = true;
    });
    builder.addCase(AddFeedback.fulfilled, (state, action) => {
      state.isLoading = false;
      state.isSuccess = true;
      if (action.payload && action.payload.msg) {
        state.message = action.payload.msg;
      }
      if (action.payload) {
        state.feed = action.payload;
      }
    });
    builder.addCase(AddFeedback.rejected, (state, action) => {
      state.isLoading = false;
      state.isError = true;
      state.message = action.payload;
    });
  },
});

export const { reset } = feedbackSlice.actions;
export default feedbackSlice.reducer;
