import { configureStore } from "@reduxjs/toolkit";
import authenticationReducer from "./authentication";
import employeeReducer from "./employeeSlice";
import driverReducer from "./driverSlice";
import customerReducer from "./customerSlice";
import fleetReducer from "./fleetSlice";
import companyReducer from "./companySlice";
import orderReducer from "./orderSlice";
import driverAuthReducer from "./driverAuthSlice";
import routeReducer from "./routeSlice";
import feedbackReducer from "./feedbackSlice";

export const store = configureStore({
  reducer: {
    auth: authenticationReducer,
    trucks: driverAuthReducer,
    employee: employeeReducer,
    driver: driverReducer,
    customer: customerReducer,
    fleet: fleetReducer,
    company: companyReducer,
    order: orderReducer,
    track: routeReducer,
    feed: feedbackReducer
  },
});
