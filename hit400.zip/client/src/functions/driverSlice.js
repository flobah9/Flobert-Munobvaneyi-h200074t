import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

const url = "http://127.0.0.1:5000/driver";

const initialState = {
  driver: null,
  isError: false,
  isSuccess: false,
  isLoading: false,
  message: "",
};

//api call to get all drivers
export async function getAllDrivers() {
  try {
    return await axios.get(`${url}/all`, { withCredentials: true });
  } catch (error) {
    console.log(error);
  }
}

//count all drivers
export async function countDrivers() {
  try {
    return await axios.get(`${url}/count`, { withCredentials: true });
  } catch (error) {
    console.log(error);
  }
}

//count all assigned orders
export async function countTotalAssigned() {
  try {
    return await axios.get(`${url}/countall`, { withCredentials: true });
  } catch (error) {
    console.log(error);
  }
}

//count all completed orders
export async function countCompletedOrders() {
  try {
    return await axios.get(`${url}/countfull`, { withCredentials: true });
  } catch (error) {
    console.log(error);
  }
}

//api call to register new driver into the system
export const AddNewDriver = createAsyncThunk(
  "driver/AddNewDriver",
  async (driver_details, thunkAPI) => {
    try {
      const response = await axios.post(`${url}/add`, driver_details, {
        withCredentials: true,
      });
      return response.data || response.msg;
    } catch (error) {
      if (error.response) {
        const message = error.response.data.msg;
        return thunkAPI.rejectWithValue(message);
      }
    }
  }
);

//api call to update driver details
export const UpdateDriver = createAsyncThunk(
  "driver/UpdateDriver",
  async ({ id, driver_details }, thunkAPI) => {
    try {
      const response = await axios.patch(
        `${url}/update/${id}`,
        driver_details,
        { withCredentials: true }
      );
      return response.data || response.msg;
    } catch (error) {
      if (error.response) {
        const message = error.response.data.msg;
        return thunkAPI.rejectWithValue(message);
      }
    }
  }
);

export const driverSlice = createSlice({
  name: "driver",
  initialState,
  reducers: {
    reset: (state) => initialState,
  },
  extraReducers: (builder) => {
    //Add new driver details
    builder.addCase(AddNewDriver.pending, (state) => {
      state.isLoading = true;
    });
    builder.addCase(AddNewDriver.fulfilled, (state, action) => {
      state.isLoading = false;
      state.isSuccess = true;
      if (action.payload && action.payload.msg) {
        state.message = action.payload.msg;
      }
      if (action.payload) {
        state.driver = action.payload;
      }
    });
    builder.addCase(AddNewDriver.rejected, (state, action) => {
      state.isLoading = false;
      state.isError = true;
      state.message = action.payload;
    });

    //update driver details
    builder.addCase(UpdateDriver.pending, (state) => {
      state.isLoading = true;
    });
    builder.addCase(UpdateDriver.fulfilled, (state, action) => {
      state.isLoading = false;
      state.isSuccess = true;
      if (action.payload && action.payload.msg) {
        state.message = action.payload.msg;
      }
      if (action.payload) {
        state.driver = action.payload;
      }
    });
    builder.addCase(UpdateDriver.rejected, (state, action) => {
      state.isLoading = false;
      state.isError = true;
      state.message = action.payload;
    });
  },
});

export const { reset } = driverSlice.actions;
export default driverSlice.reducer;
