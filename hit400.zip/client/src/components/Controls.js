import ActionButton from "./ActionButton";
import Button from "./Button";
import Input from "./Input";
import PhoneNumberInput from "./PhoneNumberInput";
import UserSelect from "./UserSelect";
import Checkbox from "./Checkbox";

const Controls = {
  ActionButton,
  Button,
  Input,
  PhoneNumberInput,
  UserSelect,
  Checkbox,
};

export default Controls;
