import React, { useEffect, useState } from "react";
import { Grid, Stack } from "@mui/material";
import ReactMapGL, { Marker, NavigationControl } from "react-map-gl";
import "mapbox-gl/dist/mapbox-gl.css";
import Controls from "../../components/Controls";
import { Form } from "../../utils/useForm";
import { getOptimizedRoute } from "../../functions/routeSlice";
import dijkstra from "dijkstra";

export default function ViewRoute({ path }) {
  const [route, setRoute] = useState([]);
  const [travelTime, setTravelTime] = useState(null);
  const [trafficData, setTrafficData] = useState(null);

  useEffect(() => {
    const fetchRouteAndTrafficData = async () => {
      try {
        const response = await getOptimizedRoute(path.id);
        const origin = {
          lat: response.data.originlat,
          lng: response.data.originlng,
        };
        const destination = {
          lat: response.data.destinationlat,
          lng: response.data.destinationlng,
        };
        
        // Fetch route from Mapbox Directions API
        const routeResponse = await fetchRouteFromMapbox(origin, destination);
        const route = routeResponse.routes[0].geometry.coordinates;

        // Fetch traffic data from Mapbox Traffic API
        const trafficData = await fetchTrafficData(route);

        setRoute(route);
        setTrafficData(trafficData);

        // Calculate travel time
        const totalDistance = routeResponse.routes[0].distance; // in meters
        const averageSpeed = 50; // km/h
        const travelTime = totalDistance / (averageSpeed * 1000); // Convert meters to km
        setTravelTime(travelTime);
      } catch (error) {
        console.error("Error fetching route and traffic data:", error);
      }
    };

    fetchRouteAndTrafficData();
  }, [path]);

  // Fetch route from Mapbox Directions API
  const fetchRouteFromMapbox = async (origin, destination) => {
    const accessToken = "YOUR_MAPBOX_ACCESS_TOKEN";
    const url = `https://api.mapbox.com/directions/v5/mapbox/driving/${origin.lng},${origin.lat};${destination.lng},${destination.lat}?steps=true&geometries=geojson&access_token=${accessToken}`;
    const response = await fetch(url);
    const data = await response.json();
    return data;
  };

  // Fetch traffic data from Mapbox Traffic API
  const fetchTrafficData = async (route) => {
    const accessToken = "YOUR_MAPBOX_ACCESS_TOKEN";
    const coordinates = route.map(coord => `${coord[0]},${coord[1]}`).join(';');
    const url = `https://api.mapbox.com/traffic/v1/mapbox/driving/${coordinates}?access_token=${accessToken}`;
    const response = await fetch(url);
    const data = await response.json();
    return data;
  };

  return (
    <Form>
      <Grid container>{/*... */}</Grid>
      <Stack sx={{ height: "100vh", display: "flex", position: "relative" }}>
        <ReactMapGL
          mapboxAccessToken="pk.eyJ1Ijoid2FiYW50dS13YXhvIiwiYSI6ImNsc3p2eWYwODB3ZnAyam8ycXVyd3Y4anMifQ.sknSv3PqoEf8zD3cmMRzKA"
          initialViewState={{
            longitude: 31.053028,
            latitude: -17.824858,
            zoom: 10,
          }}
          mapStyle="mapbox://styles/mapbox/streets-v11"
        >
          {route.map((coord, index) => (
            <Marker
              key={index}
              latitude={coord[1]} // latitude is index 1 in coordinate array
              longitude={coord[0]} // longitude is index 0 in coordinate array
            />
          ))}
          <NavigationControl showCompass showZoom position="top-right" />
        </ReactMapGL>
      </Stack>
      {travelTime && <p>Travel time: {travelTime} hours</p>}
      {trafficData && <p>Traffic data: {JSON.stringify(trafficData)}</p>}
    </Form>
  );
}
