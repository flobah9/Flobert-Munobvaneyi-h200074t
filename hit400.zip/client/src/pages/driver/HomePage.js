import React, { useEffect, useState } from "react";
import { styled } from "@mui/material/styles";
import { Container, Grid, Paper } from "@mui/material";
import PageHeader from "../../utils/PageHeader";
import { ApartmentTwoTone, Done, ShoppingBag } from "@mui/icons-material";
import NoteCard from "../../utils/NoteCard";
import {
  countCompletedOrders,
  countTotalAssigned,
} from "../../functions/driverSlice";

const PageContent = styled("div")(({ theme }) => ({
  margin: theme.spacing(0.5),
  padding: theme.spacing(0.5),
}));

const StyledContainer = styled(Container)(({ theme }) => ({
  paddingTop: theme.spacing(0.5),
  paddingBottom: theme.spacing(0.5),
}));

const StyledPaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(2),
  display: "flex",
  overflow: "auto",
  flexDirection: "column",
}));

export default function HomePage() {
  const [orders, setOrder] = useState();
  const [done, setDone] = useState();

  useEffect(() => {
    async function MyAssignedOrders() {
      try {
        const response = await countTotalAssigned();
        setOrder(response.data);
      } catch (error) {
        console.log(error);
      }
    }
    MyAssignedOrders();
  }, []);

  useEffect(() => {
    async function CompletedOrders() {
      try {
        const response = await countCompletedOrders();
        setDone(response.data);
      } catch (error) {
        console.log(error);
      }
    }
    CompletedOrders();
  }, []);

  return (
    <>
      <PageHeader
        title="DMS | Driver Home"
        subTitle="Welcome to DMS"
        icon={<ApartmentTwoTone fontSize="large" />}
      />
      <main className={PageContent}>
        <StyledContainer maxWidth="lg">
          <Grid item xs={12}>
            <StyledPaper>
              <Grid container spacing={3}>
                <Grid item xs={12} md={6} lg={4}>
                  <NoteCard
                    title="My Orders"
                    icon={<ShoppingBag fontSize="large" color="primary" />}
                    details={orders}
                  />
                </Grid>
                <Grid item xs={12} md={6} lg={4}>
                  <NoteCard
                    title="Completed deliveries"
                    icon={<Done fontSize="large" color="primary" />}
                    details={done}
                  />
                </Grid>
              </Grid>
            </StyledPaper>
          </Grid>
        </StyledContainer>
      </main>
    </>
  );
}
