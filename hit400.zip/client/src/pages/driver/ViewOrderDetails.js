import React from "react";
import { Form } from "../../utils/useForm";
import { Grid } from "@mui/material";
import Controls from "../../components/Controls";

export default function ViewOrderDetails({ order }) {
  return (
    <Form>
      <Grid container>
        <Grid item xs={6}>
          <Controls.Input
            name="orderID"
            label="Order ID"
            value={order?.order_detail?.orderID}
            variant="outlined"
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="loadType"
            label="Load Type"
            value={order?.order_detail?.loadType}
            variant="outlined"
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="order_details"
            label="Order details"
            variant="outlined"
            value={order?.order_detail?.order_details}
            multiline
            rows={3}
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="scheduled_delivery_time"
            label="Delivery time"
            value={order?.order_detail?.scheduled_delivery_time}
            variant="outlined"
            inputProps={{ readOnly: true }}
          />
        </Grid>
        <Grid item xs={6}>
          <Controls.Input
            name="customerID"
            label="Customer ID"
            value={order?.order_detail?.customerID}
            variant="outlined"
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="customerName"
            label="Customer Name"
            variant="outlined"
            value={order?.order_detail?.customer_profile?.customerName}
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="location"
            label="Customer address"
            variant="outlined"
            value={order?.order_detail?.customer_profile?.location}
            multiline
            rows={3}
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="status"
            label="Status"
            value={order?.order_detail?.status}
            variant="outlined"
            inputProps={{ readOnly: true }}
          />
        </Grid>
      </Grid>
    </Form>
  );
}
