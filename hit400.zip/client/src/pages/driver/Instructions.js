import React from "react";
import { ListItemIcon, ListItemText, ListItem } from "@mui/material";

const Instructions = ({ steps, no_ }) => {
  return (
    <ListItem sx={{ padding: "2px 4px" }}>
      <ListItemIcon>
        <div className="step-number">{no_}</div>
      </ListItemIcon>
      <ListItemText primary={steps} />
    </ListItem>
  );
};

export default Instructions;
