import React, { useState, useEffect } from "react";
import { Form, useForm } from "../../utils/useForm";
import { Grid, Typography } from "@mui/material";
import Controls from "../../components/Controls";
import {
  trafficRoles,
  conditionRoles,
  AddFeedback,
  reset,
} from "../../functions/feedbackSlice";
import SignatureCanvas from "react-signature-canvas";
import { RestartAlt, Send } from "@mui/icons-material";
import { useDispatch, useSelector } from "react-redux";
import Notification from "../../utils/Notification";
import Loading from "../../utils/Loading";
import { useNavigate } from "react-router-dom";

const initialFValues = {
  traffic: "Moderate Traffic",
  report: "",
  condition: "Good",
};

export default function Feedback({ id }) {
  const [trimmedDataURL, setTrimmedDataUrl] = useState([]);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const { feed, isError, isSuccess, message } = useSelector(
    (state) => state.feed
  );

  const [loading, setLoading] = useState(false);

  const [notify, setNotify] = useState({
    open: false,
    message: "",
    severity: "",
  });

  let sigPad = {};

  const clear = () => {
    sigPad.clear();
  };

  const trim = () => {
    setTrimmedDataUrl(sigPad.getTrimmedCanvas().toDataURL("image/png"));
  };

  const validate = (fieldValues = values) => {
    let temp = { ...errors };
    if ("report" in fieldValues)
      temp.report = fieldValues.report ? "" : "This field is required.";
    if ("traffic" in fieldValues)
      temp.traffic = fieldValues.traffic
        ? ""
        : "Traffic condition is required.";
    setErrors({
      ...temp,
    });
    if (fieldValues === values)
      return Object.values(temp).every((x) => x === "");
  };

  const { values, errors, setErrors, handleInputChange, resetForm } = useForm(
    initialFValues,
    true,
    validate
  );

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate) {
      const feedback = {
        id: id,
        traffic: values.traffic,
        condition: values.condition,
        report: values.report,
      };
      dispatch(AddFeedback(feedback));
      setLoading(true);
    }
  };

  useEffect(() => {
    if (isError) {
      setNotify({
        open: true,
        severity: "error",
        message: message,
      });
      setLoading(false);
    }
    if (isSuccess && feed) {
      setNotify({
        open: true,
        severity: "success",
        message: message,
      });
      setLoading(false);
      navigate("/home");
    }
    dispatch(reset());
  }, [isError, setNotify, isSuccess, feed, dispatch]);

  return (
    <>
      <Loading loading={loading} />
      <Notification notify={notify} setNotify={setNotify} />
      <Form onSubmit={handleSubmit}>
        <Grid container>
          <Grid item xs={6}>
            <Controls.UserSelect
              name="traffic"
              label="Traffic condition"
              value={values.traffic}
              onChange={handleInputChange}
              options={trafficRoles()}
              error={errors.traffic}
            />
            <Controls.Input
              name="report"
              label="Report details"
              value={values.report}
              onChange={handleInputChange}
              multiline
              rows={4}
              error={errors.report}
            />
          </Grid>
          <Grid item xs={6}>
            <Controls.UserSelect
              name="condition"
              label="Package condition"
              value={values.condition}
              onChange={handleInputChange}
              options={conditionRoles()}
            />
            <div style={{ width: 350 }}>
              <Typography
                variant="h6"
                color="primary"
                style={{ marginLeft: 5 }}
              >
                Driver's signature
              </Typography>
              <SignatureCanvas
                penColor="black"
                canvasProps={{
                  width: 345,
                  height: 125,
                  className: "sigCanvas",
                  style: { border: "1px solid blue", marginLeft: 5 },
                }}
                ref={(ref) => {
                  sigPad = ref;
                }}
              />
              <Controls.Button
                text="Clear signature"
                color="error"
                onClick={() => {
                  clear();
                }}
              />
            </div>
            <div>
              <Controls.Button
                type="submit"
                text="Submit"
                startIcon={<Send />}
                onClick={() => {
                  trim();
                }}
              />
              <Controls.Button
                text="Reset"
                color="error"
                startIcon={<RestartAlt />}
                onClick={resetForm}
              />
            </div>
          </Grid>
        </Grid>
      </Form>
    </>
  );
}
