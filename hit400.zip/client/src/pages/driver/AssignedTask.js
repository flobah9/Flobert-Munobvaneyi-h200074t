import React, { useEffect, useState } from "react";
import PageHeader from "../../utils/PageHeader";
import { AltRoute, Task, Visibility } from "@mui/icons-material";
import {
  InputAdornment,
  Paper,
  TableBody,
  TableCell,
  TableRow,
  Toolbar,
} from "@mui/material";
import Controls from "../../components/Controls";
import useTable from "../../utils/useTable";
import { Search } from "@mui/icons-material";
import { getAllRoutes } from "../../functions/routeSlice";
import Popup from "../../utils/Popup";
import ViewRoute from "./ViewRoute";
import ViewOrderDetails from "./ViewOrderDetails";

const headCells = [
  { id: "id", label: "" },
  { id: "orderID", label: "Order ID" },
  { id: "customerID", label: "Customer ID" },
  { id: "scheduled_delivery_time", label: "Delivery time " },
  { id: "location", label: "Location" },
  { id: "status", label: "Status" },
  { id: "actions", label: "Actions", disableSorting: true },
];

export default function AssignedTask() {
  const [records, setRecords] = useState([]);
  const [recordForRoute, setRecordForRoute] = useState(null);
  const [recordForView, setRecordForView] = useState(null);
  const [openPopup, setOpenPopup] = useState(false);
  const [open, setOpen] = useState(false);

  const [filterFn, setFilterFn] = useState({
    fn: (items) => {
      return items;
    },
  });

  const { TblContainer, TblHead, TblPagination, recordsAfterPagingAndSorting } =
    useTable(records, headCells, filterFn);

  useEffect(() => {
    async function getAllAssignedOrders() {
      try {
        const response = await getAllRoutes();
        setRecords(response.data);
      } catch (error) {
        console.log(error);
      }
    }
    getAllAssignedOrders();
  }, []);

  const handleSearch = (e) => {
    let target = e.target;
    setFilterFn({
      fn: (items) => {
        if (target.value === "") return items;
        else
          return items.filter((x) =>
            x.make.toLowerCase().includes(target.value)
          );
      },
    });
  };

  const openInWindow = (path) => {
    setRecordForRoute(path);
    setOpen(true);
  };

  const openInView = (order) => {
    setRecordForView(order);
    setOpenPopup(true);
  };
  return (
    <>
      <PageHeader
        title="DMS | Assigned Deliveries"
        subTitle="Delivery List"
        icon={<AltRoute fontSize="large" />}
      />
      <Paper
        sx={{
          margin: (theme) => theme.spacing(2),
          padding: (theme) => theme.spacing(1),
          flexGrow: 1,
          overflow: "auto",
        }}
      >
        <Toolbar
          sx={{
            display: "flex",
            flexDirection: "row",
            flexWrap: "nowrap",
            justifyContent: "space-between",
          }}
        >
          <Controls.Input
            label="Search route"
            sx={{ width: "60%" }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Search />
                </InputAdornment>
              ),
            }}
            onChange={handleSearch}
          />
        </Toolbar>
        <TblContainer>
          <TblHead />
          <TableBody>
            {recordsAfterPagingAndSorting().map((path) => (
              <TableRow key={path.id}>
                <TableCell>{path.id}</TableCell>
                <TableCell>{path?.order_detail?.orderID}</TableCell>
                <TableCell>{path?.order_detail?.customerID}</TableCell>
                <TableCell>
                  {path?.order_detail?.scheduled_delivery_time}
                </TableCell>
                <TableCell>
                  {path?.order_detail?.customer_profile?.location}
                </TableCell>
                <TableCell>{path?.order_detail?.status}</TableCell>
                <TableCell>
                  {path && path?.order_detail?.status !== "Completed" ? (
                    <Controls.ActionButton
                      color="primary"
                      onClick={() => {
                        openInWindow(path);
                      }}
                    >
                      <Task fontSize="small" />
                    </Controls.ActionButton>
                  ) : (
                    ""
                  )}
                  <Controls.ActionButton
                    color="primary"
                    onClick={() => {
                      openInView(path);
                    }}
                  >
                    <Visibility fontSize="small" />
                  </Controls.ActionButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </TblContainer>
        <TblPagination />
      </Paper>
      <Popup title="Delivery Route" openPopup={open} setOpenPopup={setOpen}>
        <ViewRoute path={recordForRoute} />
      </Popup>
      <Popup
        title="View Order Details"
        openPopup={openPopup}
        setOpenPopup={setOpenPopup}
      >
        <ViewOrderDetails order={recordForView} />
      </Popup>
    </>
  );
}
