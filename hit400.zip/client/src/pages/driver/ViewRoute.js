import React, { useState, useEffect, useMemo } from "react";
import {
  Grid,
  Skeleton,
  Stack,
  IconButton,
  Card,
  CardContent,
  Typography,
} from "@mui/material";
import Controls from "../../components/Controls";
import { Form } from "../../utils/useForm";
import ReactMapGL, {
  Marker,
  NavigationControl,
  FullscreenControl,
  Layer,
  Source,
} from "react-map-gl";
import "mapbox-gl/dist/mapbox-gl.css";
import axios from "axios";
import Instructions from "./Instructions";
import Feedback from "./Feedback";
import { useDispatch, useSelector } from "react-redux";
import {
  ExpandMore,
  ExpandLess,
  Send,
  ShareLocation,
} from "@mui/icons-material";
import {
  AddLocation,
  UpdateFinalLocation,
  UpdateLocation,
  getCurrentLocation,
  reset,
} from "../../functions/routeSlice";
import Notification from "../../utils/Notification";
import "./main.css";

const mapboxAccessToken =
  "pk.eyJ1Ijoid2FiYW50dS13YXhvIiwiYSI6ImNsdjE2a3c1cDA0N20yanVzaWs2Mng2d2YifQ.DWfNt-TLsGUujYIgwmMQYw";

const BlinkingShareLocation = ({ position }) => (
  <ShareLocation
    sx={{
      color: "blue",
      animation: "blink 1s infinite",
    }}
    style={{
      left: position.lng,
      top: position.lat,
    }}
  />
);

export default function ViewRoute({ path }) {
  const [travelTime, setTravelTime] = useState(null);
  const [distance, setDistance] = useState(null);
  const [coords, setCoords] = useState([]);
  const [steps, setSteps] = useState([]);
  const [enabled, setEnabled] = useState(true);
  const [currentId, setCurrentId] = useState(null);
  const [showMoreSteps, setShowMoreSteps] = useState(false);
  const [visible, setVisible] = useState(true);
  const maxStepsToShow = 3;

  const dispatch = useDispatch();

  const { track, isError, isSuccess, message } = useSelector(
    (state) => state.track
  );

  const origin = useMemo(
    () => ({ lng: path.originLng, lat: path.originLat }),
    [path]
  );
  const destination = useMemo(
    () => ({ lng: path.destinationLng, lat: path.destinationLat }),
    [path]
  );

  const [notify, setNotify] = useState({
    open: false,
    message: "",
    severity: "",
  });

  const [viewState, setViewState] = useState({
    longitude: 31.053028,
    latitude: -17.824858,
    zoom: 7,
  });

  const [currentPosition, setCurrentPosition] = useState({
    lng: origin.lng,
    lat: origin.lat,
  });

  async function fetchDirections(origin, destination) {
    const response = await axios.get(
      `https://api.mapbox.com/directions/v5/mapbox/driving-traffic/${origin.lng},${origin.lat};${destination.lng},${destination.lat}?steps=true&geometries=geojson&access_token=${mapboxAccessToken}`
    );
    const data = response.data;
    const steps = data.routes[0].legs[0].steps;
    const coords = data.routes[0].geometry.coordinates;
    setCoords(coords);
    setSteps(steps);
    setTravelTime(data.routes[0].duration / 60); // Convert seconds to minutes
    setDistance(data.routes[0].distance / 1000); // Convert meters to kilometers
  }

  useEffect(() => {
    if (origin && destination) {
      fetchDirections(origin, destination);
    }
  }, [origin, destination]);

  const geojson = {
    type: "FeatureCollection",
    features: [
      {
        type: "feature",
        geometry: {
          type: "LineString",
          coordinates: [...coords],
        },
      },
    ],
  };

  const lineStyle = {
    id: "roadLayer",
    type: "line",
    layout: {
      "line-join": "round",
      "line-cap": "round",
    },
    paint: {
      "line-color": "blue",
      "line-width": 4,
      "line-opacity": 0.75,
      "line-blur": 0.5,
    },
  };

  const stepsToShow = showMoreSteps ? steps : steps.slice(0, maxStepsToShow);

  async function fetchCurrentLocation(id) {
    try {
      const response = await getCurrentLocation(id);
      if (response) {
        setCurrentId(response.data.id);
      }
    } catch (error) {
      console.log(error);
    }
  }

  async function UpdateNewLocation(id, position) {
    try {
      dispatch(UpdateLocation({ id: id, location_details: position }));
    } catch (error) {
      console.log(error);
    }
  }

  async function FinishMyTravel(id, position) {
    try {
      dispatch(UpdateFinalLocation({ id: id, location_details: position }));
    } catch (error) {
      console.log(error);
    }
  }

  useEffect(() => {
    if (isError) {
      setNotify({
        open: true,
        severity: "error",
        message: message,
      });
      setEnabled(false);
    }
    if (track && isSuccess) {
      if (currentId === null) {
        fetchCurrentLocation(path.id);
      }
    }
    dispatch(reset());
  }, [isError, message, dispatch, isSuccess, track, path, currentId]);

  useEffect(() => {
    if (currentId !== null) {
      let intervalId;
      if (coords.length > 0) {
        let index = 0;
        intervalId = setInterval(() => {
          if (index < coords.length) {
            const lng = coords[index][0];
            const lat = coords[index][1];
            setCurrentPosition({ lng, lat });
            UpdateNewLocation(currentId, { lng, lat });
            index++;
          } else {
            clearInterval(intervalId);
            setCurrentPosition({
              lng: coords[coords.length - 1][0],
              lat: coords[coords.length - 1][1],
            });
            FinishMyTravel(currentId, {
              lng: coords[coords.length - 1][0],
              lat: coords[coords.length - 1][1],
            });
            setVisible(false);
          }
        }, 2500);
      }
      return () => clearInterval(intervalId);
    }
  }, [coords, currentId]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const location = {
      id: path.id,
      lng: origin.lng,
      lat: origin.lat,
    };
    dispatch(AddLocation(location));
    setEnabled(false);
  };

  return visible ? (
    <>
      <Form>
        <Grid container>
          <Grid item xs={6}>
            <Controls.Input
              name="customerName"
              label="Customer Name"
              variant="outlined"
              value={path?.order_detail?.customer_profile?.customerName}
              inputProps={{ readOnly: true }}
            />
            <Controls.Input
              name="location"
              label="Customer address"
              variant="outlined"
              value={path?.order_detail?.customer_profile?.location}
              multiline
              rows={2}
              inputProps={{ readOnly: true }}
            />
          </Grid>
          <Grid item xs={6}>
            <Controls.Input
              name="orderID"
              label="Order ID"
              value={path?.order_detail?.orderID}
              variant="outlined"
              inputProps={{ readOnly: true }}
            />
            <Controls.Input
              name="order_details"
              label="Order details"
              variant="outlined"
              value={path?.order_detail?.order_details}
              multiline
              rows={2}
              inputProps={{ readOnly: true }}
            />
          </Grid>
        </Grid>
        <Stack sx={{ height: "100vh", display: "flex", position: "relative" }}>
          <ReactMapGL
            {...viewState}
            mapboxAccessToken={mapboxAccessToken}
            mapStyle="mapbox://styles/mapbox/streets-v11"
            onMove={(e) => setViewState(e.viewState)}
          >
            {coords ? (
              <>
                <Source id="routeSource" type="geojson" data={geojson}>
                  <Layer {...lineStyle} />
                </Source>
              </>
            ) : (
              <Skeleton animation="wave" />
            )}
            <FullscreenControl />
            {steps && (
              <Card
                sx={{
                  position: "absolute",
                  top: "2px",
                  left: "2px",
                  width: 300,
                  zIndex: 200, // Adjust width as needed
                  backgroundColor: "background.paper",
                  boxShadow:
                    "0px 2px 1px -1px rgba(0, 0, 0, 0.2), 0px 1px 1px 0px rgba(0, 0, 0, 0.14), 0px 1px 3px 0px rgba(0, 0, 0, 0.12)",
                }}
              >
                <CardContent>
                  <Typography
                    variant="h6"
                    component="div"
                    sx={{ fontWeight: "bold" }}
                  >
                    Turn-by-turn instructions
                  </Typography>
                  {stepsToShow.map((item, i) => (
                    <div key={i} className="flex flex-col gap-2">
                      <Instructions
                        no_={i + 1}
                        steps={item?.maneuver?.instruction}
                      />
                    </div>
                  ))}
                  {steps.length > maxStepsToShow && (
                    <IconButton
                      onClick={() => setShowMoreSteps(!showMoreSteps)}
                    >
                      {showMoreSteps ? <ExpandLess /> : <ExpandMore />}
                    </IconButton>
                  )}
                </CardContent>
              </Card>
            )}
            <NavigationControl showCompass showZoom position="top-right" />
            <Marker longitude={origin.lng} latitude={origin.lat} />
            <Marker
              longitude={destination.lng}
              latitude={destination.lat}
              color="red"
            />
            <Marker
              longitude={currentPosition.lng}
              latitude={currentPosition.lat}
            >
              <BlinkingShareLocation position={currentPosition} />
            </Marker>
          </ReactMapGL>
        </Stack>
        {distance && travelTime && (
          <>
            <Grid container>
              <Grid item xs={6}>
                <Controls.Input
                  name="distance"
                  label="Distance"
                  value={`${distance} km`}
                  inputProps={{ readOnly: true }}
                  variant="outlined"
                />
              </Grid>
              <Grid item xs={6}>
                <Controls.Input
                  name="travelTime"
                  label="Travel time"
                  value={`${travelTime} mins`}
                  inputProps={{ readOnly: true }}
                  variant="outlined"
                />
              </Grid>
            </Grid>
            <Grid item xs={12}>
              <div className="row">
                <Controls.Button
                  type="submit"
                  text="Start Trip"
                  startIcon={<Send />}
                  disabled={!enabled}
                  onClick={(e) => {
                    handleSubmit(e);
                  }}
                />
              </div>
            </Grid>
          </>
        )}
      </Form>
      <Notification notify={notify} setNotify={setNotify} />
    </>
  ) : (
    <Feedback id={path.id} />
  );
}
