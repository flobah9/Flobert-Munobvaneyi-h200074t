import React, { useState } from "react";
import {
  Avatar,
  Box,
  Card,
  Divider,
  FormControl,
  FormLabel,
  IconButton,
  Stack,
  Typography,
} from "@mui/material";
import { EditRounded } from "@mui/icons-material";

export default function MyProfile() {
  const [pic, setPic] = useState();

  const handleChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const photoUrl = URL.createObjectURL(file);
      setPic(photoUrl);
    }
  };
  return (
    <Card>
      <Box sx={{ mb: 1 }}>
        <Typography variant="h1" color="primary">
          Personal Information
        </Typography>
      </Box>
      <Divider />
      <Stack
        direction="row"
        spacing={3}
        sx={{ display: { xs: "none", md: "flex" }, my: 1 }}
      >
        <Stack direction="column" spacing={1}>
          <label htmlFor="profilePic">
            <input
              id="profilePic"
              accept="/*"
              type="file"
              style={{ display: "none" }}
              onChange={handleChange}
            />
            <Avatar src={pic} sx={{ width: 100, height: 100 }} />
          </label>
          <IconButton
            aria-label="upload new picture"
            size="sm"
            variant="outlined"
            color="neutral"
            sx={{
              bgcolor: "background.body",
              position: "absolute",
              zIndex: 2,
              borderRadius: "50%",
              left: 100,
              top: 170,
              boxShadow: "sm",
            }}
          >
            <EditRounded />
          </IconButton>
        </Stack>
        <Stack spacing={2} sx={{ flexGrow: 1 }}>
          <Stack spacing={1}>
            <FormLabel>Name</FormLabel>
            <FormControl
              sx={{ display: { sm: "flex-column", md: "flex-row" }, gap: 2 }}
            >
              <input size="sm" placeholder="First name" />
              <input size="sm" placeholder="Last name" sx={{ flexGrow: 1 }} />
            </FormControl>
          </Stack>
        </Stack>
      </Stack>
    </Card>
  );
}
