import React, { useState } from "react";
import { Alert, AlertTitle, Button, Container } from "@mui/material";
import { Lock } from "@mui/icons-material";
import Authorization from "./Authorization";

const AccessMessage = () => {
  const [openLogin, setOpenLogin] = useState(false);
  return (
    <>
      <Container sx={{ py: 5, marginTop: 5 }}>
        <Alert severity="error" variant="outlined">
          <AlertTitle>Forbidden Access</AlertTitle>
          Please login or register to access the system pages
          <Button
            variant="outlined"
            sx={{ ml: 2 }}
            startIcon={<Lock />}
            onClick={() => setOpenLogin(true)}
          >
            login
          </Button>
        </Alert>
      </Container>
      <Authorization openLogin={openLogin} setOpenLogin={setOpenLogin} />
    </>
  );
};

export default AccessMessage;
