import React, { useState, useEffect } from "react";
import PasswordField from "../../components/PasswordField";
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  IconButton,
  TextField,
} from "@mui/material";
import { Close, Send } from "@mui/icons-material";
import { LoginUser, SignUser, reset } from "../../functions/authentication";
import { useDispatch, useSelector } from "react-redux";
import Notification from "../../utils/Notification";
import Loading from "../../utils/Loading";

const Authorization = (props) => {
  const { openLogin, setOpenLogin } = props;
  const { user, isError, isSuccess, message } = useSelector(
    (state) => state.auth
  );
  const [title, setTitle] = useState("Login");
  const [isRegister, setIsRegister] = useState(false);
  const [emailAddress, setEmailAddress] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [notify, setNotify] = useState({
    open: false,
    message: "",
    severity: "",
  });
  const dispatch = useDispatch();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isError) {
      setLoading(false);
      setNotify({
        open: true,
        severity: "error",
        message: message,
      });
    }
    if (user && isSuccess) {
      setNotify({
        open: true,
        severity: "success",
        message: message,
      });
      setLoading(false);
      setOpenLogin(false);
    }
    dispatch(reset());
  }, [dispatch, isError, isSuccess, message, setLoading, setOpenLogin, user]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!isRegister) {
      setLoading(true);
      dispatch(LoginUser({ emailAddress, password }));
    } else {
      setLoading(true);
      dispatch(SignUser({ emailAddress, password, confirmPassword }));
    }
  };

  useEffect(() => {
    isRegister ? setTitle("Register") : setTitle("Login");
  }, [isRegister]);

  return (
    <>
      <Dialog open={openLogin} onClose={() => setOpenLogin(false)}>
        <DialogTitle>
          <strong>{title}</strong>
          <IconButton
            sx={{
              position: "absolute",
              top: 8,
              right: 8,
              color: (theme) => theme.palette.grey[500],
            }}
            onClick={() => setOpenLogin(false)}
          >
            <Close />
          </IconButton>
        </DialogTitle>
        <form onSubmit={handleSubmit}>
          <DialogContent>
            <DialogContentText>
              Please fill in your login credentials
            </DialogContentText>
            <TextField
              autoFocus
              margin="normal"
              variant="standard"
              id="emailAddress"
              label="Email Address"
              type="email"
              value={emailAddress}
              onChange={(e) => setEmailAddress(e.target.value)}
              fullWidth
              required
            />
            <PasswordField
              name="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            {isRegister && (
              <PasswordField
                id="confirmPassword"
                name="confirmPassword"
                label="Confirm Password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
              />
            )}
          </DialogContent>
          <DialogActions sx={{ px: "19px" }}>
            <Button type="submit" variant="contained" endIcon={<Send />}>
              Submit
            </Button>
          </DialogActions>
        </form>
        <DialogActions sx={{ justifyContent: "left", p: "5px 24px" }}>
          {isRegister
            ? "Do you have an account? Sign in now..."
            : "Don`t have an account, create one"}
          <Button onClick={() => setIsRegister(!isRegister)}>
            {isRegister ? "Login" : "Register"}
          </Button>
        </DialogActions>
      </Dialog>
      <Loading loading={loading} />
      <Notification notify={notify} setNotify={setNotify} />
    </>
  );
};

export default Authorization;
