import React, { useState, useEffect } from "react";
import Avatar from "@mui/material/Avatar";
import Button from "@mui/material/Button";
import CssBaseline from "@mui/material/CssBaseline";
import TextField from "@mui/material/TextField";
import FormControlLabel from "@mui/material/FormControlLabel";
import Checkbox from "@mui/material/Checkbox";
import Link from "@mui/material/Link";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Container from "@mui/material/Container";
import logo from "./dms_login.png";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { DriverSignIn, reset } from "../../functions/driverAuthSlice";
import Loading from "../../utils/Loading";
import Notification from "../../utils/Notification";
import { createTheme, ThemeProvider } from "@mui/material/styles";

const tealTheme = createTheme({
  palette: {
    primary: {
      main: "#00897B", // Teal color
    },
    secondary: {
      main: "#1de9b6", // Some other color for secondary
    },
  },
});

export default function SignIn() {
  const [licence_no, setLicence] = useState("");
  const [password, setPassword] = useState("");
  const { truck, isError, isSuccess, message } = useSelector(
    (state) => state.trucks
  );
  const [notify, setNotify] = useState({
    open: false,
    message: "",
    severity: "",
  });
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isError) {
      setLoading(false);
      setNotify({
        open: true,
        severity: "error",
        message: message,
      });
    }
    if (truck && isSuccess) {
      setNotify({
        open: true,
        severity: "success",
        message: message,
      });
      setLoading(false);
      navigate("/home");
    }
    //dispatch(reset());
  }, [truck, isError, isSuccess, message, setLoading, navigate, dispatch]);

  const handleSubmit = (e) => {
    e.preventDefault();
    setLoading(true);
    dispatch(DriverSignIn({ licence_no, password }));
  };

  return (
    <ThemeProvider theme={tealTheme}>
      <Container component="main" maxWidth="xs">
        <CssBaseline />
        <Box
          sx={{
            marginTop: 8,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
          }}
        >
          <Avatar sx={{ m: 1 }}>
            <img src={logo} style={{ width: 200, height: 200 }} />
          </Avatar>
          <Typography component="h1" variant="h5">
            Driver Sign in
          </Typography>
          <Box
            component="form"
            onSubmit={handleSubmit}
            noValidate
            sx={{ mt: 1 }}
          >
            <TextField
              margin="normal"
              required
              fullWidth
              id="licence_no"
              label="Licence no"
              name="licence_no"
              autoComplete="licence_no"
              variant="outlined"
              value={licence_no}
              onChange={(e) => setLicence(e.target.value)}
              autoFocus
            />
            <TextField
              margin="normal"
              variant="outlined"
              required
              fullWidth
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              name="password"
              label="Password"
              type="password"
              id="password"
              autoComplete="current-password"
            />
            <FormControlLabel
              control={<Checkbox value="remember" color="primary" />}
              label="Remember me"
            />
            <Button
              type="submit"
              fullWidth
              variant="contained"
              sx={{ mt: 3, mb: 2 }}
            >
              Sign In
            </Button>
            <Grid container>
              <Grid item xs>
                <Link href="" variant="body2">
                  Forgot password?
                </Link>
              </Grid>
              <Grid item>
                <Link href="/signup" variant="body2">
                  {"Don't have an account? Sign Up"}
                </Link>
              </Grid>
            </Grid>
          </Box>
        </Box>
      </Container>
      <Loading loading={loading} />
      <Notification notify={notify} setNotify={setNotify} />
    </ThemeProvider>
  );
}
