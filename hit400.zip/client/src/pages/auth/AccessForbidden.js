import React from "react";
import { Alert, AlertTitle, Button, Container } from "@mui/material";
import { Lock } from "@mui/icons-material";
import { useNavigate } from "react-router-dom";

const AccessForbidden = () => {
  const navigate = useNavigate();
  return (
    <>
      <Container sx={{ py: 5, marginTop: 5 }}>
        <Alert severity="error" variant="outlined">
          <AlertTitle>Forbidden Access</AlertTitle>
          Please login or register to access the system pages
          <Button
            variant="outlined"
            sx={{ ml: 2 }}
            startIcon={<Lock />}
            onClick={() => navigate("/signin")}
          >
            login
          </Button>
        </Alert>
      </Container>
    </>
  );
};

export default AccessForbidden;
