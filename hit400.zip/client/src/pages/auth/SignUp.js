import React, { useState, useEffect } from "react";
import Avatar from "@mui/material/Avatar";
import Button from "@mui/material/Button";
import CssBaseline from "@mui/material/CssBaseline";
import TextField from "@mui/material/TextField";
import Link from "@mui/material/Link";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Container from "@mui/material/Container";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import Loading from "../../utils/Loading";
import Notification from "../../utils/Notification";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import { SignUpDriver, reset } from "../../functions/driverAuthSlice";
import logo from "./dms_login.png";

const tealTheme = createTheme({
  palette: {
    primary: {
      main: "#00897B", // Teal color
    },
    secondary: {
      main: "#1de9b6", // Some other color for secondary
    },
  },
});

export default function SignUp() {
  const [emailAddress, setEmailAddress] = useState("");
  const [licence, setLicence] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const { truck, isError, isSuccess, message } = useSelector(
    (state) => state.trucks
  );

  const [notify, setNotify] = useState({
    open: false,
    message: "",
    severity: "",
  });
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isError) {
      setLoading(false);
      setNotify({
        open: true,
        severity: "error",
        message: message,
      });
    }
    if (truck && isSuccess) {
      setNotify({
        open: true,
        severity: "success",
        message: message,
      });
      setLoading(false);
      navigate("/signin");
    }
    //dispatch(reset());
  }, [dispatch, isError, isSuccess, message, setLoading, truck, navigate]);

  const handleSubmit = (e) => {
    e.preventDefault();
    setLoading(true);
    dispatch(
      SignUpDriver({ emailAddress, licence, password, confirmPassword })
    );
  };

  return (
    <ThemeProvider theme={tealTheme}>
      <Container component="main" maxWidth="xs">
        <CssBaseline />
        <Box
          sx={{
            marginTop: 8,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
          }}
        >
          <Avatar sx={{ m: 1 }}>
            <img src={logo} style={{ width: 200, height: 200 }} />
          </Avatar>
          <Typography component="h1" variant="h5">
            Sign up
          </Typography>
          <Box
            component="form"
            noValidate
            onSubmit={handleSubmit}
            sx={{ mt: 3 }}
          >
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <TextField
                  autoComplete="email"
                  name="emailAddress"
                  required
                  fullWidth
                  id="emailAddress"
                  label="Email Address"
                  value={emailAddress}
                  onChange={(e) => setEmailAddress(e.target.value)}
                  autoFocus
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  id="licence"
                  label="Licence no"
                  name="licence"
                  value={licence}
                  onChange={(e) => setLicence(e.target.value)}
                  autoComplete="licence"
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  name="password"
                  label="Password"
                  type="password"
                  id="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  autoComplete="new-password"
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  id="confirmPassword"
                  label="Confirm password"
                  name="confirmPassword"
                  type="password"
                  autoComplete="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                />
              </Grid>
            </Grid>
            <Button
              type="submit"
              fullWidth
              variant="contained"
              sx={{ mt: 3, mb: 2 }}
            >
              Sign Up
            </Button>
            <Grid container justifyContent="flex-end">
              <Grid item>
                <Link href="/signin" variant="body2">
                  Already have an account? Sign in
                </Link>
              </Grid>
            </Grid>
          </Box>
        </Box>
      </Container>
      <Loading loading={loading} />
      <Notification notify={notify} setNotify={setNotify} />
    </ThemeProvider>
  );
}
