import React, { useEffect, useState } from "react";
import {
  Chart as ChartJS,
  BarElement,
  CategoryScale,
  LinearScale,
} from "chart.js";
import { Bar } from "react-chartjs-2";
import { GetFleetOrders } from "../../functions/orderSlice";
import Title from "../../utils/Title";

ChartJS.register(BarElement, CategoryScale, LinearScale);

export default function BarChart() {
  const [chart, setChart] = useState([]);

  const GetFleetVsOrders = async () => {
    try {
      const response = await GetFleetOrders();
      setChart(response.data);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    GetFleetVsOrders();
  }, []);

  var data = {
    labels: chart?.map((x) => x.make),
    datasets: [
      {
        label: "Orders",
        data: chart?.map((x) => x.total),
        backgroundColor: ["rgba(54, 162, 235, 1)"],
        borderColor: ["rgba(54, 162, 235, 1)"],
        borderWidth: 1,
      },
    ],
  };

  var options = {
    maintainAspectRatio: false,
    scales: {},
    legend: {
      labels: {
        fontSize: 25,
      },
    },
  };
  return (
    <div>
      <Title>Fleet deliveries</Title>
      <div
        class="chart-container"
        style={{ position: "relative", height: "40vh" }}
      >
        <Bar data={data} height={450} options={options} />
      </div>
    </div>
  );
}
