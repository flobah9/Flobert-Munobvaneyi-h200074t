import React, { useEffect, useState } from "react";
import PageHeader from "../utils/PageHeader";
import { ManageAccountsTwoTone } from "@mui/icons-material";
import { Paper, Grid, TextField, Stack } from "@mui/material";
import ReactMapGL, {
  GeolocateControl,
  Marker,
  NavigationControl,
} from "react-map-gl";
import "mapbox-gl/dist/mapbox-gl.css";
import Controls from "../components/Controls";
import { Send } from "@mui/icons-material";
import { useDispatch, useSelector } from "react-redux";
import { RegisterCompany, reset } from "../functions/companySlice";
import Loading from "../utils/Loading";
import Notification from "../utils/Notification";

export default function CompanyProfile() {
  const [companyName, setCompanyName] = useState("");
  const [phoneNumber, setPhone] = useState("");
  const [emailAddress, setEmailAddress] = useState("");
  const [location, setLocation] = useState("");
  const [lng, setlng] = useState(0);
  const [lat, setlat] = useState(0);
  const [notify, setNotify] = useState({
    open: false,
    message: "",
    severity: "",
  });
  const [loading, setLoading] = useState(false);
  const { company, isError, isSuccess, message } = useSelector(
    (state) => state.company
  );
  const dispatch = useDispatch();

  useEffect(() => {
    if (isError) {
      setLoading(false);
      setNotify({
        open: true,
        severity: "error",
        message: message,
      });
    }
    if (company && isSuccess) {
      setLoading(false);
      setNotify({
        open: true,
        severity: "success",
        message: message,
      });
    }
    dispatch(reset());
  }, [isError, isSuccess, company, dispatch, message]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (lng === 0 || lat === 0) {
      setNotify({
        open: true,
        severity: "error",
        message: "Provide location, longitude and lattitude can not be 0!!!",
      });
    } else {
      const company_details = {
        companyName: companyName,
        emailAddress: emailAddress,
        phoneNumber: phoneNumber,
        location: location,
        lng: lng,
        lat: lat,
      };
      setLoading(true);
      dispatch(RegisterCompany(company_details));
    }
  };

  return (
    <>
      <PageHeader
        title="DMS | Company Profile"
        icon={<ManageAccountsTwoTone fontSize="large" />}
      />
      <Paper>
        <Stack
          sx={{
            alignItems: "center",
            "& .MuiTextField-root": { width: "100%", maxWidth: 500, m: 1 },
          }}
        >
          <Grid container>
            <Grid item xs={6}>
              <TextField
                name="companyName"
                id="companyName"
                label="Company Name"
                variant="outlined"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                required
              />
              <TextField
                name="phoneNumber"
                id="phoneNumber"
                label="Phone (tel)"
                variant="outlined"
                value={phoneNumber}
                onChange={(e) => setPhone(e.target.value)}
                required
              />
              <TextField
                name="emailAddress"
                id="emailAddress"
                label="Email Address"
                variant="outlined"
                value={emailAddress}
                onChange={(e) => setEmailAddress(e.target.value)}
                required
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                name="location"
                id="location"
                label="Company address"
                variant="outlined"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                multiline
                rows={6}
                required
              />
            </Grid>
          </Grid>
        </Stack>
        <Stack sx={{ height: "100vh", display: "flex", position: "relative" }}>
          <ReactMapGL
            mapboxAccessToken="pk.eyJ1Ijoid2FiYW50dS13YXhvIiwiYSI6ImNsdjE2a3c1cDA0N20yanVzaWs2Mng2d2YifQ.DWfNt-TLsGUujYIgwmMQYw"
            initialViewState={{
              longitude: lng,
              latitude: lat,
              zoom: 8,
            }}
            mapStyle="mapbox://styles/mapbox/streets-v11"
          >
            <Marker
              latitude={lat}
              longitude={lng}
              draggable
              onDragEnd={(e) => {
                setlng(e.lngLat.lng);
                setlat(e.lngLat.lat);
              }}
            />
            <NavigationControl position="bottom-right" />
            <GeolocateControl
              position="top-left"
              trackUserLocation
              onGeolocate={(e) => {
                setlng(e.coords.longitude);
                setlat(e.coords.latitude);
              }}
            />
          </ReactMapGL>
        </Stack>
        <div className="row">
          <Controls.Button
            type="submit"
            text="Submit"
            startIcon={<Send />}
            onClick={handleSubmit}
          />
        </div>
      </Paper>
      <Loading loading={loading} />
      <Notification notify={notify} setNotify={setNotify} />
    </>
  );
}
