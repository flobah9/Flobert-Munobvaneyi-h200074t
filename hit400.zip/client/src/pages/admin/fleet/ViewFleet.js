import React from "react";
import { Form } from "../../../utils/useForm";
import { Grid, Typography } from "@mui/material";
import Controls from "../../../components/Controls";

export default function ViewFleet({ flt }) {
  return (
    <Form>
      <Grid container>
        <Grid item xs={6}>
          <Typography varient="h6" color="primary" marginLeft="5px">
            Truck details
          </Typography>
          <Controls.Input
            name="fleetNo"
            label="fleetNo"
            value={flt?.fleetNo}
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="make"
            label="Make"
            value={flt?.make}
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="type"
            label="Class of truck"
            value={flt?.class}
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="engine_size"
            label="Engine size"
            value={flt?.engine_size}
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="payload_capacity"
            label="Payload capacity"
            value={flt?.payload_capacity}
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="status"
            label="Status"
            value={flt?.fleet_status?.status}
            inputProps={{ readOnly: true }}
          />
        </Grid>
        <Grid item xs={6}>
          <Typography varient="h6" color="primary" marginLeft="5px">
            Assigned driver details
          </Typography>
          <Controls.Input
            name="firstName"
            label="Firstname"
            value={flt?.driver_personal_detail?.firstName}
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="lastName"
            label="lastname"
            value={flt?.driver_personal_detail?.lastName}
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="licence_no"
            label="Licence no"
            value={flt?.driver_personal_detail?.licence_no}
            inputProps={{ readOnly: true }}
          />
        </Grid>
      </Grid>
    </Form>
  );
}
