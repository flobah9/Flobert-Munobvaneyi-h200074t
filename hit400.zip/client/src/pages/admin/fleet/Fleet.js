import React, { useEffect, useState } from "react";
import {
  Paper,
  Toolbar,
  InputAdornment,
  TableBody,
  TableRow,
  TableCell,
} from "@mui/material";
import PageHeader from "../../../utils/PageHeader";
import {
  FireTruckTwoTone,
  Search,
  Visibility,
  Edit,
  AddAlert,
} from "@mui/icons-material";
import Controls from "../../../components/Controls";
import useTable from "../../../utils/useTable";
import Popup from "../../../utils/Popup";
import AddOrEdit from "./AddOrEdit";
import { useDispatch, useSelector } from "react-redux";
import {
  AddNewFleet,
  UpdateFleet,
  getAllFleet,
  reset,
} from "../../../functions/fleetSlice";
import Loading from "../../../utils/Loading";
import Notification from "../../../utils/Notification";
import ViewFleet from "./ViewFleet";

const headCells = [
  { id: "id", label: "" },
  { id: "fleetNo", label: "Fleet no" },
  { id: "make", label: "Make" },
  { id: "class", label: "Class" },
  { id: "engine_size", label: "Engine size" },
  { id: "payload_capacity", label: "Capacity" },
  { id: "status", label: "Status" },
  { id: "actions", label: "Actions", disableSorting: true },
];

export default function Fleet() {
  const [records, setRecords] = useState([]);
  const [recordForEdit, setRecordForEdit] = useState(null);
  const [recordForView, setRecordForView] = useState(null);
  const [openPopup, setOpenPopup] = useState(false);
  const [open, setOpen] = useState(false);
  const dispatch = useDispatch();

  const { user } = useSelector((state) => state.auth);
  const { fleet, isError, isSuccess, message } = useSelector(
    (state) => state.fleet
  );

  const [filterFn, setFilterFn] = useState({
    fn: (items) => {
      return items;
    },
  });
  const { TblContainer, TblHead, TblPagination, recordsAfterPagingAndSorting } =
    useTable(records, headCells, filterFn);

  const [notify, setNotify] = useState({
    open: false,
    message: "",
    severity: "",
  });
  const [loading, setLoading] = useState(false);
  const [reloadData, setReloadData] = useState(false);

  const handleSearch = (e) => {
    let target = e.target;
    setFilterFn({
      fn: (items) => {
        if (target.value === "") return items;
        else
          return items.filter((x) =>
            x.make.toLowerCase().includes(target.value)
          );
      },
    });
  };

  //retrieve all fleet data
  async function fleetData() {
    try {
      let response = await getAllFleet();
      setRecords(response.data);
    } catch (error) {
      console.log(error);
    }
  }

  useEffect(() => {
    if (reloadData) {
      fleetData();
      setReloadData(false);
    } else {
      fleetData();
    }
  }, [reloadData]);

  useEffect(() => {
    if (isError) {
      setLoading(false);
      setNotify({
        open: true,
        severity: "error",
        message: message,
      });
    }
    if (fleet && isSuccess) {
      setLoading(false);
      setOpenPopup(false);
      setNotify({
        open: true,
        severity: "success",
        message: message,
      });
    }
    dispatch(reset());
  }, [dispatch, fleet, isError, isSuccess, message]);

  //function to eiither add or edit fleet details
  const addOrEdit = async (fleet_details, resetForm) => {
    try {
      //update existing fleet details
      if (fleet_details.id) {
        setLoading(true);
        dispatch(
          UpdateFleet({
            id: fleet_details.id,
            fleet_details: fleet_details,
          })
        );

        //add new employee if does not exists
      } else {
        setLoading(true);
        dispatch(AddNewFleet(fleet_details));
      }
      setReloadData(true);
      resetForm();
    } catch (error) {
      console.log(error);
    }
  };

  const openInPopup = (fleet) => {
    setRecordForEdit(fleet);
    setOpenPopup(true);
  };

  const openInView = (detail) => {
    setRecordForView(detail);
    setOpen(true);
  };

  return (
    <>
      <PageHeader
        title="DMS | Fleet Management"
        subTitle="Fleet details and performance"
        icon={<FireTruckTwoTone fontSize="large" />}
      />
      <Paper
        sx={{
          margin: (theme) => theme.spacing(2),
          padding: (theme) => theme.spacing(1),
          flexGrow: 1,
          overflow: "auto",
        }}
      >
        <Toolbar
          sx={{
            display: "flex",
            flexDirection: "row",
            flexWrap: "nowrap",
            justifyContent: "space-between",
          }}
        >
          <Controls.Input
            label="Search employees"
            sx={{ width: "75%" }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Search />
                </InputAdornment>
              ),
            }}
            onChange={handleSearch}
          />
          {user && user.role === "Admin" ? (
            <Controls.Button
              text="Add_new"
              variant="outlined"
              startIcon={<AddAlert />}
              sx={{ position: "absolute", right: "10px" }}
              onClick={() => {
                setOpenPopup(true);
                setRecordForEdit(null);
              }}
            />
          ) : (
            ""
          )}
        </Toolbar>
        <TblContainer>
          <TblHead />
          <TableBody>
            {recordsAfterPagingAndSorting().map((fleet) => (
              <TableRow key={fleet.id}>
                <TableCell>{fleet.id}</TableCell>
                <TableCell>{fleet.fleetNo}</TableCell>
                <TableCell>{fleet.make}</TableCell>
                <TableCell>{fleet.class}</TableCell>
                <TableCell>{fleet.engine_size}</TableCell>
                <TableCell>{fleet.payload_capacity}</TableCell>
                <TableCell>{fleet?.fleet_status?.status}</TableCell>
                <TableCell>
                  {user && user.role === "Admin" ? (
                    <Controls.ActionButton
                      color="primary"
                      onClick={() => {
                        openInPopup(fleet);
                      }}
                    >
                      <Edit fontSize="small" />
                    </Controls.ActionButton>
                  ) : (
                    ""
                  )}
                  <Controls.ActionButton
                    color="secondary"
                    onClick={() => {
                      openInView(fleet);
                    }}
                  >
                    <Visibility fontSize="small" />
                  </Controls.ActionButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </TblContainer>
        <TblPagination />
      </Paper>
      <Popup
        title={
          recordForEdit ? "DMS | Update Fleet Details" : "DMS | Add New Fleet"
        }
        openPopup={openPopup}
        setOpenPopup={setOpenPopup}
      >
        <AddOrEdit recordForEdit={recordForEdit} addOrEdit={addOrEdit} />
      </Popup>
      <Popup title="Fleet profile" openPopup={open} setOpenPopup={setOpen}>
        <ViewFleet flt={recordForView} />
      </Popup>
      <Loading loading={loading} />
      <Notification notify={notify} setNotify={setNotify} />
    </>
  );
}
