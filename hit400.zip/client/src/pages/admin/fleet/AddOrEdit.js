import React, { useEffect } from "react";
import { useForm, Form } from "../../../utils/useForm";
import { Grid } from "@mui/material";
import Controls from "../../../components/Controls";
import { RestartAlt, Send } from "@mui/icons-material";
import { truckType } from "../../../functions/fleetSlice";

const initialFValues = {
  make: "",
  class: "Heavy",
  engine_size: "",
  payload_capacity: "",
};

export default function AddOrEdit(props) {
  const { recordForEdit, addOrEdit } = props;

  const validate = (fieldValues = values) => {
    let temp = { ...errors };
    if ("make" in fieldValues)
      temp.make = fieldValues.make ? "" : "Make is required.";
    if ("engine_size" in fieldValues)
      temp.engine_size = fieldValues.engine_size
        ? ""
        : "This field is required.";
    if ("payload_capacity" in fieldValues)
      temp.payload_capacity = fieldValues.payload_capacity
        ? ""
        : "Capacity is required.";
    setErrors({
      ...temp,
    });

    if (fieldValues === values)
      return Object.values(temp).every((x) => x === "");
  };

  const { values, setValues, errors, setErrors, handleInputChange, resetForm } =
    useForm(initialFValues, true, validate);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      addOrEdit(values, resetForm);
    }
  };

  useEffect(() => {
    if (recordForEdit != null)
      setValues({
        ...recordForEdit,
      });
    // eslint-disable-next-line
  }, [recordForEdit]);
  return (
    <Form onSubmit={handleSubmit}>
      <Grid container>
        <Grid item xs={12}>
          <Controls.Input
            name="make"
            label="Make"
            value={values.make}
            onChange={handleInputChange}
            error={errors.make}
          />
          <Controls.Input
            name="engine_size"
            label="Engine size"
            value={values.engine_size}
            onChange={handleInputChange}
            error={errors.engine_size}
          />
          <Controls.Input
            name="payload_capacity"
            label="Payload capacity"
            value={values.payload_capacity}
            onChange={handleInputChange}
            error={errors.payload_capacity}
          />
        </Grid>
        <Grid item xs={12}>
          <Controls.UserSelect
            name="class"
            label="Truck Type"
            value={values.type}
            onChange={handleInputChange}
            options={truckType()}
            sx={{ width: "100%" }}
          />
        </Grid>
        <Grid item xs={12}>
          <div className="row">
            <Controls.Button type="submit" text="Submit" startIcon={<Send />} />
            <Controls.Button
              text="Reset"
              color="error"
              startIcon={<RestartAlt />}
              onClick={resetForm}
            />
          </div>
        </Grid>
      </Grid>
    </Form>
  );
}
