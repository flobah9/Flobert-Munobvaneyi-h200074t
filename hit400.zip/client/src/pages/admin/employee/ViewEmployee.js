import React from "react";
import { Form } from "../../../utils/useForm";
import { Grid, Typography } from "@mui/material";
import Controls from "../../../components/Controls";

export default function ViewEmployee({ empl }) {
  return (
    <Form>
      <Grid container>
        <Grid item xs={6}>
          <Typography varient="h6" color="primary" marginLeft="5px">
            Employee details
          </Typography>
          <Controls.Input
            name="firstName"
            label="Firstname"
            value={empl.firstName}
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="lastName"
            label="lastname"
            value={empl.lastName}
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="ID_number"
            label="ID_number"
            value={empl.ID_number}
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="phoneNumber"
            label="phoneNumber"
            value={empl.phoneNumber}
            inputProps={{ readOnly: true }}
          />
        </Grid>
        <Grid item xs={6}>
          <Controls.Input
            name="emailAddress"
            label="emailAddress"
            value={empl.emailAddress}
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="homeAddress"
            label="homeAddress"
            value={empl.homeAddress}
            inputProps={{ readOnly: true }}
            multiline
            rows={2}
          />
          <Controls.Input
            name="role"
            label="role"
            value={empl.role}
            inputProps={{ readOnly: true }}
          />
        </Grid>
      </Grid>
    </Form>
  );
}
