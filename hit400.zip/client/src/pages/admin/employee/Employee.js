import React, { useEffect, useState } from "react";
import PageHeader from "../../../utils/PageHeader";
import useTable from "../../../utils/useTable";
import Popup from "../../../utils/Popup";
import Controls from "../../../components/Controls";
import { useNavigate } from "react-router-dom";
import {
  AddAlert,
  Edit,
  PeopleOutlineTwoTone,
  TaxiAlert,
  Search,
  Visibility,
} from "@mui/icons-material";
import {
  InputAdornment,
  Paper,
  TableBody,
  Toolbar,
  TableCell,
  TableRow,
} from "@mui/material";
import AddOrEdit from "./AddOrEdit";
import {
  AddNewEmployee,
  UpdateEmployee,
  getAllEmployee,
  reset,
} from "../../../functions/employeeSlice";
import { useDispatch, useSelector } from "react-redux";
import Loading from "../../../utils/Loading";
import Notification from "../../../utils/Notification";
import ViewEmployee from "./ViewEmployee";

const headCells = [
  { id: "id", label: "" },
  { id: "firstName", label: "First name" },
  { id: "lastName", label: "Last name" },
  { id: "email", label: "Email Address " },
  { id: "phone", label: "Phone Number" },
  { id: "role", label: "Role" },
  { id: "actions", label: "Actions", disableSorting: true },
];

export default function Employee() {
  const [records, setRecords] = useState([]);
  const [recordForEdit, setRecordForEdit] = useState(null);
  const [recordForView, setRecordForView] = useState(null);
  const [openPopup, setOpenPopup] = useState(false);
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const { user } = useSelector((state) => state.auth);

  const { employee, isError, isSuccess, message } = useSelector(
    (state) => state.employee
  );
  const [filterFn, setFilterFn] = useState({
    fn: (items) => {
      return items;
    },
  });

  const [notify, setNotify] = useState({
    open: false,
    message: "",
    severity: "",
  });
  const [loading, setLoading] = useState(false);
  const [reloadData, setReloadData] = useState(false);

  const { TblContainer, TblHead, TblPagination, recordsAfterPagingAndSorting } =
    useTable(records, headCells, filterFn);

  const handleSearch = (e) => {
    let target = e.target;
    setFilterFn({
      fn: (items) => {
        if (target.value === "") return items;
        else
          return items.filter((x) =>
            x.firstName.toLowerCase().includes(target.value)
          );
      },
    });
  };

  async function employeeData() {
    try {
      const response = await getAllEmployee();
      setRecords(response.data);
    } catch (error) {
      console.log(error);
    }
  }

  useEffect(() => {
    if (reloadData) {
      employeeData();
      setReloadData(false);
    } else {
      employeeData();
    }
  }, [reloadData]);

  useEffect(() => {
    if (isError) {
      setLoading(false);
      setNotify({
        open: true,
        severity: "error",
        message: message,
      });
    }
    if (employee && isSuccess) {
      setLoading(false);
      setOpenPopup(false);
      setNotify({
        open: true,
        severity: "success",
        message: message,
      });
    }
    dispatch(reset());
  }, [dispatch, employee, isError, isSuccess, message]);

  //function to eiither add or edit employee details
  const addOrEdit = async (employee_details, resetForm) => {
    try {
      //update existing employee details
      if (employee_details.id) {
        setLoading(true);
        dispatch(
          UpdateEmployee({
            id: employee_details.id,
            employee_details: employee_details,
          })
        );
      }

      //add new employee if does not exists
      else {
        setLoading(true);
        dispatch(AddNewEmployee(employee_details));
      }
      setReloadData(true);
      resetForm();
    } catch (error) {
      console.log(error);
    }
  };

  const openInPopup = (empl) => {
    setRecordForEdit(empl);
    setOpenPopup(true);
  };

  const openInView = (detail) => {
    setRecordForView(detail);
    setOpen(true);
  };

  return (
    <>
      <PageHeader
        title="DMS | Employee Management"
        subTitle="Employee List"
        icon={<PeopleOutlineTwoTone fontSize="large" />}
      />
      <Paper
        sx={{
          margin: (theme) => theme.spacing(2),
          padding: (theme) => theme.spacing(1),
          flexGrow: 1,
          overflow: "auto",
        }}
      >
        <Toolbar
          sx={{
            display: "flex",
            flexDirection: "row",
            flexWrap: "nowrap",
            justifyContent: "space-between",
          }}
        >
          <Controls.Input
            label="Search employees"
            sx={{ width: "60%" }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Search />
                </InputAdornment>
              ),
            }}
            onChange={handleSearch}
          />
          {user && user.role === "Admin" ? (
            <>
              <Controls.Button
                text="Add_new"
                variant="outlined"
                startIcon={<AddAlert />}
                onClick={() => {
                  setOpenPopup(true);
                  setRecordForEdit(null);
                }}
              />
              <Controls.Button
                text="Drivers"
                variant="outlined"
                startIcon={<TaxiAlert />}
                sx={{ position: "absolute", right: "10px" }}
                onClick={() => navigate("/drivers")}
              />
            </>
          ) : (
            ""
          )}
        </Toolbar>
        <TblContainer>
          <TblHead />
          <TableBody>
            {recordsAfterPagingAndSorting().map((empl) => (
              <TableRow key={empl.id}>
                <TableCell>{empl.id}</TableCell>
                <TableCell>{empl.firstName}</TableCell>
                <TableCell>{empl.lastName}</TableCell>
                <TableCell>{empl.emailAddress}</TableCell>
                <TableCell>{empl.phoneNumber}</TableCell>
                <TableCell>{empl.role}</TableCell>
                <TableCell>
                  {user && user.role === "Admin" ? (
                    <Controls.ActionButton
                      color="primary"
                      onClick={() => {
                        openInPopup(empl);
                      }}
                    >
                      <Edit fontSize="small" />
                    </Controls.ActionButton>
                  ) : (
                    ""
                  )}
                  <Controls.ActionButton
                    color="secondary"
                    onClick={() => {
                      openInView(empl);
                    }}
                  >
                    <Visibility fontSize="small" />
                  </Controls.ActionButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </TblContainer>
        <TblPagination />
      </Paper>
      <Popup
        title={
          recordForEdit
            ? "DMS | Update Employee Details"
            : "DMS | Add New Employee"
        }
        openPopup={openPopup}
        setOpenPopup={setOpenPopup}
      >
        <AddOrEdit recordForEdit={recordForEdit} addOrEdit={addOrEdit} />
      </Popup>
      <Popup title="Employee profile" openPopup={open} setOpenPopup={setOpen}>
        <ViewEmployee empl={recordForView} />
      </Popup>
      <Loading loading={loading} />
      <Notification notify={notify} setNotify={setNotify} />
    </>
  );
}
