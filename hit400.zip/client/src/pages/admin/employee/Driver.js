import React, { useEffect, useState } from "react";
import PageHeader from "../../../utils/PageHeader";
import useTable from "../../../utils/useTable";
import Popup from "../../../utils/Popup";
import Controls from "../../../components/Controls";
import {
  AddAlert,
  Edit,
  PeopleOutlineTwoTone,
  PersonPin,
  Search,
  Visibility,
} from "@mui/icons-material";
import {
  InputAdornment,
  Paper,
  TableBody,
  Toolbar,
  TableCell,
  TableRow,
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import AddDriver from "./AddDriver";
import { useDispatch, useSelector } from "react-redux";
import {
  AddNewDriver,
  UpdateDriver,
  getAllDrivers,
  reset,
} from "../../../functions/driverSlice";
import Loading from "../../../utils/Loading";
import Notification from "../../../utils/Notification";
import ViewDriver from "./ViewDriver";

const headCells = [
  { id: "id", label: "" },
  { id: "firstName", label: "First name" },
  { id: "lastName", label: "Last name" },
  { id: "email", label: "Email Address " },
  { id: "phone", label: "Phone Number" },
  { id: "licence_no", label: "licence_no" },
  { id: "actions", label: "Actions", disableSorting: true },
];

export default function Driver() {
  const [records, setRecords] = useState([]);
  const [recordForEdit, setRecordForEdit] = useState(null);
  const [openPopup, setOpenPopup] = useState(false);
  const [open, setOpen] = useState(false);
  const [recordForView, setRecordForView] = useState(null);
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const { user } = useSelector((state) => state.auth);

  const { driver, isError, isSuccess, message } = useSelector(
    (state) => state.driver
  );

  const [notify, setNotify] = useState({
    open: false,
    message: "",
    severity: "",
  });
  const [loading, setLoading] = useState(false);
  const [reloadData, setReloadData] = useState(false);

  const [filterFn, setFilterFn] = useState({
    fn: (items) => {
      return items;
    },
  });

  const { TblContainer, TblHead, TblPagination, recordsAfterPagingAndSorting } =
    useTable(records, headCells, filterFn);

  const handleSearch = (e) => {
    let target = e.target;
    setFilterFn({
      fn: (items) => {
        if (target.value === "") return items;
        else
          return items.filter((x) =>
            x.firstName.toLowerCase().includes(target.value)
          );
      },
    });
  };

  async function getDriversData() {
    try {
      let response = await getAllDrivers();
      setRecords(response.data);
    } catch (error) {
      console.log(error);
    }
  }

  useEffect(() => {
    if (reloadData) {
      getDriversData();
      setReloadData(false);
    } else {
      getDriversData();
    }
  }, [reloadData]);

  useEffect(() => {
    if (isError) {
      setLoading(false);
      setNotify({
        open: true,
        severity: "error",
        message: message,
      });
    }
    if (driver && isSuccess) {
      setLoading(false);
      setOpenPopup(false);
      setNotify({
        open: true,
        severity: "success",
        message: message,
      });
    }
    dispatch(reset());
  }, [dispatch, driver, isError, isSuccess, message]);

  //function to eiither add or edit driver details
  const addOrEdit = async (driver_details, resetForm) => {
    try {
      if (driver_details.id) {
        setLoading(true);
        dispatch(
          UpdateDriver({
            id: driver_details.id,
            driver_details: driver_details,
          })
        );
      }
      //add new driver if does not exists
      else {
        setLoading(true);
        dispatch(AddNewDriver(driver_details));
      }
      setReloadData(true);
      resetForm();
    } catch (error) {
      console.log(error);
    }
  };

  const openInPopup = (drv) => {
    setRecordForEdit(drv);
    setOpenPopup(true);
  };

  const openInView = (drv) => {
    setRecordForView(drv);
    setOpen(true);
  };

  return (
    <>
      <PageHeader
        title="DMS | Employee Management"
        subTitle="Driver's List"
        icon={<PeopleOutlineTwoTone fontSize="large" />}
      />
      <Paper
        sx={{
          margin: (theme) => theme.spacing(2),
          padding: (theme) => theme.spacing(1),
          flexGrow: 1,
          overflow: "auto",
        }}
      >
        <Toolbar
          sx={{
            display: "flex",
            flexDirection: "row",
            flexWrap: "nowrap",
            justifyContent: "space-between",
          }}
        >
          <Controls.Input
            label="Search employees"
            sx={{ width: "60%" }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Search />
                </InputAdornment>
              ),
            }}
            onChange={handleSearch}
          />
          {user && user.role === "Admin" ? (
            <>
              <Controls.Button
                text="Add_new"
                variant="outlined"
                startIcon={<AddAlert />}
                onClick={() => {
                  setOpenPopup(true);
                  setRecordForEdit(null);
                }}
              />
              <Controls.Button
                text="Employees"
                variant="outlined"
                startIcon={<PersonPin />}
                sx={{ position: "absolute", right: "10px" }}
                onClick={() => navigate("/employee")}
              />
            </>
          ) : (
            ""
          )}
        </Toolbar>
        <TblContainer>
          <TblHead />
          <TableBody>
            {recordsAfterPagingAndSorting().map((drv) => (
              <TableRow key={drv.id}>
                <TableCell>{drv.id}</TableCell>
                <TableCell>{drv.firstName}</TableCell>
                <TableCell>{drv.lastName}</TableCell>
                <TableCell>{drv.emailAddress}</TableCell>
                <TableCell>{drv.phoneNumber}</TableCell>
                <TableCell>{drv.licence_no}</TableCell>
                <TableCell>
                  {user && user.role === "Admin" ? (
                    <Controls.ActionButton
                      color="primary"
                      onClick={() => {
                        openInPopup(drv);
                      }}
                    >
                      <Edit fontSize="small" />
                    </Controls.ActionButton>
                  ) : (
                    ""
                  )}
                  <Controls.ActionButton
                    color="secondary"
                    onClick={() => {
                      openInView(drv);
                    }}
                  >
                    <Visibility fontSize="small" />
                  </Controls.ActionButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </TblContainer>
        <TblPagination />
      </Paper>
      <Popup
        title={
          recordForEdit ? "DMS | Update Driver Details" : "DMS | Add New Driver"
        }
        openPopup={openPopup}
        setOpenPopup={setOpenPopup}
      >
        <AddDriver recordForEdit={recordForEdit} addOrEdit={addOrEdit} />
      </Popup>
      <Popup title="Driver's profile" openPopup={open} setOpenPopup={setOpen}>
        <ViewDriver drv={recordForView} />
      </Popup>
      <Loading loading={loading} />
      <Notification notify={notify} setNotify={setNotify} />
    </>
  );
}
