import React from "react";
import { Form } from "../../../utils/useForm";
import { Grid, Typography } from "@mui/material";
import Controls from "../../../components/Controls";

export default function ViewDriver({ drv }) {
  return (
    <Form>
      <Grid container>
        <Grid item xs={6}>
          <Typography varient="h6" color="primary" marginLeft="5px">
            Driver details
          </Typography>
          <Controls.Input
            name="firstName"
            label="Firstname"
            value={drv.firstName}
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="lastName"
            label="lastname"
            value={drv.lastName}
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="ID_number"
            label="ID_number"
            value={drv.ID_number}
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="licence_no"
            label="Licence no"
            value={drv.licence_no}
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="phoneNumber"
            label="phoneNumber"
            value={drv.phoneNumber}
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="emailAddress"
            label="emailAddress"
            value={drv.emailAddress}
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="homeAddress"
            label="homeAddress"
            value={drv.homeAddress}
            inputProps={{ readOnly: true }}
            multiline
            rows={2}
          />
        </Grid>
        <Grid item xs={6}>
          <Typography varient="h6" color="primary" marginLeft="5px">
            Assigned truck details
          </Typography>
          <Controls.Input
            name="fleetNo"
            label="fleetNo"
            value={drv?.fleet_detail?.fleetNo}
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="make"
            label="Make"
            value={drv?.fleet_detail?.make}
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="class"
            label="Class of truck"
            value={drv?.fleet_detail?.class}
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="engine_size"
            label="Engine size"
            value={drv?.fleet_detail?.engine_size}
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="payload_capacity"
            label="Payload capacity"
            value={drv?.fleet_detail?.payload_capacity}
            inputProps={{ readOnly: true }}
          />
        </Grid>
      </Grid>
    </Form>
  );
}
