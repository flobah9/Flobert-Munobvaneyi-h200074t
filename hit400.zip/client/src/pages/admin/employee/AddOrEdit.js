import React, { useEffect } from "react";
import { useForm, Form } from "../../../utils/useForm";
import { Grid } from "@mui/material";
import Controls from "../../../components/Controls";
import { userRoles } from "../../../functions/employeeSlice";
import { RestartAlt, Send } from "@mui/icons-material";

const initialFValues = {
  firstName: "",
  lastName: "",
  ID_number: "",
  emailAddress: "",
  phoneNumber: "",
  homeAddress: "",
  role: "User",
};

export default function AddOrEdit(props) {
  const { recordForEdit, addOrEdit } = props;

  const validate = (fieldValues = values) => {
    let temp = { ...errors };
    if ("firstName" in fieldValues)
      temp.firstName = fieldValues.firstName ? "" : "First name is required.";
    if ("lastName" in fieldValues)
      temp.lastName = fieldValues.lastName ? "" : "Last name is required.";
    if ("emailAddress" in fieldValues)
      temp.emailAddress = /$^|.+@.+..+/.test(fieldValues.emailAddress)
        ? ""
        : "Email is not valid.";
    if ("homeAddress" in fieldValues)
      temp.homeAddress = fieldValues.homeAddress
        ? ""
        : "This field is required.";
    if ("role" in fieldValues)
      temp.role = fieldValues.role ? "" : "User role is required.";
    setErrors({
      ...temp,
    });

    if (fieldValues === values)
      return Object.values(temp).every((x) => x === "");
  };

  const { values, setValues, errors, setErrors, handleInputChange, resetForm } =
    useForm(initialFValues, true, validate);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      if (validate()) {
        addOrEdit(values, resetForm);
      }
    }
  };

  useEffect(() => {
    if (recordForEdit != null)
      setValues({
        ...recordForEdit,
      });
    // eslint-disable-next-line
  }, [recordForEdit]);
  return (
    <Form onSubmit={handleSubmit}>
      <Grid container>
        <Grid item xs={6}>
          <Controls.Input
            name="firstName"
            label="Firstname"
            value={values.firstName}
            onChange={handleInputChange}
            error={errors.firstName}
          />
          <Controls.Input
            label="Lastname"
            name="lastName"
            value={values.lastName}
            onChange={handleInputChange}
            error={errors.lastName}
          />
          <Controls.Input
            label="Email Address"
            name="emailAddress"
            value={values.emailAddress}
            onChange={handleInputChange}
            error={errors.emailAddress}
          />
          <Controls.PhoneNumberInput
            label="Phone number"
            name="phoneNumber"
            id="phoneNumber"
            enableSearch={true}
            value={values.phoneNumber}
            onChange={(e) =>
              handleInputChange({ target: { value: e, name: "phoneNumber" } })
            }
            inputProps={{
              required: true,
            }}
          />
        </Grid>
        <Grid item xs={6}>
          <Controls.Input
            name="ID_number"
            label="ID_number"
            value={values.ID_number}
            onChange={handleInputChange}
          />
          <Controls.Input
            name="homeAddress"
            label="Home Address"
            multiline
            rows={4}
            value={values.homeAddress}
            onChange={handleInputChange}
          />
          <Controls.UserSelect
            name="role"
            label="User role"
            value={values.role}
            onChange={handleInputChange}
            options={userRoles()}
          />
          <div className="row">
            <Controls.Button type="submit" text="Submit" startIcon={<Send />} />
            <Controls.Button
              text="Reset"
              color="error"
              startIcon={<RestartAlt />}
              onClick={resetForm}
            />
          </div>
        </Grid>
      </Grid>
    </Form>
  );
}
