import { Box, Grid, Stack, Skeleton } from "@mui/material";
import React, { useState, useEffect, useMemo } from "react";
import Controls from "../../../components/Controls";
import ReactMapGL, {
  Marker,
  NavigationControl,
  FullscreenControl,
  Layer,
  Source,
} from "react-map-gl";
import "mapbox-gl/dist/mapbox-gl.css";
import axios from "axios";
import "../../driver/main.css";
import { MyLocation } from "@mui/icons-material";

const mapboxAccessToken =
  "pk.eyJ1Ijoid2FiYW50dS13YXhvIiwiYSI6ImNsdjE2a3c1cDA0N20yanVzaWs2Mng2d2YifQ.DWfNt-TLsGUujYIgwmMQYw";

const BlinkingShareLocation = ({ position }) => (
  <MyLocation
    sx={{
      color: "blue",
      animation: "blink 1s infinite",
    }}
    style={{
      left: position.lng,
      top: position.lat,
    }}
  />
);

export default function ViewTrackOrder(props) {
  const { recordForTracking } = props;
  const [values, setValues] = useState([]);
  const [coords, setCoords] = useState([]);
  const [viewState, setViewState] = useState({
    longitude: 31.053028,
    latitude: -17.824858,
    zoom: 7,
  });
  const [location, setLocation] = useState({
    lng: recordForTracking.lng,
    lat: recordForTracking.lat,
  });

  const origin = useMemo(
    () => ({
      lng: recordForTracking?.route_detail?.originLng,
      lat: recordForTracking?.route_detail?.originLat,
    }),
    [recordForTracking]
  );

  const destination = useMemo(
    () => ({
      lng: recordForTracking?.route_detail?.destinationLng,
      lat: recordForTracking?.route_detail?.destinationLat,
    }),
    [recordForTracking]
  );

  useEffect(() => {
    const intervalId = setInterval(() => {
      setLocation({
        lng: recordForTracking.lng,
        lat: recordForTracking.lat,
      });
    }, 1000);

    return () => {
      clearInterval(intervalId);
    };
  }, [recordForTracking]);

  const fetchDirections = async (origin, destination) => {
    const response = await axios.get(
      `https://api.mapbox.com/directions/v5/mapbox/driving-traffic/${origin.lng},${origin.lat};${destination.lng},${destination.lat}?steps=true&geometries=geojson&access_token=${mapboxAccessToken}`
    );
    const data = response.data;
    const coords = data.routes[0].geometry.coordinates;
    setCoords(coords);
  };

  useEffect(() => {
    if (recordForTracking !== null) {
      setValues({ ...recordForTracking });
      console.log(location);
    }
  }, [recordForTracking]);

  useEffect(() => {
    if (origin && destination) {
      fetchDirections(origin, destination);
    }
  }, [origin, destination]);

  const geojson = {
    type: "FeatureCollection",
    features: [
      {
        type: "feature",
        geometry: {
          type: "LineString",
          coordinates: [...coords],
        },
      },
    ],
  };

  const lineStyle = {
    id: "roadLayer",
    type: "line",
    layout: {
      "line-join": "round",
      "line-cap": "round",
    },
    paint: {
      "line-color": "blue",
      "line-width": 4,
      "line-opacity": 0.75,
      "line-blur": 0.5,
    },
  };

  return (
    <Box width="100%" height="100%">
      <Grid container>
        <Grid item xs={6}>
          <Controls.Input
            name="customerName"
            label="Customer Name"
            variant="outlined"
            value={
              values?.route_detail?.order_detail?.customer_profile?.customerName
            }
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="location"
            label="Location"
            variant="outlined"
            value={
              values?.route_detail?.order_detail?.customer_profile?.location
            }
            inputProps={{ readOnly: true }}
            multiline
            rows={2}
          />
        </Grid>
        <Grid item xs={6}>
          <Controls.Input
            name="order"
            label="Order ID"
            variant="outlined"
            value={values?.route_detail?.order_detail?.orderID}
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="order"
            label="Order details"
            variant="outlined"
            value={values?.route_detail?.order_detail?.order_details}
            inputProps={{ readOnly: true }}
            multiline
            rows={2}
          />
        </Grid>
      </Grid>
      <Stack sx={{ height: "100vh", display: "flex", position: "relative" }}>
        <ReactMapGL
          {...viewState}
          mapboxAccessToken={mapboxAccessToken}
          mapStyle="mapbox://styles/mapbox/streets-v11"
          onMove={(e) => setViewState(e.viewState)}
        >
          <FullscreenControl />
          <NavigationControl showCompass showZoom position="top-right" />
          {coords ? (
            <>
              <Source id="routeSource" type="geojson" data={geojson}>
                <Layer {...lineStyle} />
              </Source>
            </>
          ) : (
            <Skeleton animation="wave" />
          )}
          <Marker longitude={origin.lng} latitude={origin.lat} />
          <Marker
            longitude={destination.lng}
            latitude={destination.lat}
            color="red"
          />
          <Marker longitude={location.lng} latitude={location.lat}>
            <BlinkingShareLocation position={location} />
          </Marker>
        </ReactMapGL>
      </Stack>
      <Grid container>
        <Grid item xs={6}>
          <Controls.Input
            name="fleetNo"
            label="Fleet no"
            variant="outlined"
            value={values?.route_detail?.order_detail?.fleet_detail?.fleetNo}
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="make"
            label="Make"
            variant="outlined"
            value={values?.route_detail?.order_detail?.fleet_detail?.make}
            inputProps={{ readOnly: true }}
          />
        </Grid>
        <Grid item xs={6}>
          <Controls.Input
            name="driver"
            label="Driver details"
            variant="outlined"
            value={`${values?.route_detail?.order_detail?.fleet_detail?.driver_personal_detail?.lastName} ${values?.route_detail?.order_detail?.fleet_detail?.driver_personal_detail?.firstName}`}
            inputProps={{ readOnly: true }}
          />
        </Grid>
      </Grid>
    </Box>
  );
}

//how to show location coordinates between the 2 markers and use a marker to show it as driver location
