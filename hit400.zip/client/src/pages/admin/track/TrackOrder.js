import React, { useEffect, useState } from "react";
import PageHeader from "../../../utils/PageHeader";
import { SpatialTrackingTwoTone, LocationSearching } from "@mui/icons-material";
import { Paper, TableBody, TableRow, TableCell } from "@mui/material";
import useTable from "../../../utils/useTable";
import Popup from "../../../utils/Popup";
import Controls from "../../../components/Controls";
import { getAllLocation } from "../../../functions/routeSlice";
import ViewTrackOrder from "./ViewTrackOrder";

const headCells = [
  { id: "id", label: "Order ID" },
  { id: "order_details", label: "Order" },
  { id: "fleetNo", label: "Fleet no" },
  { id: "make", label: "Make" },
  { id: "customerName", label: "Customer" },
  { id: "Location", label: "Location" },
  { id: "lastName", label: "Driver" },
  { id: "status", label: "Status" },
  { id: "actions", label: "Actions", disableSorting: true },
];

export default function TrackOrder() {
  const [records, setRecords] = useState([]);
  const [recordForTracking, setRecordForTracking] = useState(null);
  const [openPopup, setOpenPopup] = useState(false);
  const [filterFn, setFilterFn] = useState({
    fn: (items) => {
      return items;
    },
  });
  const { TblContainer, TblHead, TblPagination, recordsAfterPagingAndSorting } =
    useTable(records, headCells, filterFn);

  const handleSearch = (e) => {
    let target = e.target;
    setFilterFn({
      fn: (items) => {
        if (target.value === "") return items;
        else
          return items.filter((x) =>
            x.make.toLowerCase().includes(target.value)
          );
      },
    });
  };

  async function GetAllOrdersToTrack() {
    try {
      const response = await getAllLocation();
      setRecords(response.data);
    } catch (error) {
      console.log(error);
    }
  }

  useEffect(() => {
    const intervalId = setInterval(() => {
      GetAllOrdersToTrack();
    }, 1000);

    return () => {
      clearInterval(intervalId);
    };
  }, []);

  const openInPopup = (loc) => {
    setRecordForTracking(loc);
    setOpenPopup(true);
  };

  return (
    <>
      <PageHeader
        title="DMS | Real Time Tracking"
        subTitle="Track Orders"
        icon={<SpatialTrackingTwoTone fontSize="large" />}
      />
      <Paper
        sx={{
          margin: (theme) => theme.spacing(2),
          padding: (theme) => theme.spacing(1),
          flexGrow: 1,
          overflow: "auto",
        }}
      >
        <TblContainer>
          <TblHead />
          <TableBody>
            {recordsAfterPagingAndSorting().map((loc) => (
              <TableRow key={loc.id}>
                <TableCell>
                  {loc?.route_detail?.order_detail?.orderID}
                </TableCell>
                <TableCell>
                  {loc?.route_detail?.order_detail?.order_details}
                </TableCell>
                <TableCell>
                  {loc?.route_detail?.order_detail?.fleet_detail?.fleetNo}
                </TableCell>
                <TableCell>
                  {loc?.route_detail?.order_detail?.fleet_detail?.make}
                </TableCell>
                <TableCell>
                  {loc?.route_detail?.order_detail?.customerID}
                </TableCell>
                <TableCell>
                  {loc?.route_detail?.order_detail?.customer_profile?.location}
                </TableCell>
                <TableCell>
                  {
                    loc?.route_detail?.order_detail?.fleet_detail
                      ?.driver_personal_detail?.lastName
                  }
                </TableCell>
                <TableCell>{loc.status}</TableCell>
                <TableCell>
                  {loc.status !== "Delivered" && (
                    <Controls.ActionButton
                      color="primary"
                      onClick={() => {
                        openInPopup(loc);
                      }}
                    >
                      <LocationSearching fontSize="small" />
                    </Controls.ActionButton>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </TblContainer>
        <TblPagination />
      </Paper>
      <Popup
        title="DMS | Track Delivery Order"
        openPopup={openPopup}
        setOpenPopup={setOpenPopup}
      >
        <ViewTrackOrder recordForTracking={recordForTracking} />
      </Popup>
    </>
  );
}
