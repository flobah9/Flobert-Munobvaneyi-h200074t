import React, { useState, useEffect } from "react";
import PageHeader from "../utils/PageHeader";
import { styled } from "@mui/material/styles";
import { Container, Grid, Paper } from "@mui/material";
import NoteCard from "../utils/NoteCard";
import {
  AirlineSeatReclineExtra,
  Groups,
  LocalShipping,
  HomeTwoTone,
  ShoppingCart,
  ShoppingCartCheckout,
} from "@mui/icons-material";
import { countCustomers } from "../functions/customerSlice";
import { countFleet } from "../functions/fleetSlice";
import { countDrivers } from "../functions/driverSlice";
import { countCompletedOrders, countOrders } from "../functions/orderSlice";
import { useSelector } from "react-redux";
import BarChart from "./charts/BarChart";
import PieChat from "./charts/PieChat";

const PageContent = styled("div")(({ theme }) => ({
  margin: theme.spacing(0.5),
  padding: theme.spacing(0.5),
}));

const StyledContainer = styled(Container)(({ theme }) => ({
  paddingTop: theme.spacing(0.5),
  paddingBottom: theme.spacing(0.5),
}));

const StyledPaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(2),
  display: "flex",
  overflow: "auto",
  flexDirection: "column",
}));

export default function Home() {
  const [fleet, setFleet] = useState([]);
  const [drivers, setDrivers] = useState([]);
  const [customer, setCustomers] = useState([]);
  const [orders, setOrders] = useState([]);
  const [comp, setComp] = useState([]);
  const { user } = useSelector((state) => state.auth);

  useEffect(() => {
    async function countAllCustomers() {
      try {
        const response = await countCustomers();
        setCustomers(response.data);
      } catch (error) {
        console.log(error);
      }
    }
    countAllCustomers();
  }, []);

  useEffect(() => {
    async function countAllTrucks() {
      try {
        const response = await countFleet();
        setFleet(response.data);
      } catch (error) {
        console.log(error);
      }
    }
    countAllTrucks();
  }, []);

  useEffect(() => {
    async function countAllDrivers() {
      try {
        const response = await countDrivers();
        setDrivers(response.data);
      } catch (error) {
        console.log(error);
      }
    }
    countAllDrivers();
  }, []);

  useEffect(() => {
    async function countAllOrdersAvailable() {
      try {
        const response = await countOrders();
        setOrders(response.data);
      } catch (error) {
        console.log(error);
      }
    }
    countAllOrdersAvailable();
  }, []);

  useEffect(() => {
    async function countTotalOrders() {
      try {
        const response = await countCompletedOrders();
        setComp(response.data);
      } catch (error) {
        console.log(error);
      }
    }
    countTotalOrders();
  }, []);

  return (
    <>
      <PageHeader
        title="DMS | Home"
        subTitle="Welcome to DMS"
        icon={<HomeTwoTone fontSize="large" />}
      />
      <main className={PageContent}>
        <StyledContainer maxWidth="lg">
          <StyledPaper>
            <Grid item xs={12}>
              <Grid container spacing={3}>
                <Grid item xs={12} md={6} lg={4}>
                  <NoteCard
                    title="Trucks"
                    icon={<LocalShipping fontSize="large" color="primary" />}
                    details={fleet}
                  />
                </Grid>
                <Grid item xs={12} md={6} lg={4}>
                  <NoteCard
                    title="Drivers"
                    icon={
                      <AirlineSeatReclineExtra
                        fontSize="large"
                        color="primary"
                      />
                    }
                    details={drivers}
                  />
                </Grid>
                <Grid item xs={12} md={6} lg={4}>
                  <NoteCard
                    title="Customers"
                    icon={<Groups fontSize="large" color="primary" />}
                    details={customer}
                  />
                </Grid>
                <Grid item xs={12} md={6} lg={4}>
                  <NoteCard
                    title="Orders"
                    icon={<ShoppingCart fontSize="large" color="primary" />}
                    details={orders}
                  />
                </Grid>
                <Grid item xs={12} md={6} lg={4}>
                  <NoteCard
                    title="Complete Orders"
                    icon={
                      <ShoppingCartCheckout fontSize="large" color="primary" />
                    }
                    details={comp}
                  />
                </Grid>
              </Grid>
            </Grid>
            <Grid container spacing={2} sx={{ marginTop: 2 }}>
              {user && user.role === "Admin" ? (
                <>
                  <Grid item xs={12} md={8} lg={8}>
                    <BarChart />
                  </Grid>
                  <Grid item xs={12} md={4} lg={4}>
                    <PieChat />
                  </Grid>
                </>
              ) : (
                <Grid item xs={12}>
                  <BarChart />
                </Grid>
              )}
            </Grid>
          </StyledPaper>
        </StyledContainer>
      </main>
    </>
  );
}
