import React, { useContext } from "react";
import MultiFormContext from "../../../context/MultiFormContext";
import { Stack, TextField, Grid } from "@mui/material";

export default function CustomerDetails() {
  const {
    customerName,
    setCustomerName,
    emailAddress,
    setEmailAddress,
    phoneNumber,
    setPhone,
    preferences,
    setPreferences,
    location,
    setLocation,
  } = useContext(MultiFormContext);
  return (
    <Stack
      sx={{
        alignItems: "center",
        "& .MuiTextField-root": { width: "100%", maxWidth: 500, m: 1 },
      }}
    >
      <Grid container>
        <Grid item xs={6}>
          <TextField
            name="customerName"
            id="customerName"
            label="Customer Name"
            variant="outlined"
            value={customerName}
            onChange={(e) => setCustomerName(e.target.value)}
            required
          />
          <TextField
            name="phoneNumber"
            id="phoneNumber"
            label="Phone (tel)"
            variant="outlined"
            value={phoneNumber}
            onChange={(e) => setPhone(e.target.value)}
            required
          />
          <TextField
            name="preferences"
            id="preferences"
            label="Customer preferences"
            variant="outlined"
            value={preferences}
            onChange={(e) => setPreferences(e.target.value)}
            multiline
            rows={2}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            name="emailAddress"
            id="emailAddress"
            label="Email Address"
            variant="outlined"
            value={emailAddress}
            onChange={(e) => setEmailAddress(e.target.value)}
            required
          />
          <TextField
            name="location"
            id="location"
            label="Customer address"
            variant="outlined"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            multiline
            rows={5}
            required
          />
        </Grid>
      </Grid>
    </Stack>
  );
}
