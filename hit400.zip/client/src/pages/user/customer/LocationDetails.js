import React, { useContext, useEffect, useRef } from "react";
import MultiFormContext from "../../../context/MultiFormContext";
import { Stack } from "@mui/material";
import ReactMapGL, {
  GeolocateControl,
  Marker,
  NavigationControl,
} from "react-map-gl";
import "mapbox-gl/dist/mapbox-gl.css";
import Geocoder from "./Geocoder";

export default function LocationDetails() {
  const { lng, lat, setlat, setlng } = useContext(MultiFormContext);
  const mapRef = useRef();

  useEffect(() => {
    if (!lng && !lat) {
      fetch("https://ipapi.co/json")
        .then((response) => {
          return response.json();
        })
        .then((data) => {
          mapRef.current.flyTo({
            center: [data.longitude, data.latitude],
          });
          setlng(data.longitude);
          setlat(data.latitude);
        });
    }
  }, [lng, lat, mapRef]);

  return (
    <Stack sx={{ height: "100vh", display: "flex", position: "relative" }}>
      <ReactMapGL
        ref={mapRef}
        mapboxAccessToken="pk.eyJ1Ijoid2FiYW50dS13YXhvIiwiYSI6ImNsdjE2a3c1cDA0N20yanVzaWs2Mng2d2YifQ.DWfNt-TLsGUujYIgwmMQYw"
        initialViewState={{
          longitude: lng,
          latitude: lat,
          zoom: 8,
        }}
        mapStyle="mapbox://styles/mapbox/streets-v12"
      >
        <Marker
          latitude={lat}
          longitude={lng}
          draggable={true}
          onDragEnd={(e) => {
            setlng(e.lngLat.lng);
            setlat(e.lngLat.lat);
          }}
        />
        <NavigationControl position="bottom-right" />
        <GeolocateControl
          position="top-left"
          trackUserLocation
          onGeolocate={(e) => {
            setlng(e.coords.longitude);
            setlat(e.coords.latitude);
          }}
        />
        <Geocoder />
      </ReactMapGL>
    </Stack>
  );
}
