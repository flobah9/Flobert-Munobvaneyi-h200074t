import React, { useEffect, useState } from "react";
import {
  Paper,
  Toolbar,
  InputAdornment,
  TableBody,
  TableRow,
  TableCell,
} from "@mui/material";
import Controls from "../../../components/Controls";
import {
  Search,
  Visibility,
  SupportAgent,
  HowToReg,
} from "@mui/icons-material";
import useTable from "../../../utils/useTable";
import PageHeader from "../../../utils/PageHeader";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import { getAllCustomers } from "../../../functions/customerSlice";

const headCells = [
  { id: "id", label: "" },
  { id: "customerID", label: "Customer ID" },
  { id: "customerName", label: "Customer name" },
  { id: "email", label: "Email Address " },
  { id: "phone", label: "Phone Number" },
  { id: "address", label: "Address" },
  { id: "preferences", label: "Preferences" },
  { id: "actions", label: "Actions", disableSorting: true },
];

export default function Customers() {
  const [records, setRecords] = useState([]);
  const navigate = useNavigate();
  const [filterFn, setFilterFn] = useState({
    fn: (items) => {
      return items;
    },
  });

  const { user } = useSelector((state) => state.auth);

  const { TblContainer, TblHead, TblPagination, recordsAfterPagingAndSorting } =
    useTable(records, headCells, filterFn);

  const handleSearch = (e) => {
    let target = e.target;
    setFilterFn({
      fn: (items) => {
        if (target.value === "") return items;
        else
          return items.filter((x) =>
            x.firstName.toLowerCase().includes(target.value)
          );
      },
    });
  };

  async function getAllCustomerProfile() {
    try {
      const response = await getAllCustomers();
      setRecords(response.data);
    } catch (error) {
      console.log(error);
    }
  }

  useEffect(() => {
    getAllCustomerProfile();
  }, []);

  return (
    <>
      <PageHeader
        title="DMS | Customer Management"
        subTitle="Customer list"
        icon={<SupportAgent fontSize="large" />}
      />
      <Paper
        sx={{
          flexGrow: 1,
          margin: (theme) => theme.spacing(2),
          padding: (theme) => theme.spacing(1),
          overflow: "auto",
        }}
      >
        <Toolbar
          sx={{
            display: "flex",
            flexDirection: "row",
            flexWrap: "nowrap",
            justifyContent: "space-between",
          }}
        >
          <Controls.Input
            label="Search customer"
            sx={{ width: "65%" }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Search />
                </InputAdornment>
              ),
            }}
            onChange={handleSearch}
          />
          {user && user.role === "User" ? (
            <Controls.Button
              text="Register"
              variant="outlined"
              startIcon={<HowToReg />}
              sx={{ position: "absolute", right: "10px" }}
              onClick={() => navigate("/addcustomer")}
            />
          ) : (
            ""
          )}
        </Toolbar>
        <TblContainer>
          <TblHead />
          <TableBody>
            {recordsAfterPagingAndSorting().map((cust) => (
              <TableRow key={cust.id}>
                <TableCell>{cust.id}</TableCell>
                <TableCell>{cust.customerID}</TableCell>
                <TableCell>{cust.customerName}</TableCell>
                <TableCell>{cust.emailAddress}</TableCell>
                <TableCell>{cust.phoneNumber}</TableCell>
                <TableCell>{cust.location}</TableCell>
                <TableCell>{cust.preferences}</TableCell>
                <TableCell>
                  <Controls.ActionButton color="secondary">
                    <Visibility fontSize="small" />
                  </Controls.ActionButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </TblContainer>
        <TblPagination />
      </Paper>
    </>
  );
}
