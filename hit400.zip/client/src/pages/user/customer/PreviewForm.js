import React, { useContext } from "react";
import MultiFormContext from "../../../context/MultiFormContext";
import { Stack, Grid, TextField } from "@mui/material";

export default function PreviewForm() {
  const {
    customerName,
    emailAddress,
    phoneNumber,
    preferences,
    lng,
    lat,
    location,
  } = useContext(MultiFormContext);
  return (
    <Stack
      sx={{
        alignItems: "center",
        "& .MuiTextField-root": { width: "100%", maxWidth: 500, m: 1 },
      }}
    >
      <Grid container>
        <Grid item xs={6}>
          <TextField
            name="customerName"
            id="customerName"
            label="Customer Name"
            variant="outlined"
            value={customerName}
            inputProps={{
              readOnly: true,
            }}
          />
          <TextField
            name="phoneNumber"
            id="phoneNumber"
            label="Phone (tel)"
            variant="outlined"
            value={phoneNumber}
            inputProps={{
              readOnly: true,
            }}
          />
          <TextField
            name="emailAddress"
            id="emailAddress"
            label="Email Address"
            variant="outlined"
            value={emailAddress}
            inputProps={{
              readOnly: true,
            }}
          />
          <TextField
            name="preferences"
            id="preferences"
            label="Customer preferences"
            variant="outlined"
            value={preferences}
            inputProps={{
              readOnly: true,
            }}
            multiline
            rows={2}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            name="location"
            id="location"
            label="Customer address"
            variant="outlined"
            value={location}
            inputProps={{
              readOnly: true,
            }}
            multiline
            rows={5}
          />
          <TextField
            name="lng"
            id="lng"
            label="Longitude"
            variant="outlined"
            value={lng}
            inputProps={{
              readOnly: true,
            }}
          />
          <TextField
            name="lat"
            id="lat"
            label="Lattitude"
            variant="outlined"
            value={lat}
            inputProps={{
              readOnly: true,
            }}
          />
        </Grid>
      </Grid>
    </Stack>
  );
}
