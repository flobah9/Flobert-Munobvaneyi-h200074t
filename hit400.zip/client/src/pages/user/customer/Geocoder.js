import React, { useContext } from "react";
import MapBoxGeocoder from "@mapbox/mapbox-gl-geocoder";
import MultiFormContext from "../../../context/MultiFormContext";
import { useControl } from "react-map-gl";
import "@mapbox/mapbox-gl-geocoder/dist/mapbox-gl-geocoder.css";

const Geocoder = () => {
  const { setlat, setlng } = useContext(MultiFormContext);
  const ctrl = new MapBoxGeocoder({
    accessToken: "pk.eyJ1Ijoid2FiYW50dS13YXhvIiwiYSI6ImNsdjE2a3c1cDA0N20yanVzaWs2Mng2d2YifQ.DWfNt-TLsGUujYIgwmMQYw",
    marker: false,
    collapsed: true,
  });
  useControl(() => ctrl);
  ctrl.on("result", (e) => {
    const coords = e.result.geometry.coordinates;
    setlng(coords[0]);
    setlat(coords[1]);
  });
  return null;
};

export default Geocoder;
