import React, { useEffect, useState } from "react";
import { styled } from "@mui/material/styles";
import {
  Paper,
  Stepper,
  Step,
  StepButton,
  Stack,
  Button,
  Toolbar,
  InputAdornment,
} from "@mui/material";
import { Provider } from "../../../context/MultiFormContext";
import CustomerDetails from "./CustomerDetails";
import LocationDetails from "./LocationDetails";
import PageHeader from "../../../utils/PageHeader";
import {
  PersonPinCircle,
  Search,
  Send,
  SupportAgent,
} from "@mui/icons-material";
import Controls from "../../../components/Controls";
import { useNavigate } from "react-router-dom";
import Notification from "../../../utils/Notification";
import Loading from "../../../utils/Loading";
import { useDispatch, useSelector } from "react-redux";
import { AddNewCustomer, reset } from "../../../functions/customerSlice";
import PreviewForm from "./PreviewForm";

const StyledPaper = styled(Paper)(({ theme }) => ({
  marginTop: theme.spacing(1),
  marginBottom: theme.spacing(1),
  padding: theme.spacing(2),
  [theme.breakpoints.up(600 + theme.spacing(1) * 2)]: {
    marginTop: theme.spacing(2),
    marginBottom: theme.spacing(2),
    padding: theme.spacing(3),
  },
}));

const renderStep = (step) => {
  switch (step) {
    case 0:
      return <CustomerDetails />;
    case 1:
      return <LocationDetails />;
    case 2:
      return <PreviewForm />;
    default:
      throw new Error("Unknown step");
  }
};
const AddCustomer = () => {
  const [activeStep, setActiveStep] = useState(0);
  const [customerName, setCustomerName] = useState("");
  const [emailAddress, setEmailAddress] = useState("");
  const [phoneNumber, setPhone] = useState("");
  const [preferences, setPreferences] = useState("");
  const [location, setLocation] = useState("");
  const [lng, setlng] = useState(31.053028);
  const [lat, setlat] = useState(-17.824858);
  const [steps, setSteps] = useState([
    { label: "Customer details", completed: false },
    { label: "Location", completed: false },
    { label: "Preview", completed: false },
  ]);
  const [notify, setNotify] = useState({
    open: false,
    message: "",
    severity: "",
  });
  const [loading, setLoading] = useState(false);
  const [showSubmit, setShowSubmit] = useState(false);

  const navigate = useNavigate();
  const dispatch = useDispatch();

  const { customer, isError, isSuccess, message } = useSelector(
    (state) => state.customer
  );

  //next function
  const handleNext = () => {
    if (activeStep < steps.length - 1) {
      setActiveStep((activeStep) => activeStep + 1);
    } else {
      const stepIndex = findUnfinished();
      setActiveStep(stepIndex);
    }
  };

  const checkDisabled = () => {
    if (activeStep < steps.length - 1) return false;
    const index = findUnfinished();
    if (index !== -1) return false;
    return true;
  };

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const findUnfinished = () => {
    return steps.findIndex((step) => !step.completed);
  };

  //making the first form complete
  useEffect(() => {
    if (
      (customerName &&
        emailAddress &&
        phoneNumber &&
        preferences &&
        location) !== ""
    ) {
      if (!steps[0].completed) setComplete(0, true);
    } else {
      if (steps[0].completed) setComplete(0, false);
    }
  }, [customerName, emailAddress, location, phoneNumber, preferences, steps]);

  //making the second form complete
  useEffect(() => {
    if (lng !== 31.053028 && lat !== -17.824858) {
      if (!steps[1].completed) setComplete(1, true);
    } else {
      if (steps[1].completed) setComplete(1, false);
    }
  }, [lat, lng, steps]);

  //making the third form complete
  useEffect(() => {
    if (
      (customerName &&
        emailAddress &&
        phoneNumber &&
        preferences &&
        location) !== "" &&
      lng !== 31.053028 &&
      lat !== -17.824858
    ) {
      if (!steps[2].completed) setComplete(2, true);
    } else {
      if (steps[2].completed) setComplete(2, false);
    }
  }, [
    customerName,
    emailAddress,
    location,
    phoneNumber,
    preferences,
    steps,
    lat,
    lng,
  ]);

  //function to change the status of each step
  const setComplete = (index, status) => {
    setSteps((steps) => {
      steps[index].completed = status;
      return [...steps];
    });
  };

  //making the showSubmit button active
  useEffect(() => {
    if (findUnfinished() === -1) {
      if (!showSubmit) setShowSubmit(true);
    } else {
      if (showSubmit) setShowSubmit(false);
    }
  }, [findUnfinished, showSubmit, steps]);

  useEffect(() => {
    if (isError) {
      setLoading(false);
      setNotify({
        open: true,
        severity: "error",
        message: message,
      });
    }
    if (customer && isSuccess) {
      setLoading(false);
      setNotify({
        open: true,
        severity: "success",
        message: message,
      });
      setCustomerName("");
      setEmailAddress("");
      setPhone("");
      setLocation("");
      setPreferences("");
      setlat(-17.824858);
      setlng(31.053028);
      setActiveStep(0);
    }
    dispatch(reset());
  }, [customer, dispatch, isError, isSuccess, message]);

  //function to submit the captured details
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (lng === 31.053028 && lat === -17.824858) {
      setNotify({
        open: true,
        severity: "error",
        message: "Provide location, longitude and lattitude can not be 0!!!",
      });
    } else {
      const customer_details = {
        customerName: customerName,
        emailAddress: emailAddress,
        phoneNumber: phoneNumber,
        preferences: preferences,
        location: location,
        lng: lng,
        lat: lat,
      };
      setLoading(true);
      dispatch(AddNewCustomer(customer_details));
    }
  };

  return (
    <Provider
      value={{
        emailAddress,
        setEmailAddress,
        customerName,
        setCustomerName,
        phoneNumber,
        setPhone,
        location,
        setLocation,
        lat,
        setlat,
        lng,
        setlng,
        preferences,
        setPreferences,
      }}
    >
      <PageHeader
        title="DMS | Customer Management"
        subTitle="Register new customer"
        icon={<SupportAgent fontSize="large" />}
      />
      <StyledPaper sx={{ pb: 7 }}>
        <Toolbar
          sx={{
            display: "flex",
            flexDirection: "row",
            flexWrap: "nowrap",
            justifyContent: "space-between",
            marginBottom: "10px",
          }}
        >
          <Controls.Input
            label="Search customer"
            sx={{ width: "65%" }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Search />
                </InputAdornment>
              ),
            }}
          />
          <Controls.Button
            text="Customers"
            variant="outlined"
            startIcon={<PersonPinCircle />}
            sx={{ position: "absolute", right: "10px" }}
            onClick={() => navigate("/customers")}
          />
        </Toolbar>
        <Stepper
          alternativeLabel
          nonLinear
          activeStep={activeStep}
          sx={{ mb: 3 }}
        >
          {steps.map((step, index) => (
            <Step key={step.label} completed={step.completed}>
              <StepButton onClick={() => setActiveStep(index)}>
                {step.label}
              </StepButton>
            </Step>
          ))}
        </Stepper>
        <main>{renderStep(activeStep)}</main>
        <Stack direction="row" sx={{ pt: 2, justifyContent: "space-around" }}>
          <Button
            color="inherit"
            disabled={!activeStep}
            onClick={() => setActiveStep((activeStep) => activeStep - 1)}
          >
            Back
          </Button>
          <Button disabled={checkDisabled()} onClick={handleNext}>
            Next
          </Button>
        </Stack>
        {showSubmit && (
          <Stack sx={{ alignItems: "center" }}>
            <Button
              variant="contained"
              endIcon={<Send />}
              onClick={handleSubmit}
            >
              Submit
            </Button>
          </Stack>
        )}
      </StyledPaper>
      <Loading loading={loading} />
      <Notification notify={notify} setNotify={setNotify} />
    </Provider>
  );
};

export default AddCustomer;
