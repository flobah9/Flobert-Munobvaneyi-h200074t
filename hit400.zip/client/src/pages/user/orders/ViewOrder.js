import React from "react";
import { Form } from "../../../utils/useForm";
import { Grid } from "@mui/material";
import Controls from "../../../components/Controls";

export default function ViewOrder({ order }) {
  return (
    <Form>
      <Grid container>
        <Grid item xs={6}>
          <Controls.Input
            name="orderID"
            label="Order ID"
            value={order.orderID}
            variant="outlined"
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="customerID"
            label="Customer ID"
            value={order.customerID}
            variant="outlined"
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="loadType"
            label="Load Type"
            value={order.loadType}
            variant="outlined"
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="order_details"
            label="Order details"
            variant="outlined"
            value={order.order_details}
            multiline
            rows={3}
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="scheduled_delivery_time"
            label="Delivery time"
            value={order.scheduled_delivery_time}
            variant="outlined"
            inputProps={{ readOnly: true }}
          />
        </Grid>
        <Grid item xs={6}>
          <Controls.Input
            name="customerName"
            label="Customer Name"
            variant="outlined"
            value={order?.customer_profile?.customerName}
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="location"
            label="Customer address"
            variant="outlined"
            value={order?.customer_profile?.location}
            multiline
            rows={3}
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="fleetNo"
            label="fleetNo"
            value={order?.fleet_detail?.fleetNo}
            variant="outlined"
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="make"
            label="Make"
            value={order?.fleet_detail?.make}
            variant="outlined"
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="name"
            label="name"
            value={
              order?.fleet_detail?.driver_personal_detail?.firstName +
              " " +
              order?.fleet_detail?.driver_personal_detail?.lastName
            }
            variant="outlined"
            inputProps={{ readOnly: true }}
          />
          <Controls.Input
            name="status"
            label="Status"
            value={order.status}
            variant="outlined"
            inputProps={{ readOnly: true }}
          />
        </Grid>
      </Grid>
    </Form>
  );
}
