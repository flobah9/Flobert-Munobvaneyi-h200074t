import React, { useEffect, useState } from "react";
import useTable from "../../../utils/useTable";
import PageHeader from "../../../utils/PageHeader";
import {
  AddShoppingCart,
  Close,
  Edit,
  OnlinePredictionSharp,
  Search,
  Visibility,
} from "@mui/icons-material";
import {
  InputAdornment,
  Paper,
  TableBody,
  TableCell,
  TableRow,
  Toolbar,
} from "@mui/material";
import Controls from "../../../components/Controls";
import Popup from "../../../utils/Popup";
import CreateOrder from "./CreateOrder";
import { useDispatch, useSelector } from "react-redux";
import {
  CancelOrder,
  CreateCustomerOrder,
  ReAssignOrder,
  getAllOrders,
  reset,
} from "../../../functions/orderSlice";
import Notification from "../../../utils/Notification";
import Loading from "../../../utils/Loading";
import ConfirmDialog from "../../../utils/ConfirmDialog";
import ViewOrder from "./ViewOrder";

const headCells = [
  { id: "id", label: "" },
  { id: "customerName", label: "Customer name" },
  { id: "customerID", label: "CustomerID " },
  { id: "orderID", label: "OrderID" },
  { id: "loadType", label: "Class" },
  { id: "delivery_time", label: "Time" },
  { id: "fleetNo", label: "Fleet" },
  { id: "status", label: "Status" },
  { id: "actions", label: "Actions", disableSorting: true },
];

export default function Order() {
  const [records, setRecords] = useState([]);
  const [recordForView, setRecordForView] = useState(null);
  const [open, setOpen] = useState(false);
  const [openPopup, setOpenPopup] = useState(false);
  const [filterFn, setFilterFn] = useState({
    fn: (items) => {
      return items;
    },
  });

  const [notify, setNotify] = useState({
    open: false,
    message: "",
    severity: "",
  });
  const [loading, setLoading] = useState(false);
  const [reloadData, setReloadData] = useState(false);
  const dispatch = useDispatch();

  const { user } = useSelector((state) => state.auth);
  const { order, isError, isSuccess, message } = useSelector(
    (state) => state.order
  );

  const [confirmDialog, setConfirmDialog] = React.useState({
    isOpen: false,
    title: "",
    subTitle: "",
    onConfirm: () => {},
  });

  const { TblContainer, TblHead, TblPagination, recordsAfterPagingAndSorting } =
    useTable(records, headCells, filterFn);

  const handleSearch = (e) => {
    let target = e.target;
    setFilterFn({
      fn: (items) => {
        if (target.value === "") return items;
        else
          return items.filter((x) =>
            x.orderID.toLowerCase().includes(target.value)
          );
      },
    });
  };

  async function getAllCustomerOrder() {
    try {
      const response = await getAllOrders();
      setRecords(response.data);
    } catch (error) {
      console.log(error);
    }
  }

  useEffect(() => {
    if (reloadData) {
      getAllCustomerOrder();
      setReloadData(false);
    } else {
      getAllCustomerOrder();
    }
  }, [reloadData]);

  useEffect(() => {
    if (isError) {
      setLoading(false);
      setNotify({
        open: true,
        severity: "error",
        message: message,
      });
    }
    if (order && isSuccess) {
      setLoading(false);
      setOpenPopup(false);
      setNotify({
        open: true,
        severity: "success",
        message: message,
      });
    }
    dispatch(reset());
  }, [dispatch, order, isError, isSuccess, message]);

  const addOrEdit = async (order_details, resetForm) => {
    try {
      setLoading(true);
      dispatch(CreateCustomerOrder(order_details));
      setReloadData(true);
      resetForm();
    } catch (error) {
      console.log(error);
    }
  };

  const handleCancel = async (id) => {
    setConfirmDialog({
      ...confirmDialog,
      isOpen: false,
    });
    try {
      dispatch(CancelOrder(id));
    } catch (error) {
      console.log(error);
    }
  };

  const handleReAssign = async (id) => {
    setConfirmDialog({
      ...confirmDialog,
      isOpen: false,
    });
    try {
      dispatch(ReAssignOrder(id));
    } catch (error) {
      console.log(error);
    }
  };

  const openInView = (order) => {
    setRecordForView(order);
    setOpen(true);
  };

  return (
    <>
      <PageHeader
        title="DMS | Order Management"
        subTitle="Order lists"
        icon={<OnlinePredictionSharp fontSize="large" />}
      />
      <Paper
        sx={{
          flexGrow: 1,
          margin: (theme) => theme.spacing(2),
          padding: (theme) => theme.spacing(1),
          overflow: "auto",
        }}
      >
        <Toolbar
          sx={{
            display: "flex",
            flexDirection: "row",
            flexWrap: "nowrap",
            justifyContent: "space-between",
          }}
        >
          <Controls.Input
            label="Search order"
            sx={{ width: "55%" }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Search />
                </InputAdornment>
              ),
            }}
            onChange={handleSearch}
          />
          {user && user.role === "User" ? (
            <Controls.Button
              text="Create_order"
              variant="outlined"
              startIcon={<AddShoppingCart />}
              sx={{ position: "absolute", right: "10px" }}
              onClick={() => {
                setOpenPopup(true);
              }}
            />
          ) : (
            ""
          )}
        </Toolbar>
        <TblContainer>
          <TblHead />
          <TableBody>
            {recordsAfterPagingAndSorting().map((ord) => (
              <TableRow key={ord.id}>
                <TableCell>{ord.id}</TableCell>
                <TableCell>{ord?.customer_profile?.customerName}</TableCell>
                <TableCell>{ord?.customer_profile?.customerID}</TableCell>
                <TableCell>{ord.orderID}</TableCell>
                <TableCell>{ord.loadType}</TableCell>
                <TableCell>{ord.scheduled_delivery_time}</TableCell>
                <TableCell>{ord?.fleet_detail?.fleetNo}</TableCell>
                <TableCell>{ord.status}</TableCell>
                <TableCell>
                  <Controls.ActionButton
                    color="secondary"
                    onClick={() => {
                      openInView(ord);
                    }}
                  >
                    <Visibility fontSize="small" />
                  </Controls.ActionButton>
                  {user && user.role === "Admin" ? (
                    <>
                      {ord.status !== "Assigned" &&
                        ord.status !== "Completed" && (
                          <Controls.ActionButton
                            color="primary"
                            onClick={() => {
                              setConfirmDialog({
                                isOpen: true,
                                title:
                                  "Are you sure you want to retry to assign a vehicle?",
                                subTitle: "Confirm to retry the assignment",
                                onConfirm: () => {
                                  handleReAssign(ord.id);
                                },
                              });
                            }}
                          >
                            <Edit fontSize="small" />
                          </Controls.ActionButton>
                        )}
                      {ord.status !== "Completed" ? (
                        <Controls.ActionButton
                          color="error"
                          onClick={() => {
                            setConfirmDialog({
                              isOpen: true,
                              title: "Are you sure to cancel this order?",
                              subTitle: "You can't undo this operation",
                              onConfirm: () => {
                                handleCancel(ord.id);
                              },
                            });
                          }}
                        >
                          <Close fontSize="small" />
                        </Controls.ActionButton>
                      ) : (
                        ""
                      )}
                    </>
                  ) : (
                    ""
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </TblContainer>
        <TblPagination />
      </Paper>
      <Popup
        title={"DMS | Create New Order"}
        openPopup={openPopup}
        setOpenPopup={setOpenPopup}
      >
        <CreateOrder addOrEdit={addOrEdit} />
      </Popup>
      <Popup
        title="DMS | View Order Details"
        openPopup={open}
        setOpenPopup={setOpen}
      >
        <ViewOrder order={recordForView} />
      </Popup>
      <ConfirmDialog
        confirmDialog={confirmDialog}
        setConfirmDialog={setConfirmDialog}
      />
      <Loading loading={loading} />
      <Notification notify={notify} setNotify={setNotify} />
    </>
  );
}
