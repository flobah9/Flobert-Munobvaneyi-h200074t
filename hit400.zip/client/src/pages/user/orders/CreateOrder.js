import React, { useEffect, useState } from "react";
import { useForm, Form } from "../../../utils/useForm";
import { Grid, InputAdornment, TextField } from "@mui/material";
import Controls from "../../../components/Controls";
import { RestartAlt, Scale, Search, Send } from "@mui/icons-material";
import { GetCustomerID } from "../../../functions/customerSlice";
import { orderType } from "../../../functions/orderSlice";

const initialFValues = {
  customerID: "",
  loadType: "Light",
  order_details: "",
  estimated_weight: "",
  scheduled_delivery_time: "",
};

export default function CreateOrder(props) {
  const { addOrEdit } = props;
  const [custID, setCustID] = useState("");
  const [custom, setCustom] = useState([]);

  const [schedule, setSchedule] = useState(new Date("yyyy-MM-dd"));

  const validate = (fieldValues = values) => {
    let temp = { ...errors };
    if ("customerID" in fieldValues)
      temp.customerID = fieldValues.customerID
        ? ""
        : "Customer ID is required.";
    if ("loadType" in fieldValues)
      temp.loadType = fieldValues.loadType ? "" : "Type of load is required.";
    if ("order_details" in fieldValues)
      temp.order_details = fieldValues.order_details
        ? ""
        : "Order details is required.";
    if ("estimated_weight" in fieldValues)
      temp.estimated_weight = fieldValues.estimated_weight
        ? ""
        : "This field is required.";
    setErrors({
      ...temp,
    });

    if (fieldValues === values)
      return Object.values(temp).every((x) => x === "");
  };

  useEffect(() => {
    if (custID !== "") {
      if (custID.length > 6) {
        async function searchCustomer() {
          try {
            const response = await GetCustomerID(custID);
            setCustom(response.data);
          } catch (error) {
            console.log(error);
          }
        }
        searchCustomer();
      }
    }
  }, [custID]);

  const { values, errors, setErrors, handleInputChange, resetForm } = useForm(
    initialFValues,
    true,
    validate
  );

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (validate()) {
      const details = {
        customerID: values.customerID,
        estimated_weight: values.estimated_weight,
        loadType: values.loadType,
        order_details: values.order_details,
        scheduled_delivery_time: schedule,
      };
      addOrEdit(details, resetForm);
    }
  };

  return (
    <Form onSubmit={handleSubmit}>
      <Grid container>
        <Grid item xs={6}>
          <Controls.Input
            name="customerID"
            label="Customer ID"
            value={values.customerID}
            onChange={(e) => {
              setCustID(e.target.value);
              handleInputChange(e);
            }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="end">
                  <Search />
                </InputAdornment>
              ),
            }}
            error={errors.customerID}
          />
          <Controls.Input
            name="customerName"
            value={custom.customerName}
            inputProps={{
              readOnly: true,
            }}
          />
          <Controls.Input
            name="emailAddress"
            value={custom.emailAddress}
            inputProps={{
              readOnly: true,
            }}
          />
          <Controls.Input
            name="location"
            value={custom.location}
            inputProps={{ readOnly: true }}
            multiline
            rows={3}
          />
        </Grid>
        <Grid item xs={6}>
          <Controls.UserSelect
            name="loadType"
            label="Load Type"
            value={values.loadType}
            onChange={handleInputChange}
            options={orderType()}
          />
          <Controls.Input
            name="order_details"
            label="Order details"
            value={values.order_details}
            onChange={handleInputChange}
            multiline
            rows={2}
            error={errors.order_details}
          />
          <Controls.Input
            name="estimated_weight"
            label="Estimate delivery weight"
            value={values.estimated_weight}
            onChange={handleInputChange}
            InputProps={{
              startAdornment: (
                <InputAdornment position="end">
                  <Scale />
                </InputAdornment>
              ),
            }}
            error={errors.estimated_weight}
          />
          <TextField
            id="datetime-local"
            label="Schedule delivery time"
            variant="outlined"
            name="scheduled_delivery_time"
            type="datetime-local"
            sx={{ margin: (theme) => theme.spacing(1), width: "80%" }}
            onChange={(e) => setSchedule(e.target.value)}
            value={schedule}
            InputLabelProps={{
              shrink: true,
            }}
          />
          <div className="row">
            <Controls.Button type="submit" text="Submit" startIcon={<Send />} />
            <Controls.Button
              text="Reset"
              color="error"
              startIcon={<RestartAlt />}
              onClick={resetForm}
            />
          </div>
        </Grid>
      </Grid>
    </Form>
  );
}
