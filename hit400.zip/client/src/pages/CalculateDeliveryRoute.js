import axios from 'axios'; // Assuming you're using Axios for HTTP requests

// Replace with your actual Mapbox access token (avoid hardcoding)
const mapboxAccessToken =
  "pk.eyJ1Ijoid2FiYW50dS13YXhvIiwiYSI6ImNsdjE2a3c1cDA0N20yanVzaWs2Mng2d2YifQ.DWfNt-TLsGUujYIgwmMQYw";

export const calculateDeliveryRoute = async (path, deliveryTime, trafficConditions) => {
  if (!path || !deliveryTime) {
    throw new Error('Invalid path or delivery time provided');
  }

  const origin = `${path.originLng},${path.originLat}`;
  const destination = `${path.destinationLng},${path.destinationLat}`;
  const profile = trafficConditions ? `driving-${trafficConditions}` : 'driving'; // Adjust profile based on traffic conditions
  const baseUrl = `https://api.mapbox.com/directions/v5/mapbox/${profile}`;

  const params = {
    access_token: mapboxAccessToken,
    geometries: 'geojson',
    waypoints: [origin, destination],
    driving_time : deliveryTime.toISOString(), // Include ISO 8601 formatted delivery time for time-based routing
  };

  try {
    const response = await axios.get(baseUrl, { params });
    const route = response.data.routes[0]; // Assuming the first route is the desired one

    return {
      origin: { lng: path.originLng, lat: path.originLat },
      destination: { lng: path.destinationLng, lat: path.destinationLat },
      distance: route.distance,
      estimatedTime: route.duration / 1000, // Convert milliseconds to seconds
    };
  } catch (error) {
    console.error('Error fetching delivery route:', error);
    throw new Error('Failed to calculate delivery route'); // Re-throw for handling in the calling component
  }
};
