import React from "react";
import { Outlet } from "react-router-dom";
import { DriverDashboard } from "./utils/DriverDashboard";

function DriverAppLayout() {
  return (
    <DriverDashboard>
      <Outlet />
    </DriverDashboard>
  );
}

export default DriverAppLayout;
