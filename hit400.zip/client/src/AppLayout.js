import React from "react";
import { Outlet } from "react-router-dom";
import { Dashboard } from "./utils/Dashboard";

function AppLayout() {
  return (
    <Dashboard>
      <Outlet />
    </Dashboard>
  );
}

export default AppLayout;
