import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import AppLayout from "./AppLayout";
import DriverAppLayout from "./DriverAppLayout";
import Home from "./pages/Home";
import Employee from "./pages/admin/employee/Employee";
import Customers from "./pages/user/customer/Customers";
import Fleet from "./pages/admin/fleet/Fleet";
import Driver from "./pages/admin/employee/Driver";
import AddCustomer from "./pages/user/customer/AddCustomer";
import Order from "./pages/user/orders/Order";
import CompanyProfile from "./pages/CompanyProfile";
import SignIn from "./pages/auth/SignIn";
import SignUp from "./pages/auth/SignUp";
import HomePage from "./pages/driver/HomePage";
import AssignedTask from "./pages/driver/AssignedTask";
import TrackOrder from "./pages/admin/track/TrackOrder";

function App() {
  return (
    <>
      <Router>
        <Routes>
          <Route element={<AppLayout />}>
            <Route exact path="/" element={<Home />} />
            <Route path="/employee" element={<Employee />} />
            <Route exact path="/drivers" element={<Driver />} />
            <Route exact path="/customers" element={<Customers />} />
            <Route exact path="/addcustomer" element={<AddCustomer />} />
            <Route exact path="/fleet" element={<Fleet />} />
            <Route exact path="/orders" element={<Order />} />
            <Route exact path="/companyprofile" element={<CompanyProfile />} />
            <Route exact path="/tracking" element={<TrackOrder />} />
          </Route>
          <Route exact path="/signin" element={<SignIn />} />
          <Route exact path="/signup" element={<SignUp />} />
          <Route element={<DriverAppLayout />}>
            <Route exact path="/home" element={<HomePage />} />
            <Route exact path="/task" element={<AssignedTask />} />
          </Route>
        </Routes>
      </Router>
    </>
  );
}

export default App;
