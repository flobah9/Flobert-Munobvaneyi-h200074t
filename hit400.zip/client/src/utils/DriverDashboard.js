import * as React from "react";
import { styled, createTheme, ThemeProvider } from "@mui/material/styles";
import CssBaseline from "@mui/material/CssBaseline";
import MuiDrawer from "@mui/material/Drawer";
import Box from "@mui/material/Box";
import MuiAppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import List from "@mui/material/List";
import Typography from "@mui/material/Typography";
import Divider from "@mui/material/Divider";
import IconButton from "@mui/material/IconButton";
import Container from "@mui/material/Container";
import MenuIcon from "@mui/icons-material/Menu";
import ChevronLeftIcon from "@mui/icons-material/ChevronLeft";
import Grid from "@mui/material/Grid";
import {
  Avatar,
  Badge,
  Button,
  ListItem,
  ListItemIcon,
  ListItemText,
  Menu,
  MenuItem,
  Tooltip,
} from "@mui/material";
import {
  AddTask,
  HomeRounded,
  Lock,
  Logout,
  Mail,
  Notifications,
  Person,
  PersonPinCircleRounded,
} from "@mui/icons-material";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import Protection from "./Protection";
import { LogOut, reset } from "../functions/authentication";
import ConfirmDialog from "./ConfirmDialog";

const drawerWidth = 240;

const AppBar = styled(MuiAppBar, {
  shouldForwardProp: (prop) => prop !== "open",
})(({ theme, open }) => ({
  zIndex: theme.zIndex.drawer + 1,
  transition: theme.transitions.create(["width", "margin"], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  ...(open && {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  }),
}));

const Drawer = styled(MuiDrawer, {
  shouldForwardProp: (prop) => prop !== "open",
})(({ theme, open }) => ({
  "& .MuiDrawer-paper": {
    position: "relative",
    whiteSpace: "nowrap",
    width: drawerWidth,
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
    boxSizing: "border-box",
    ...(!open && {
      overflowX: "hidden",
      transition: theme.transitions.create("width", {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen,
      }),
      width: theme.spacing(7),
      [theme.breakpoints.up("sm")]: {
        width: theme.spacing(9),
      },
    }),
  },
}));

const tealTheme = createTheme({
  palette: {
    primary: {
      main: "#00897B", // Teal color
    },
    secondary: {
      main: "#1de9b6", // Some other color for secondary
    },
  },
});

export const DriverDashboard = (props) => {
  const [open, setOpen] = React.useState(false);
  const [anchorUserMenu, setAnchorUserMenu] = React.useState(null);
  const [confirmDialog, setConfirmDialog] = React.useState({
    isOpen: false,
    title: "",
    subTitle: "",
    onConfirm: () => {},
  });
  const { truck } = useSelector((state) => state.trucks);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const toggleDrawer = () => {
    setOpen(!open);
  };

  const handleCloseMenu = () => {
    setAnchorUserMenu(null);
  };

  const userLogout = async () => {
    setConfirmDialog({
      ...confirmDialog,
      isOpen: false,
    });
    try {
      dispatch(LogOut());
      navigate("/signin");
      dispatch(reset());
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <ThemeProvider theme={tealTheme}>
      <Box sx={{ display: "flex" }}>
        <CssBaseline />
        <AppBar position="absolute" open={open}>
          <Toolbar
            sx={{
              pr: "24px", // keep right padding when drawer closed
            }}
          >
            <IconButton
              edge="start"
              color="inherit"
              aria-label="open drawer"
              onClick={toggleDrawer}
              sx={{
                marginRight: "36px",
                ...(open && { display: "none" }),
              }}
            >
              <MenuIcon />
            </IconButton>
            <Typography
              variant="h6"
              component="h1"
              noWrap
              sx={{ flexGrow: 1, display: { xs: "none", md: "flex" } }}
            >
              Delivery Management System
            </Typography>
            <Typography
              variant="h6"
              component="h1"
              noWrap
              sx={{ flexGrow: 1, display: { xs: "flex", md: "none" } }}
            >
              DMS
            </Typography>
            {!truck ? (
              <Button
                color="inherit"
                startIcon={<Lock />}
                onClick={() => navigate("/signin")}
              >
                Login
              </Button>
            ) : (
              <Box>
                <IconButton color="inherit">
                  <Badge color="error" badgeContent={5}>
                    <Mail />
                  </Badge>
                </IconButton>
                <IconButton color="inherit">
                  <Badge color="error" badgeContent={9}>
                    <Notifications />
                    {""}
                  </Badge>
                </IconButton>
                <Tooltip title="Open user settings">
                  <IconButton
                    onClick={(e) => setAnchorUserMenu(e.currentTarget)}
                  >
                    <Avatar src={null} alt={truck?.firstName + truck?.lastName}>
                      {truck?.firstName?.charAt(0).toUpperCase() +
                        truck?.lastName?.charAt(0).toUpperCase()}
                    </Avatar>
                  </IconButton>
                </Tooltip>
                <Menu
                  anchorEl={anchorUserMenu}
                  open={Boolean(anchorUserMenu)}
                  onClose={handleCloseMenu}
                  onClick={handleCloseMenu}
                >
                  <MenuItem>
                    <ListItemIcon>
                      <Person fontSize="small" />
                    </ListItemIcon>
                    <ListItemText primary="My Profile" />
                  </MenuItem>
                  <MenuItem
                    onClick={() => {
                      setConfirmDialog({
                        isOpen: true,
                        title: "You are about to logout of the system!",
                        subTitle: "Are you sure, you can't undo this operation",
                        onConfirm: () => {
                          userLogout();
                        },
                      });
                    }}
                  >
                    <ListItemIcon>
                      <Logout fontSize="small" />
                    </ListItemIcon>
                    <ListItemText primary="Logout" />
                  </MenuItem>
                </Menu>
              </Box>
            )}
          </Toolbar>
        </AppBar>
        {truck && truck.licence_no !== null ? (
          <>
            <Drawer variant="permanent" open={open}>
              <Toolbar
                sx={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "flex-end",
                  px: [1],
                }}
              >
                <IconButton onClick={toggleDrawer}>
                  <ChevronLeftIcon />
                </IconButton>
              </Toolbar>
              <Divider />
              <List component="nav">
                <ListItem button onClick={() => navigate("/home")}>
                  <ListItemIcon>
                    <HomeRounded />
                  </ListItemIcon>
                  <ListItemText primary="Home" />
                </ListItem>

                <ListItem button onClick={() => navigate("/task")}>
                  <ListItemIcon>
                    <AddTask />
                  </ListItemIcon>
                  <ListItemText primary="Assigned deliveries" />
                </ListItem>

                <ListItem button onClick={() => navigate("/profile")}>
                  <ListItemIcon>
                    <PersonPinCircleRounded />
                  </ListItemIcon>
                  <ListItemText primary="My profile" />
                </ListItem>
              </List>
            </Drawer>
            <Box
              component="main"
              sx={{
                backgroundColor: (theme) =>
                  theme.palette.mode === "light"
                    ? theme.palette.grey[100]
                    : theme.palette.grey[900],
                flexGrow: 1,
                height: "100vh",
                overflow: "auto",
              }}
            >
              <Toolbar />
              <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
                <Grid item xs={12}>
                  {props.children}
                </Grid>
              </Container>
            </Box>
          </>
        ) : (
          <Protection />
        )}
      </Box>
      <ConfirmDialog
        confirmDialog={confirmDialog}
        setConfirmDialog={setConfirmDialog}
      />
    </ThemeProvider>
  );
};
