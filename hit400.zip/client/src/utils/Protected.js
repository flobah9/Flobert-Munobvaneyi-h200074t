import React from "react";
import { useSelector } from "react-redux";
import AccessMessage from "../pages/auth/AccessMessage";

const Protected = ({ children }) => {
  const { user } = useSelector((state) => state.auth);
  return user ? children : <AccessMessage />;
};

export default Protected;
