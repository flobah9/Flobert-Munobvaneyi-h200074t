import React from "react";
import { Paper, Card, Typography } from "@mui/material";
import { styled } from "@mui/material/styles";

const StyledPaper = styled(Paper)({
  backgroundColor: "#fdfdff",
});

const HeaderDiv = styled("div")(({ theme }) => ({
  padding: theme.spacing(1),
  display: "flex",
  marginBottom: theme.spacing(0.5),
}));

const StyledCard = styled(Card)(({ theme }) => ({
  display: "inline-block",
  padding: theme.spacing(1),
  color: theme.palette.primary.light,
}));

const TitleDiv = styled("div")(({ theme }) => ({
  paddingLeft: theme.spacing(1),
  "& .MuiTypography-subtitle2": {
    opacity: "0.5",
  },
}));

export default function PageHeader(props) {
  const { title, subTitle, icon } = props;
  return (
    <StyledPaper elevation={0} square>
      <HeaderDiv>
        <StyledCard>{icon}</StyledCard>
        <TitleDiv>
          <Typography variant="h6" component="div">
            {title}
          </Typography>
          <Typography variant="subtitle2" component="div">
            {subTitle}
          </Typography>
        </TitleDiv>
      </HeaderDiv>
    </StyledPaper>
  );
}
