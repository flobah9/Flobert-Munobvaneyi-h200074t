import React from "react";
import { useSelector } from "react-redux";
import AccessForbidden from "../pages/auth/AccessForbidden";

const Protected = ({ children }) => {
  const { truck } = useSelector((state) => state.trucks);
  return truck ? children : <AccessForbidden />;
};

export default Protected;
