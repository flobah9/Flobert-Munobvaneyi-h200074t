// In routeSlice.js
export const getOptimizedRoute = createAsyncThunk(
    "route/getOptimizedRoute",
    async (id) => {
      const response = await axios.get(
        `https://api.mapbox.com/directions/v5/mapbox/driving/${origin.lng},${origin.lat};${destination.lng},${destination.lat}?geometries=geojson&access_token=${process.env.REACT_APP_MAPBOX_ACCESS_TOKEN}`
      );
      const trafficResponse = await axios.get(
        `https://api.mapbox.com/traffic-data/v1/mapbox/driving/${origin.lng},${origin.lat};${destination.lng},${destination.lat}?access_token=${process.env.REACT_APP_MAPBOX_ACCESS_TOKEN}`
      );
      const trafficData = trafficResponse.data;
      // Parse the traffic data and adjust the distance variable based on the traffic data
      const distance = getDistance(origin, destination, trafficData);
      return { id, coordinates: response.data.routes[0].geometry.coordinates };
    }
  );
  
  // In ViewRoute.js
  // Update the getDistance function to take trafficData as a parameter
  const getDistance = (start, end, trafficData) => {
    const R = 6371; // Radius of the Earth in km
    const dLat = deg2rad(end.lat - start.lat);
    const dLon = deg2rad(end.lng - start.lng);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(deg2rad(start.lat)) *
        Math.cos(deg2rad(end.lat)) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distance = R * c; // Distance in km
    // Adjust the distance based on the traffic data
    const trafficFactor = getTrafficFactor(trafficData);
    return distance * trafficFactor;
  };
  
  // Add a helper function to get the traffic factor based on the traffic data
  const getTrafficFactor = (trafficData) => {
    // Parse the traffic data and return a traffic factor based on the data
    // For example, if the traffic data shows heavy traffic, you can return a traffic factor of 1.5 to increase the distance
    // If the traffic data shows light traffic, you can return a traffic factor of 0.5 to decrease the distance
    // You can also use the traffic data to adjust the average speed used to calculate the travel time
  };